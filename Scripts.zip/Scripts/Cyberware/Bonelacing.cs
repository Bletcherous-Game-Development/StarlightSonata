using System;

[Serializable]
public class Bonelacing : Cyberware
{
    public void CGO_Initialize(Augmentation.WARE_GRADE wG, int rtng)
    {
        augmentationName = Augmentation.AUGMENTATION_NAME.Bonelacing;
        base.CGO_Initialize(augmentationName, 1000, 1, Gear.LEGALITY.L, wG, 0.1f);
    }
}