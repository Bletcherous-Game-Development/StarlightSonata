// base class for various stats
using System;
using System.Collections.Generic;

[Serializable]
public abstract class ControllableStat : CyberpunkGameObject
{
    public StatController statController;
    public Entity entity;
    public List<Modifier> modifiers = new List<Modifier>();
    bool _isControlled = false;

    public bool isControlled
    {
        get { return _isControlled; }
        set
        {
            try
            {
                _isControlled = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public void SetEntity(Entity e)
    {
        entity = e;
    }

    public void SetStatController(StatController sCon)
    {
        statController = sCon;
        SetControlled(true);
        if (Utilities.isntNull(sCon.GM))
        {
            SetGM(sCon.GM);
        }

        if (Utilities.isntNull(sCon.entity))
        {
            SetEntity(sCon.entity);
        }
    }

    public void SetControlled(bool c)
    {
        isControlled = c;
        if (c == false)
        {
            entity = null;
            statController = null;
        }
    }

    public void Sync(StatController sCon)
    {
        SetStatController(sCon);
    }
}

