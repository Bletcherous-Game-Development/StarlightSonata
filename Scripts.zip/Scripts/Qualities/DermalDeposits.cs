using System;

[Serializable]
public class DermalDeposits : Quality
{
    public override void GameEffect()
    {
        if (Utilities.isNull(entity))
        {
            return;
        }

        if (Utilities.isNull(entity.attributeController))
        {
            return;
        }

        SetQualityType(QUALITY_TYPE.Positive);
        SetKarmaCost(7);
        foreach (Attribute a in entity.attributeController.controlledStats)
        {
            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Armor)
            {
                a.SetBaseRank(1);
                break;
            }
        }
    }

    public override void ReverseEffect()
    {
        base.ReverseEffect();
    }
}