using System;

[Serializable]
public class Avoidlncoming : Action // Anytime
{
    public override void InitiateAction()
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        Utilities.wr("***<==8_Avoidlncoming_8==>***");
        if (TimeAndTypeCheck())
        {
        }
    }
}