using System;

[Serializable]
public class Impairment : Quality
{
    Attribute.ATTRIBUTE_NAME _attributeName = Attribute.ATTRIBUTE_NAME.Undefined;
    private int _rating = 0;

    public int rating
    {
        get { return _rating; }
        set
        {
            try
            {


                _rating = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!I!");
            }
        }
    }

    public Attribute.ATTRIBUTE_NAME attributeName
    {
        get { return _attributeName; }
        set
        {
            try
            {
                _attributeName = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public void CGO_Initialize(Quality.QUALITY_NAME qN, Attribute.ATTRIBUTE_NAME aN, int rtng)
    {
        rating = rtng;
        SetKarmaCost((rating * 5));
        attributeName = aN;
        SetQualityType(QUALITY_TYPE.Negative);
        base.CGO_Initialize(qN);
        SetName((qualityName.ToString() + "(" + attributeName.ToString() + ")"));
    }

    public override void GameEffect()
    {
        if (Utilities.isNull(entity))
        {
            return;
        }

        if (Utilities.isNull(entity.attributeController))
        {
            return;
        }

        foreach (Attribute a in entity.attributeController.controlledStats)
        {
            if (a.attributeName == attributeName)
            {
                if ((a.rankLimit - rating) > 0)
                {
                    a.DecreaseRankLimit(rating);
                }
            }
        }
    }

    public override void ReverseEffect()
    {
        if (Utilities.isNull(entity))
        {
            return;
        }

        if (Utilities.isNull(entity.attributeController))
        {
            return;
        }

        foreach (Attribute a in entity.attributeController.controlledStats)
        {
            if (a.attributeName == attributeName)
            {
                a.rankLimit += rating;
            }
        }

        base.ReverseEffect();
    }
}