using System;

[Serializable]
public class Antanae : Cyberware
{
    public void CGO_Initialize(Augmentation.WARE_GRADE wG)
    {
        augmentationName = Augmentation.AUGMENTATION_NAME.Antanae;
        capacity = 1;
        base.CGO_Initialize(augmentationName, 1000, 1, Gear.LEGALITY.I, wG, 0.1f);
    }
}