//The parent for all items that can be equipped/used/inventoried
using System;

[Serializable]
public class Gear : ControllableStat
{
	private int _availability = 0;
	private int _capacity = 0;
	private int _concealability = 0;
	private bool _consumable = false;
	private int _cost = 0;
	private GEAR_CATAGORY _gearCatagory = GEAR_CATAGORY.Undefined;
	private LEGALITY _legality = LEGALITY.Undefined;
	private int _quantity = 1;
	private int _rating = 0;
	private Skill.SKILL_NAME _requiredSkillName = Skill.SKILL_NAME.Undefined;
	private bool _stackable = false;

	public enum GEAR_CATAGORY
	{
		Accessory,
		Ammunition,
		Armor,
		AuditoryDevice,
		Augmentation,
		Biotech,
		CommunicationAndCountermeasure,
		Drone,
		Electronic,
		Explosive,
		IdAndCredit,
		IndustrialChemical,
		OpticalAndImagingDevice,
		SecurityDevice,
		Sensor,
		Software,
		Survival,
		Tool,
		Weapon,
		Undefined
	}

	public enum LEGALITY
	{
		I, // Illegal
		L, // Legal, needs license
		Undefined
	}

	public virtual int availability
	{
		get { return _availability; }
		set
		{
			try
			{
				_availability = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
			}
		}
	}

	public int capacity
	{
		get { return _capacity; }
		set
		{
			try
			{
				_capacity = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
			}
		}
	}

	public int concealability
	{
		get { return _concealability; }
		set
		{
			try
			{
				_concealability = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
			}
		}
	}

	public bool consumable // for things that need to stop existing when used
	{
		get { return _consumable; }
		set
		{
			try
			{
				_consumable = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
			}
		}
	}

	public virtual int cost // grade or rating will modify this
	{
		get { return _cost; }
		set
		{

			try
			{
				_cost = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + "	Property set errror!!!");
			}
		}
	}

	public GEAR_CATAGORY gearCatagory
	{
		get { return _gearCatagory; }
		set
		{
			try
			{
				_gearCatagory = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + "	Property set errror!!!");
			}
		}
	}

	public LEGALITY legality
	{
		get { return _legality; }
		set
		{
			try
			{
				_legality = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + "	Property set errror!!!");
			}
		}
	}

	public int quantity // for inventory
	{
		get { return _quantity; }
		set
		{
			try
			{
				_quantity = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + "	Property set errror!!!");
			}
		}
	}

	public int rating
	{
		get { return _rating; }
		set
		{
			try
			{
				_rating = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + "	Property set errror!!!");
			}
		}
	}

	public Skill.SKILL_NAME requiredSkillName
	{
		get { return _requiredSkillName; }
		set
		{
			try
			{
				_requiredSkillName = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + "	Property set errror!!!");
			}
		}
	}

	public bool stackable /// for things like ammo, chips, etc{	
	{
		get { return _stackable; }
		set
		{
			try
			{
				_stackable = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + "	Property set errror!!!");
			}
		}
	}

	public void CGO_Initialize(string namu, GEAR_CATAGORY gC, int co, int avail, LEGALITY leg)
	{
		base.CGO_Initialize(namu);
		gearCatagory = gC;
		cost = co;
		availability = avail;
		legality = leg;
	}

	public virtual void Use()
	{
	}

	/// interface for inheritance	
	public virtual void Use(Ammunition ammo)
	{
	}
	///AmmunitionContainer.ReloadAmmunitionContainer
}