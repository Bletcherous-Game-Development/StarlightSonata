// saves a CyberpunkGameObject to a location. All class instances on the ego MUST be [Serializable]
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public static class SerialSaver
{
    public static void SerialSave(CyberpunkGameObject cgo)
    {
        if (!SaveData.isSaveDataFound)
        {
            Utilities.wrForce("isSaveDataFound = False");
            Utilities.wrErr("<SerialSaver> Error, File Not Found at" + SaveData.FilePath);
            return;
        }

        BinaryFormatter _formatter = new BinaryFormatter();
        FileStream _output;
        try
        {
            string _f = SaveData.FilePath + cgo.CGO_Name;
            if (File.Exists(_f))
            {
                Utilities.wrForce("Overwrite " + cgo.CGO_Name + "? y/n");
                string o = Console.ReadLine();
                if (o == "y")
                {
                    File.Delete(_f);
                }
                else
                {
                    Utilities.wrForce("***<==8_SerialSaving:" + cgo.CGO_Name + "_8==>***");
                    Utilities.wrForce(_f);
                    // open/create the file
                    _output = new FileStream(_f, FileMode.OpenOrCreate, FileAccess.Write);
                    // save it
                    _formatter.Serialize(_output, cgo);
                    _output.Close();
                    Utilities.wrForce("***<==8_SerialSaved:" + cgo.CGO_Name + "_8==>***");
                }
            }
        }
        catch
        {
            Utilities.wrErr("<SerialSaver> SerialSaver.SerialSave error");
            // Utilities.wrErr("<" + this.GetType() + "> Try a new file location, remember to use 'WW not 'W");
            //SaveData.FilePath = Console.ReadLine();
            // recursion call
            //SerialSave(cgo);
        }
    }
}