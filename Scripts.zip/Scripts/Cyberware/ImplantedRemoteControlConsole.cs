using System;

[Serializable]
public class ImplantedRemoteControlConsole : Cyberware
{
    public DataConnector slot = new DataConnector();
    
    public void CGO_Initialize(Device rcc, Augmentation.WARE_GRADE wG)
    {
        augmentationName = Augmentation.AUGMENTATION_NAME.ImplantedRemoteControlConsole;
        base.CGO_Initialize(augmentationName, (4000 + rcc.cost), 1, Gear.LEGALITY.L, wG, 0.3f);
        slot.CGO_Initialize(DataConnector.INTERFACE_TYPE.Slot);
    }
}
