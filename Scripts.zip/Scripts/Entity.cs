using System;
using System.Collections.Generic;
using UnityEngine;
using Random = System.Random;

[Serializable]
public class Entity : CyberpunkGameObject
{
	bool _isDestroyed = false;
	int _woundModifier = 0;
	int _availableEdge = 0;
	int _initiativeDice = 1;
	float _initiativeRoll = 0.0f;
	float _initiativeScore = 0.0f;
	int _karma = 0;
	int _totalKarma = 0;
	int _movement = 0;

	// support variables
	float _rollInitiativeDice = 0.0f;
	public int _resistedNetHits = 0;
	public bool isUnobtainable = false;
	public int supportVar = 0;
	public List<Attribute.ATTRIBUTE_NAME> unobtainableA = new List<Attribute.ATTRIBUTE_NAME>();
	public List<Damage.DAMAGE_TYPE> unobtainableC = new List<Damage.DAMAGE_TYPE>();
	public List<Skill.SKILL_NAME> unobtainableS = new List<Skill.SKILL_NAME>();
	public Damage dam = new Damage();

	public bool isDestroyed
	{
		get { return isDestroyed; }
		set
		{
			try
			{
				isDestroyed = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + " Property set error!!!");
			}
		}
	}

	public int woundModifier
	{
		get
		{
			if (Utilities.isNull(conditionMonitorController))
			{
				Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".conditionMonitorController is null!");
				return 0;
			}

			_woundModifier = 0;
			if (conditionMonitorController.controlledStats.Count > 0)
			{
				foreach (ConditionMonitor conditionMonitor in conditionMonitorController.controlledStats)
				{
					_woundModifier += conditionMonitor.woundModifier;
				}
			}

			return _woundModifier;
		}
	}

	public int availableEdge
	{
		get { return _availableEdge; }
		set
		{
			try
			{
				_availableEdge = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + " Property set error!!!");
			}
		}
	}

	public float initiative // (initiativeRoll + initiativescore) = place in actual initiative!
	{

		get { return initiativeRoll + initiativeScore; }
	}

	public int initiativeDice // xD6
	{
		get { return initiativeDice; }
		set
		{
			try
			{
				initiativeDice = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + " Property set error!!!");
			}
		}
	}

	public float initiativeRoll // comes back from the GM, result of # of initiativeDice rolled by GM
	{
		get { return initiativeRoll; }

		set
		{
			try
			{
				initiativeRoll = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + " Property set error!!!");
			}
		}
	}

	public float initiativeScore // (1 + R or 1 + D) + ERIC
	{
		get
		{
			if (Utilities.isNull(attributeController))
			{
				Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".attributecontroller");
				return 0.0f;
			}

			try
			{
				///ERIC
				_initiativeScore = 0.0f;
				foreach (Attribute a in attributeController.controlledStats)
				{
					if (a.attributeName == Attribute.ATTRIBUTE_NAME.Edge)
					{
						_initiativeScore += a.rank * 1.1f;
					}

					if (a.attributeName == Attribute.ATTRIBUTE_NAME.Intuition)
					{
						_initiativeScore += a.modifiedRank() * 1.001f;
					}

					if (a.attributeName == Attribute.ATTRIBUTE_NAME.Reaction)
					{
						_initiativeScore += a.modifiedRank() * 1.01f;
					}

					if (a.attributeName == Attribute.ATTRIBUTE_NAME.DataProcessing)
					{
						_initiativeScore += a.modifiedRank() * 1.01f;
					}
				}

				_initiativeScore -= woundModifier;
				return _initiativeScore;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + " Property set error!!!");
			}

			return 0.0f;
		}
	}

	public int karma
	{
		get { return _karma; }
		set
		{
			try
			{
				_karma = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + " Property set error!!!");
			}
		}
	}

	public int totalKarma
	{
		get { return _totalKarma; }
		set
		{
			try
			{
				_totalKarma = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + " Property set error!!!");
			}
		}
	}

	public int movement
	{
		get
		{
			// TODO: learn SR6's movement rules, remember fondly SR5's system
			return _movement;
		}
		set
		{
			try
			{
				_movement = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + " Property set error!!!");
			}
		}
	}

	// R+S or weapon
	public int attackRating
	{
		get
		{
			if (Utilities.isNull(attributeController))
			{
				Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".attributecontroller is null!");
				return 0;
			}

			supportVar = 0;
			foreach (Attribute a in attributeController.controlledStats)
			{
				if (a.attributeName == Attribute.ATTRIBUTE_NAME.Reaction)
				{
					supportVar += a.modifiedRank();
				}

				if (a.attributeName == Attribute.ATTRIBUTE_NAME.Strength)
				{
					supportVar += a.modifiedRank();
				}
			}

			return supportVar;
		}
	}

	public int defenseRating // armor+B
	{
		get
		{
			if (Utilities.isNull(attributeController))
			{
				Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".attributeController is null!");
				return 0;
			}

			supportVar = 0;
			foreach (Attribute a in attributeController.controlledStats)
			{
				if (a.attributeName == Attribute.ATTRIBUTE_NAME.Body)
				{
					supportVar += a.modifiedRank();
				}

				if (a.attributeName == Attribute.ATTRIBUTE_NAME.Armor)
				{
					supportVar += a.modifiedRank();
				}
			}

			return supportVar;
		}
	}

	public AttributeController attributeController;
	public ConditionMonitorController conditionMonitorController ;
	public ActiveSkillController activeSkillController ;
	public KnowledgeSkillController knowledgeSkillController;
	public QualityController qualityController;
	public AugmentationController augmentationController;
	public StatusController statusController;
	public ActionController actionController;
	public GearSlotController gearSlotController;
	public ContactController contactController;
	public List<StatController> statControllers;

	public override void CGO_Initialize()
	{
		base.CGO_Initialize();
		SetDestroyed(false);
		attributeController = this.gameObject.AddComponent<AttributeController>();
		Possess(attributeController);
		attributeController.CGO_Initialize(StatController.STAT_CONTROLLER_TYPE.AttributeController.ToString());
		conditionMonitorController = this.gameObject.AddComponent< ConditionMonitorController>();
		Possess(conditionMonitorController);
		conditionMonitorController.CGO_Initialize(StatController.STAT_CONTROLLER_TYPE.ConditionMonitorController.ToString());
		activeSkillController = this.gameObject.AddComponent< ActiveSkillController>();
		Possess(activeSkillController);
		activeSkillController.CGO_Initialize(StatController.STAT_CONTROLLER_TYPE.ActiveSkillController.ToString());
		knowledgeSkillController = this.gameObject.AddComponent< KnowledgeSkillController>();
		Possess(knowledgeSkillController);
		knowledgeSkillController.CGO_Initialize(StatController.STAT_CONTROLLER_TYPE.KnowledgeSkillController.ToString());
		qualityController = this.gameObject.AddComponent< QualityController>();
		Possess(qualityController);
		qualityController.CGO_Initialize(StatController.STAT_CONTROLLER_TYPE.QualityController.ToString());
		augmentationController = this.gameObject.AddComponent< AugmentationController>();
		Possess(augmentationController);
		augmentationController.CGO_Initialize(StatController.STAT_CONTROLLER_TYPE.AugmentationController.ToString());
		statusController = this.gameObject.AddComponent< StatusController>();
		Possess(statusController);
		statusController.CGO_Initialize(StatController.STAT_CONTROLLER_TYPE.StatusController.ToString());
		actionController = this.gameObject.AddComponent< ActionController>();
		Possess(actionController);
		actionController.CGO_Initialize(StatController.STAT_CONTROLLER_TYPE.ActionController.ToString());
		gearSlotController = this.gameObject.AddComponent< GearSlotController>();
		Possess(gearSlotController);
		gearSlotController.CGO_Initialize(StatController.STAT_CONTROLLER_TYPE.GearSlotController.ToString());
		contactController = this.gameObject.AddComponent< ContactController>();
		Possess(contactController);
		contactController.CGO_Initialize(StatController.STAT_CONTROLLER_TYPE.ContactController.ToString());
		SyncStatControllers();
	}

	public void Possess(StatController sCon)
	{
		sCon.SetEntity(this);
		sCon.SetGM(GM);
		AddToStatControllers(sCon);
	}

	public void AddToStatControllers(StatController sCon)
	{
		if (statControllers.Contains(sCon))
		{
			return;
		}

		statControllers.Add(sCon);
	}

	public void SyncStatControllers()
	{
		foreach (StatController sCon in statControllers)
		{
			sCon.SetEntity(this);
			if (sCon.CGO_Name != "")
			{
				sCon.CGO_Initialize(sCon.CGO_Name);
			}

			sCon.CGO_Initialize();
		}
	}

/************** The Call when damaged***************/
	public virtual void ResistDamage(Damage damage, ref DiceRollVariables drv) /// send the damage to the appropriate CondMon
	{
		if (Utilities.isNull(conditionMonitorController))
		{
			Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".conditionMonitorController is null!");
			return;
		}

		foreach (ConditionMonitor c in conditionMonitorController.controlledStats)
		{
			if (c.damageType == damage.damageType)
			{
				ResistDamage(c, damage, ref drv);
			}
		}
	}

/************** The Call when healed******/
	public virtual void RemoveDamage(Damage damage) ///send the damage to the appropriate CondMon
	{
		if (Utilities.isNull(conditionMonitorController))
		{
			Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".conditionMonitorController is null!");
			return;
		}

		foreach (ConditionMonitor c in conditionMonitorController.controlledStats)
		{
			if (c.damageType == damage.damageType)
			{
				RemoveDamage(c, damage);
			}
		}
	}

	public virtual void ResistDamage(ConditionMonitor cm, Damage damage, ref DiceRollVariables drv)
		// Resists damage, sends the rest to the appropriate CondMon for filling boxes
	{
		if (damage.unresisted) // sometimes it is unresisted
		{
			Utilities.wrForce(damage.modifiedDamageValue + " unresisted Damage");
			cm.TakeBoxesOfDamage(damage.modifiedDamageValue);
		}

		{
			/// use the right Attribute
			drv.dicePool = cm.linkedAttribute.modifiedRank();
			Utilities.wrForce(CGO_Name + " Resisting " + damage.modifiedDamageValue + "" + cm.CGO_Name + " with " +
			                  cm.linkedAttribute.CGO_Name + "" + cm.linkedAttribute.modifiedRank());
			CoreMechanics coreMech = new CoreMechanics();
			// make sure drv’s threshold is correct, probably 0, but be sure! 
			_resistedNetHits = coreMech.SimpleTest(ref drv);

			Utilities.wrForce("Resisted " + _resistedNetHits + " Damage");
			// if it rolled under the damage amount, soak up some and take the rest.
			if (_resistedNetHits <
			    damage.modifiedDamageValue)
			{
				damage.damageModifier -= _resistedNetHits;
				cm.TakeBoxesOfDamage(damage.modifiedDamageValue);
			}
			else
			{
//just a flesh wound.
				Utilities.wrForce("Resisted all the damage");
			}
		}
	}

	public virtual void RemoveDamage(ConditionMonitor cm, Damage damage) /// Removes damage, sends to the appropriate CondMon for unfilling boxes{
	{
		cm.RemoveBoxesOfDamage(damage.modifiedDamageValue);
	}

	public void SetDestroyed(bool destroyed)
	{
		isDestroyed = destroyed;
	}

	public virtual void SetControllableStats()
	{
	}

	public virtual void SetAttributes()
	{
	}

	public virtual void SetConditionMonitors()
	{
	}

	public virtual void SetSkills()
	{
	}

	public virtual void RollInitiativeDice(Random rN) // Rolls initiative Dice, uses ERIC, trying for max randomness
	{
		Random rando = rN;
		_rollInitiativeDice = 0.0f;
		for (int roll = 1; roll <= initiativeDice; ++roll)
		{
			int i = rando.Next(1, 7);
			Utilities.wrForce(CGO_Name + " Rolled:" + i);
			_rollInitiativeDice += i;
		}

		///ERIC “
		int ii = rando.Next(1, 10);
		_rollInitiativeDice += ii * 0.0001f;
		ii = rando.Next(1, 10);
		_rollInitiativeDice += ii * 0.00001f;
		initiativeRoll = _rollInitiativeDice;
	}

	public void ResetAvailableEdge()
	{
		if (Utilities.isntNull(attributeController))
		{
			foreach (Attribute a in attributeController.controlledStats)
			{
				if (a.attributeName == Attribute.ATTRIBUTE_NAME.Edge)
				{
					availableEdge = a.rank;
				}
			}
		}
	}

	public void UseAvailableEdge(ref DiceRollVariables drv) // Prompts for uses of Edge on Dice Rolls
	{
		if (availableEdge > 0)
		{
			Utilities.wrForce(CGO_Name + " use sixesExplode Edge Boost? y / n");
			if (Console.ReadLine() == "y")
			{
				drv.sixesExplode = true;
				--availableEdge;
				Utilities.wrForce(CGO_Name + " availableEdge:" + availableEdge);
			}
		}
	}

	public void DecreaseKarma(int amount) // for stat increases

	{
		if (karma >= amount)
		{
			karma -= amount;
		}
		else
		{
			Utilities.wrErr("<" + this.GetType() + "> Not enough karma");
		}


		Utilities.wrForce("spending " + amount + " karma, karma now at" + karma);
	}

	public void IncreaseKarma(int amount) // winning!
	{
		karma += amount;
		totalKarma += amount;
		Utilities.wrForce("Got" + amount + " more karma");
		Utilities.wrForce("karma at" + karma);
		Utilities.wrForce("totalKarma at" + totalKarma);
	}
}