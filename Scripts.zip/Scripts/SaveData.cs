//The SaveData location
public static class SaveData
{
    public static string FilePath = "C:\\Users\\koryb\\Files\\StarlightSonata\\SaveData\\";
    //C:\Users\koryb\Files\StarlightSonata\SaveData
    public static bool isSaveDataFound = false;
}