using System;

[Serializable]
public class ActiveSkillController : StatController
{
    public override void CGO_InitializeControllableStats()
    {
    }
}