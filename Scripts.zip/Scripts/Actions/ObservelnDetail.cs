using System;

[Serializable]
public class ObserveInDetail : Action
{
    DiceRollVariables drv = new DiceRollVariables();
    CoreMechanics coreMech = new CoreMechanics();

    public override void InitiateAction()
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        Utilities.wr("***<==8_ObservelnDetail_8==>***");
        if (TimeAndTypeCheck())
        {
            drv = new DiceRollVariables();
            foreach (Skill s in entity.activeSkillController.controlledStats)
            {
                if (s.skillName == Skill.SKILL_NAME.Perception)
                {
                    drv.dicePool += s.modifiedRank();
                }
            }

            foreach (Attribute a in entity.attributeController.controlledStats)
            {
                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Intuition)
                {
                    drv.dicePool += a.modifiedRank();
                }
            }

            drv.dicePool -= entity.woundModifier;
            coreMech = new CoreMechanics();
            Utilities.wrForce("ObservelnDetail:" + coreMech.SimpleTest(ref drv));
        }
    }
}