// Bioware, Cyberware, Geneware, Nanoware, etc. // TODO: needs a game Effect, right now it is equippable and essenceCost is calculated.{
using System;
using System.Collections.Generic;

[Serializable]
public class Augmentation : Gear
{
    private float _essenceCost = 0.0f;
    AUGMENTATION_NAME _augmentationName = AUGMENTATION_NAME.Undefined;
    WARE_TYPE _wareType = WARE_TYPE.Undefined;
    WARE_GRADE _wareGrade = WARE_GRADE.Undefined;

    public enum AUGMENTATION_NAME
    {


// Headware
        Datajack,
        ImplantedRemoteControlConsole,
        Skilljack,
        ControlRig,
        MedullanParallelProcessors,
        SimsenselnterfaceOverdrive,

// Eyeware
        CyberEye,

// Earware
        CyberEar,
        Antanae,

// CyberLimbs
        Cyberarm,
        Cyberleg,
        Cyberskull,
        Cybertorso,

// Bodyware
        Bonelacing,
        WiredReflexes,
        Undefined
    }

    public enum WARE_TYPE
    {
        Bioware,
        Cyberware,
        Geneware,
        Undefined
    }

    public enum WARE_GRADE
    {
        Standard,
        Alpha,
        Beta,
        Delta,
        Gamma,
        Used,
        Undefined
    }

    public Dictionary<WARE_GRADE, float> essenceModifiers = new Dictionary<WARE_GRADE, float>();
    public Dictionary<WARE_GRADE, float> costModifiers = new Dictionary<WARE_GRADE, float>();
    public Dictionary<WARE_GRADE, int> availabilityModifiers = new Dictionary<WARE_GRADE, int>();

    public AUGMENTATION_NAME augmentationName
    {
        get { return _augmentationName; }
        set
        {
            try
            {
                _augmentationName = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public WARE_TYPE wareType
    {
        get { return _wareType; }
        set
        {
            try
            {
                _wareType = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public WARE_GRADE wareGrade
    {

        get { return _wareGrade; }
        set
        {
            try
            {
                _wareGrade = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public float essenceCost
    {
        get { return (_essenceCost * essenceModifiers[wareGrade] * -1); }
        set
        {
            try
            {
                _essenceCost = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public override int cost
    {
        get { return ((int)((float)base.cost * costModifiers[wareGrade])); }
        set
        {
            try
            {
                base.cost = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public override int availability
    {
        get
        {
            if ((base.availability += availabilityModifiers[wareGrade]) < 0)
            {
                return 0;
            }

            return (base.availability += availabilityModifiers[wareGrade]);
        }
        set
        {
            try
            {
                base.availability = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public void CGO_Initialize(AUGMENTATION_NAME aN, int co, int avail, LEGALITY leg, WARE_GRADE grade, WARE_TYPE type,
        float essCost)
    {
        augmentationName = aN;
        base.CGO_Initialize(augmentationName.ToString(), Gear.GEAR_CATAGORY.Augmentation, co, avail, leg);
        wareGrade = grade;
        wareType = type;
        essenceCost = essCost;
        SetGradeModifiers();
        GameEffect();
    }

    public virtual void GameEffect()
    {
        if (Utilities.isNull(entity))
        {
            return;
        }

        if (Utilities.isNull(entity.attributeController))
        {
            return;
        }

        foreach (Attribute a in entity.attributeController.controlledStats)
        {
            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Essence)
            {
                Modifier m = new Modifier((CGO_Name + "_essenceCost"), essenceCost);
                a.modifiers.Add(m);
            }
        }
    }

    public void SetGradeModifiers()
    {
        essenceModifiers.Add(WARE_GRADE.Standard, 1.0f);
        essenceModifiers.Add(WARE_GRADE.Alpha, 0.9f);
        essenceModifiers.Add(WARE_GRADE.Beta, 0.7f);
        essenceModifiers.Add(WARE_GRADE.Delta, 0.5f);
        essenceModifiers.Add(WARE_GRADE.Gamma, 0.4f);
        essenceModifiers.Add(WARE_GRADE.Used, 1.5f);
        costModifiers.Add(WARE_GRADE.Standard, 1.0f);
        costModifiers.Add(WARE_GRADE.Alpha, 1.2f);
        costModifiers.Add(WARE_GRADE.Beta, 1.5f);
        costModifiers.Add(WARE_GRADE.Delta, 2.5f);
        costModifiers.Add(WARE_GRADE.Gamma, 0.4f);
        costModifiers.Add(WARE_GRADE.Used, 0.5f);
        availabilityModifiers.Add(WARE_GRADE.Standard, 0);
        availabilityModifiers.Add(WARE_GRADE.Alpha, 1);
        availabilityModifiers.Add(WARE_GRADE.Beta, 2);
        availabilityModifiers.Add(WARE_GRADE.Delta, 3);
        availabilityModifiers.Add(WARE_GRADE.Gamma, 5);
        availabilityModifiers.Add(WARE_GRADE.Used, -1);
    }
}