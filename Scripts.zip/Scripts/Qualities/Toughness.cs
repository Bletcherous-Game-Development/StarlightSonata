using System;

[Serializable]
public class Toughness : Quality
// needs accurate karmaCost
// // TODO, uses CM.IncreaseWoundModifierThreshold
{
    Damage.DAMAGE_TYPE _damageType = Damage.DAMAGE_TYPE.Undefined;

    public Damage.DAMAGE_TYPE damageType
    {
        get { return _damageType; }
        set
        {
            try
            {
                _damageType = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public void CGO_Initialize(Quality.QUALITY_NAME qN, Damage.DAMAGE_TYPE dT)
    {
        SetQualityType(QUALITY_TYPE.Positive);
        SetKarmaCost(5);
        damageType = dT;
        base.CGO_Initialize(qN);
        SetName((qualityName.ToString() + "(" + damageType.ToString() + ")"));
    }

    public override void GameEffect()
    {
        if (Utilities.isNull(entity))
        {
            return;
        }

        if (Utilities.isNull(entity.conditionMonitorController))
        {
            return;
        }

        foreach (ConditionMonitor c in entity.conditionMonitorController.controlledStats)
        {
            if (c.damageType == damageType)
            {
                c.woundModifierThreshold = 4;
            }
        }
    }

    public override void ReverseEffect()
    {
        if (Utilities.isNull(entity))
        {
            return;
        }

        if (Utilities.isNull(entity.conditionMonitorController))
        {
            return;
        }

        foreach (ConditionMonitor c in entity.conditionMonitorController.controlledStats)
        {
            if (c.damageType == damageType)
            {
                c.woundModifierThreshold = 3;
            }
        }

        base.ReverseEffect();
    }
}