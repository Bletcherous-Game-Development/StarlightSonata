using System;

[Serializable]
public class RiggerJumpIn : Action
{
    public override void InitiateAction()
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        Utilities.wr("***<==8_RiggerJumpIn_8==>***");
        if (TimeAndTypeCheck())
        {
        }
    }
}