using System;
using System.Collections;
using System.Collections.Generic;
using static System.Console;

public static class Utilities
{
    // does optimized null checks, generic messaging service, sends to Console.WriteLine()
    public static bool LOGGING_ON = false;

    public static void wrForce(string s)
    {
        Console.WriteLine(s);

    }

    public static void wrForce()
    {
        Console.WriteLine();
    }

    public static void wr()
    {
        if (LOGGING_ON)
        {
            Console.WriteLine();
        }
    }

    public static void wr(string s)
    {
        if (LOGGING_ON)
        {
            Console.WriteLine(s);

        }

    }

    public static void wr(string s, string sClass, string sMethod, string sNote)
    {
        if (LOGGING_ON)
        {
            Console.WriteLine(sClass + " " + sMethod + " " + sNote + " " + s);
        }
    }

    public static void wrErr(string s) // TODO: add all errors to a list and append them to a text file
    {
        Console.WriteLine("<" + s + ">");
    }

    public static void wrErr(string s, string sClass, string sMethod, string sNote)
    {
        if (LOGGING_ON)
        {
            Console.WriteLine("<" + sClass + "." + sMethod + " " + sNote + " " + s + ">");

        }
    }

    public static bool isntNull(object obj)
    {
        if (!System.Object.ReferenceEquals(obj, null))
        {
            // do stuff, it isn't null
            return true;
        }

        return false;
    }

    public static bool isNull(object obj)
    {
        if (System.Object.ReferenceEquals(obj, null))
        {
            // stop its null
            return true;
        }

        return false;
    }
}
