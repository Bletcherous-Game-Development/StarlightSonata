using System;

[Serializable]
public class CyberEar : Cyberware
{
    public void CGO_Initialize(Augmentation.WARE_GRADE wG)
    {
        augmentationName = Augmentation.AUGMENTATION_NAME.CyberEye;
        base.CGO_Initialize(augmentationName, 1000, 1, Gear.LEGALITY.L, wG, 1.0f);
    }
}