using System;
using System.Collections.Generic;

[Serializable] public class AttributeController: StatController{
public Attribute.ATTRIBUTE_NAME[] bespokeAttributes = new Attribute.ATTRIBUTE_NAME[3];
public override void CGO_InitializeControllableStats(){}
public void SetBespokeAttributes(Attribute.ATTRIBUTE_NAME[] bA){
    if(bA. Length == 3){
        bespokeAttributes = bA;}}
public void LimitBespokeAttributes(){
    int[] bA = new int[]{8,8,5};
    for(int i = 0; i < bespokeAttributes.Length; ++i){
        foreach(Attribute a in controlledStats){
            if(a.attributeName == bespokeAttributes[i]){
                a.SetRankLimit(bA[i]);}}}
/*
bespokeAttributes[0].SetRankLimit(8);
bespokeAttributes[1].SetRankLimit(8);
bespokeAttributes[2].SetRankLimit(5);
*/}}