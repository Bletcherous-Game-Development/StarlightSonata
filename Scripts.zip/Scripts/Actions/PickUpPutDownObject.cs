using System;

[Serializable]
public class PickUpPutDownObject : Action
{
    public override void InitiateAction(GearSlot slot, Gear gear)
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        Utilities.wr("***<==8_PickUpObject_8==>***");
        // If stowing or slotting use gearSlots initially it will get slotted in R/L Hand. Remember: DropObject is a different Action
        if (!Utilities.isntNull(slot.slottedGear))
        {
            if (TimeAndTypeCheck())
            {
                // If the slot is empty, pick up the gear, else if it already has a gear, put down what it is holding and pick up the new gear
                entity.gearSlotController.SlotGear(slot, gear);
            }
        }
        else
        {
            if (TimeAndTypeCheck())
            {
                Utilities.wr("***<==8_SwapObjects_8==>***");
                entity.gearSlotController.UnSlotGear(slot);
                entity.gearSlotController.SlotGear(slot,gear);
            }
        }
    }

// TODO: instanciate the gear onto a surface, bend down to set it down onto something
    public override void InitiateAction(GearSlot slot)
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        Utilities.wr("***<==8_PutDownObject_8==>***");
        if (Utilities.isntNull(slot.slottedGear))
        {
            if (TimeAndTypeCheck())
            {
                entity.gearSlotController.UnSlotGear(slot);
            }
        }
    }

// TODO: detect surfaces to put objects onto.}}}
    public override void InitiateAction(GearSlot slot0, GearSlot slot1)
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        Utilities.wr("***<==8_MoveObject_8==>***");
        ///from slot0 to slot1
        if (Utilities.isntNull(slot0.slottedGear) && !Utilities.isntNull(slot1.slottedGear))
        {
            if (TimeAndTypeCheck())
            {
                entity.gearSlotController.SlotGear(slot1, slot0.slottedGear);
                entity.gearSlotController.UnSlotGear(slot0);
            }
        }
    }
}