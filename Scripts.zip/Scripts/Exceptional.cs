using System;

[Serializable]
public class Exceptional : Quality
{
    Attribute.ATTRIBUTE_NAME _attributeName = Attribute.ATTRIBUTE_NAME.Undefined;

    public Attribute.ATTRIBUTE_NAME attributeName
    {
        get { return _attributeName; }
        set
        {
            try
            {
                _attributeName = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public void CGO_Initialize(Quality.QUALITY_NAME qN, Attribute.ATTRIBUTE_NAME aN)
    {
        attributeName = aN;
        SetKarmaCost(12);
        base.CGO_Initialize(qN.ToString());
        SetName((qualityName.ToString() + "" + attributeName.ToString() + ")"));
        SetQualityType(QUALITY_TYPE.Positive);
    }

    public override void GameEffect()
    {
        if (Utilities.isNull(entity))
        {
            return;
        }

        if (Utilities.isNull(entity.attributeController))
        {
            return;
        }

        foreach (Attribute a in entity.attributeController.controlledStats)
        {
            if (a.attributeName == attributeName)
            {
                a.AddAptitudeOrException();
                break;
            }
        }
    }

    public override void ReverseEffect()
    {
        base.ReverseEffect();
    }
}