// tracks game states, initiative, environmental factors, etc. Needs to be a Singleton in Unity

using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class GameMaster : MonoBehaviour
{
	bool _isActive = false;
	bool _verbose = false;

	public bool isActive
	{
		get { return _isActive; }
		set
		{
			try
			{
				isActive = value;
			}
			catch
			{
				Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
			}
		}
	}

	public bool SaveFileLocation() /// checks the save location
	{
		if (File.Exists(SaveData.FilePath + "\\Found.txt"))
		{
			Utilities.wrForce("SaveData found at: " + SaveData.FilePath);
			if (_verbose)
			{
				try
				{
					string[] files = Directory.GetFiles(SaveData.FilePath);
					if (files.Length > 0)
					{
					
						string[] playerNames = new string[files.Length];
						for (int i = 0; i < files.Length; ++i)
						{
							string[] pieces = files[i].Split("\\");
							playerNames[i] = pieces[pieces.Length - 1];
							Utilities.wrForce(i + " + pieces[pieces. Length -1 ]");

						}

					}


				}
				catch
				{
					Console.WriteLine("verbose error in GM.SaveFileLocation");
				}
			}

			SaveData.isSaveDataFound = true;
			return true;

		}

		Utilities.wrErr("<" + this.GetType() + "> SaveData NOT found at:" + SaveData.FilePath);
		SaveData.isSaveDataFound = false;
		return false;
	}

	public List<CyberpunkGameObject> CGOs = new List<CyberpunkGameObject>();

	public void GM_lnitialize()
	{
		// set up~the SaveData, game stuff, level loading, whatever.
		Activate();

	}

	public void Activate() // set up the SaveData

	{
		if (isActive)
		{
			return;

		}

		//Utilities.wr("<GameMaster> Activate()");
		if (!SaveFileLocation())
		{
			Utilities.wrErr("<" + this.GetType() + "> GameMaster: Cant find save Location!!!");
			return;

		}

		SetActive(true);
		Utilities.wrForce("<GameMaster> Activated");
	}

	public void Deactivate()
	{
		if (!isActive)
		{
			return;

		}

		Utilities.wrForce("<GameMaster> Deactivated");
		SetActive(false);
		CGO_DeactivateAII();
		CGOs.Clear();

	}

	public void SetActive(bool active)
	{
		isActive = active;

	}

	public void StartGame()
	{
		if (!isActive)
		{
			return;

		}

		// the GAME LOOP!
		GameLoop();

	}

	void GameLoop()
	{
		if (!isActive)
		{
			return;

		}

		Utilities.wr("<GameMaster> GameLoop()");
		CGO_ActivateAII();

	}

	public void GM(CyberpunkGameObject cgo)
	{
		cgo.SetGM(this);

	}

	public void AddToCGOs(CyberpunkGameObject cgo)
	{

		if (CGOs.Contains(cgo))
		{
			return;

		}

		CGOs.Add(cgo);

	}

	public void CGO_ActivateAII()
	{
		if (!isActive)
		{
			return;

		}

		if (CGOs.Count <= 0)
		{
			Utilities.wrErr("<GameMaster> CGOs is empty!!!");
			return;

		}

		Utilities.wrForce("<GameMaster> CGO_ActivateAII()");
		foreach (CyberpunkGameObject cgo in CGOs)
		{
			GM(cgo);
			cgo.SetActive(true);
			Utilities.wrForce(cgo.CGO_Name);

		}

	}


	public void CGO_DeactivateAII()
	{
		if (CGOs.Count <= 0)
		{
			Utilities.wr("<GameMaster> CGOs is empty!!!");
			return;
		}

		Utilities.wr("<GameMaster> CGO_DeactivateAII()");
		foreach (CyberpunkGameObject cgo in CGOs)
		{
			cgo.GM = null;
			cgo.SetActive(false);
		}
	}

	public CyberpunkGameObject Instantiate(CyberpunkGameObject cgo)
	{
		cgo.CGO_Initialize(this);
		AddToCGOs(cgo);
		return cgo;
	}

	/******************************************************************************/
	public enum GAME_TIME
	{
		Exploration,
		initiative,
		Narration,
		Paused,
		Undefined
	}

	GAME_TIME _gameTime = GAME_TIME.Undefined;
	int _currentInitiativeRound = 1;
	Entity _entityWhoseTurnItIs;
	int _currentTurn = 0;
	public List<Entity> initiativeGroup = new List<Entity>();
	public Entity[] initiativeOrder = new Entity[] { };

	public GAME_TIME gameTime
	{
		get { return _gameTime; }
		set
		{
			try
			{
				_gameTime = value;
			}
			catch
			{
			}
		}
	}

	public int currentlnitiativeRound
	{
		get { return _currentInitiativeRound; }
		set
		{
			try
			{
				_currentInitiativeRound = value;
			}
			catch
			{
			}
		}
	}

	public Entity entityWhoseTurnItIs
	{
		get { return _entityWhoseTurnItIs; }
		set
		{
			try
			{
				_entityWhoseTurnItIs = value;
			}
			catch
			{
			}
		}
	}

	public int currentTurn
	{
		get { return _currentTurn; }
		set
		{
			try
			{
				_currentTurn = value;
			}
			catch
			{

			}
		}
	}

	public void Surprise()
	{
		Utilities.wr("> Surprise");
		CoreMechanics coreMech = new CoreMechanics();
		foreach (Entity entity in initiativeGroup)
		{
			if(entity.actionController.unaware)
			{
				Utilities.wrForce(entity.CGO_Name + " is unaware");
				entity.actionController.unaware = false;

				DiceRollVariables drv = new DiceRollVariables();
				drv.threshold = 3;
				drv.dicePool = 0;
				foreach (Attribute a in entity.attributeController.controlledStats)
				{
					if (a.attributeName == Attribute.ATTRIBUTE_NAME.Reaction)
					{
						drv.dicePool += a.modifiedRank();
					}

					if (a.attributeName == Attribute.ATTRIBUTE_NAME.Intuition)
					{
						drv.dicePool += a.modifiedRank();
					}
				}

				drv.dicePool -= entity.woundModifier;
				int result = coreMech.SimpleTest(ref drv);
				Utilities.wrForce("Results of Surprise:" + result);
				if (result >= 0)
				{
					drv.success = true;
					entity.actionController.surprised = false;
					Utilities.wrForce(entity.CGO_Name + " is not surprised");
				}
				else
				{
					entity.actionController. surprised = true;
					Utilities.wrForce(entity.CGO_Name + " is surprised");
				}
			}
			else
			{
				Utilities.wrForce(entity.CGO_Name + " is not unaware");
			}
		}
	}

	public void RolllnitiativeDice()
	{
		Utilities.wr("> RolllnitiativeDice");
		 System.Random randomNumbers = new System.Random();
		foreach (Entity entity in initiativeGroup)
		{
			entity.RollInitiativeDice(randomNumbers);
		}

		Sortlnitiative();
	}

	public void Sortlnitiative()
	{
		Utilities.wr("> Sortinitiative");
		List<float> tempOrder = new List<float>();
		foreach (Entity entity in initiativeGroup)
		{
			tempOrder.Add(entity.initiative);
			Utilities.wrForce(entity.CGO_Name + "'s initiative:" + entity.initiative);
		}

		tempOrder.Sort();
		initiativeOrder = new Entity[tempOrder.Count];
		int i = tempOrder.Count - 1;
		foreach (float f in tempOrder)
		{
			foreach (Entity entity in initiativeGroup)
			{
				if(entity.initiative == f);
				{
					initiativeOrder[i] = entity;
					--i;
				}
			}
		}

		Displaylnitiative();
	}

	public void Displaylnitiative()
	{
		for (int j = 0; j < initiativeOrder.Length; ++j)
		{
			int k = j + 1;
			Utilities.wrForce(k + " " + initiativeOrder[j].CGO_Name + " at" + initiativeOrder[j].initiative);
		}
	}

	public void Activatelnitiative()
	{
		Utilities.wr("> Activatelnitiative");
		Surprise();
		RolllnitiativeDice();
		currentlnitiativeRound = 0;
		ActivateNewRound();
	}

	public void ActivateNewRound()
	{
		Utilities.wr("> ActivateNewRound");
		foreach (Entity entity in initiativeGroup)
		{
			entity.actionController.ResetCurrentActions();
		}

		++currentlnitiativeRound;
		currentTurn = 0;
		Sortlnitiative();
		if (initiativeOrder.Length > 0)
		{
			Utilities.wrForce("Activateing Round " + currentlnitiativeRound);
			ActivateNewTurn();
		}
	}

	public void ActivateNewTurn()
	{
		Utilities.wr("> ActivateNewTurn");
		entityWhoseTurnItIs = initiativeOrder[currentTurn];
		Utilities.wrForce("Entity Whose Turn It Is:" + entityWhoseTurnItIs.CGO_Name);
		if (entityWhoseTurnItIs.actionController.surprised)
		{
			Utilities.wrForce(entityWhoseTurnItIs.CGO_Name + " is surprised!");
			entityWhoseTurnItIs.actionController.currentMajorActions = 0;
			entityWhoseTurnItIs.actionController.currentMinorActions = 0;
		}

		Utilities.wrForce("currentMajorActions:" + entityWhoseTurnItIs.actionController.currentMajorActions);
		Utilities.wrForce("currentMinorActions:" + entityWhoseTurnItIs.actionController.currentMinorActions);
	}

	public void EndOfTurn()
	{
		Utilities.wr("> EndOfTurn");
		int maxTurn = initiativeOrder.Length - 1;
		++currentTurn;
		if (currentTurn <= maxTurn)
		{
			ActivateNewTurn();
		}

		if (currentTurn > maxTurn)
		{
			EndOfRound();
		}
	}

	public void EndOfRound()
	{
		Utilities.wr("> EndOfRound");
		foreach (Entity entity in initiativeGroup)
		{
			if(entity.actionController.surprised){
				entity.actionController.surprised = false;
			}
		}

		ActivateNewTurn();
	}
}
