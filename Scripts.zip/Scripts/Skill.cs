//needs work for exoticWeapons
using System;
using System.Collections.Generic;

[Serializable]
public class Skill : RankedStat
{
    bool _untrained = false;
    SKILL_SPECIALIZATION _specialization = SKILL_SPECIALIZATION.Undefined;
    SKILL_SPECIALIZATION _expertise = SKILL_SPECIALIZATION.Undefined;
    Attribute _linkedAttribute;
    Attribute _secondaryAttribute;
    Attribute _matrixAttribute;
    SKILL_NAME _skillName = SKILL_NAME.Undefined;

    public enum SKILL_NAME
    {
        Athletics,
        Biotech,
        CloseCombat,
        Con,
        Cracking,
        Electronics,
        Engineering,
        ExoticWeapons,
        Firearms,
        Influence,
        Outdoors,
        Perception,
        Piloting,
        Stealth,
        Undefined
    }

    public enum SKILL_SPECIALIZATION
    {
        ///athletics

        Archery,
        Climbing,
        Flying,
        Gymnastics,
        Sprinting,
        Swimming,
        Throwing,

        ///biotech
        Biotechnology,
        Cybertechnology,
        FirstAide,
        Medicine,

        ///closeCombat
        Blades,
        Clubs,
        UnarmedCombat,

        ///con
        Acting,
        Disguise,
        Impersonation,
        Performance,

        ///cracking
        CyberCombat,
        ElectronicWarfare,
        Hacking,

        ///electronics
        Computer,
        Hardware,
        Software,

        ///engineering
        AeronauticsMechanic,
        Armorer,
        AutomotiveMechanic,
        Demolitions,
        Gunnery,
        IndustrialMechanic,
        Lockpicking,
        NauticalMechanic,

        ///exoticWeapons
        CombatChainsaw,
        GrappleGun,
        GrenadeLauncher,
        MonofilamentWhip,
        TubeLauncher,

        ///firearms
        Automatics,
        Longarms,
        Pistols,
        Rifles,
        Shotguns,

        ///influence
        Etiquette,
        Instruction,
        Intimidation,
        Leadership,
        Negotiation,

        ///outdoors
        Navigation,
        Survival,
        TrackingArctic,
        TrackingDesert,
        TrackingJungle,
        TrackingUrban,
        TrackingWoods,

        ///perception
        Aural,
        Tactile,
        Visual,
        ByEnvironmentArctic,
        ByEnvironmentDesert,
        ByEnvironmentJungle,
        ByEnvironmentUrban,
        ByEnvironmentWoods,

        //piloting
        GroundCraft,
        Aircraft,
        Watercraft,

        //stealth
        // TODO: Disguise,
        Camouflage,
        Palming,
        Sneaking,

        //
        Undefined
    }

    public List<SKILL_SPECIALIZATION> specializations = new List<SKILL_SPECIALIZATION>();

    public bool untrained
    {
        get { return _untrained; }
        set
        {
            try
            {
                _untrained = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public SKILL_SPECIALIZATION specialization
    {
        get { return _specialization; }
        set
        {
            try
            {
                _specialization = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public SKILL_SPECIALIZATION expertise
    {
        get { return _expertise; }
        set
        {
            try
            {
                _expertise = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public Attribute linkedAttribute
    {
        get { return linkedAttribute; }
        set
        {
            try
            {
                _linkedAttribute = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public Attribute secondaryAttribute
    {
        get { return _secondaryAttribute; }
        set
        {
            try
            {

                _secondaryAttribute = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public Attribute matrixAttribute
    {
        get { return _matrixAttribute; }
        set
        {
            try
            {
                _matrixAttribute = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public SKILL_NAME skillName
    {
        get { return _skillName; }
        set
        {
            try
            {
                _skillName = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public void CGO_Initialize(SKILL_NAME sN, Attribute IA, bool uT)
    {
        SetSkillName(sN);
        SetName(skillName.ToString());
        base.CGO_Initialize();
        SetLinkedAttribute(IA);
        SetUntrained(uT);
    }

    public void SetSkillName(SKILL_NAME sN)
    {
        skillName = sN;
    }

    /*
    Note for Exotic Weapon:
    Add every weapon that uses the skill
    and a second list for purchased specializations. Ignore the
    specialization and expertise.
    Note for actions, Skill Use:
    Get a list of all the Skill specializations
    and check to see if a entity is doing an Action that can be Specialized in,
    if so give him the bonus.
    */
    public void SetLinkedAttribute(Attribute IA)
    {
        linkedAttribute = IA;
    }

    public void SetUntrained(bool uT)
    {
        untrained = uT;
    }

    public void AddToSkillSpecializations(SKILL_SPECIALIZATION spec)
    {
        if (specializations.Contains(spec))
        {
            return;
        }

        specializations.Add(spec);
    }

    public void AddSpecialization(SKILL_SPECIALIZATION sSpec, bool isCharCreation = false)
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        if (!isCharCreation)
        {
            if (entity.karma < 5)
            {
                Utilities.wrForce("<" + this.GetType().Name + ".AddSpecialization: " + CGO_Name +
                                  ".entity doesnt have enough karma!");
                return;
            }

            entity.DecreaseKarma(5);
        }

        if (specialization == SKILL_SPECIALIZATION.Undefined)
        {
            specialization = sSpec;
        }
    }

    public void AddExpertise(bool isCharCreation = false)
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        if (!isCharCreation)
        {
            if (entity.karma < 5)
            {
                Utilities.wrForce("<" + this.GetType().Name + ".AddExpertise:" + CGO_Name +
                                  ".entity doesnt have enough karma!");
                return;
            }

            entity.DecreaseKarma(5);
        }

        if (expertise == SKILL_SPECIALIZATION.Undefined && specialization != SKILL_SPECIALIZATION.Undefined)
        {
            expertise = specialization;
            specialization = SKILL_SPECIALIZATION.Undefined;
        }
    }
}