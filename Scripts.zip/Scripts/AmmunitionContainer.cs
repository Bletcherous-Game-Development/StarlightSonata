//Stores stats for Clips, Magazines, etc
using System;

[Serializable]
public class AmmunitionContainer : Gear
{

    RangedWeapon.AMMUNITION_CONTAINER_TYPE _ammunitionContainerType =
        RangedWeapon.AMMUNITION_CONTAINER_TYPE.Clip;

    Weapon.WEAPON_TYPE _weaponType = Weapon.WEAPON_TYPE.HoldoutPistol;
    private int _ammunitionCapacity = 0;
    Ammunition _containedAmmunition;

    RangedWeapon.RANGED_WEAPON_DESIGNATION _designation = RangedWeapon.RANGED_WEAPON_DESIGNATION.Undefined;

// support variables
    bool _load = false;
    int _amountToLoad = 0;

    public RangedWeapon.AMMUNITION_CONTAINER_TYPE ammunitionContainerType
    {
        get { return _ammunitionContainerType; }
        set { _ammunitionContainerType = value; }
    }

    public Weapon.WEAPON_TYPE weaponType
    {
        get { return _weaponType; }
        set { _weaponType = value; }
    }

    public int ammunitionCapacity
    {
        get { return _ammunitionCapacity; }
        set { _ammunitionCapacity = value; }
    }

    public Ammunition containedAmmunition
    {
        get { return _containedAmmunition; }
        set { _containedAmmunition = value; }
    }

    public RangedWeapon.RANGED_WEAPON_DESIGNATION designation
    {
        get { return _designation; }
        set { _designation = value; }
    }

    public int currentAmmunitionCount
    {
        get
        {
            if (Utilities.isNull(containedAmmunition))
            {
                return 0;
            }

            return containedAmmunition.quantity;
        }
        set
        {
            if (Utilities.isntNull(containedAmmunition))
            {
                containedAmmunition.quantity = value;
            }
        }
    }

    public override void CGO_Initialize()
    {
        base.CGO_Initialize();
        quantity = 1;
    }

// for loading the right ammo into the right clip for the right weapon
    public void ReloadAmmunitionContainer(Ammunition ammo)
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        Utilities.wr("***<==8_ReloadAmmunition_Container_8==>***");
        _load = false;
        if (ammo.weaponType == weaponType)
        {
            if (ammo.quantity > 0)
            {
                if (currentAmmunitionCount < ammunitionCapacity)
                {
                    _load = true;
                    if (Utilities.isntNull(containedAmmunition))
                    {
// there is already ammunition in the container, make sure the variety matches

                        if (ammo.AmmunitionVariety != containedAmmunition.AmmunitionVariety)
                        {
                            _load = false;
                        }
                        else
                        {
                            _load = true;
                        }
                    }
                    else
                    {
                        ///no containedAmmunition, make a copy of ammunition before transfering quantity.
                        containedAmmunition = new Ammunition();
                        containedAmmunition.SetName((ammo.weaponType.ToString() +
                                                     ammo.AmmunitionVariety.ToString() + "ammunition"));
                        containedAmmunition.CGO_Initialize(containedAmmunition.CGO_Name,
                            ammo.cost, ammo.availability, ammo.legality, ammo.weaponType, ammo.AmmunitionVariety);
                        currentAmmunitionCount = 0;
                    }

                    if (_load)
                    {
                        _amountToLoad = ammunitionCapacity - currentAmmunitionCount;
                        if (_amountToLoad > 0)
                        {
                            if (ammo.quantity < _amountToLoad)
                            {
                                _amountToLoad = ammo.quantity;
                                ammo.quantity = 0;
// TODO: destroy ammunition
                            }
                            else
                            {
                                ammo.quantity -= _amountToLoad;
                            }

                            currentAmmunitionCount += _amountToLoad;
                            Utilities.wrForce("amount Loaded:" + _amountToLoad);
                        }
                    }
                    else
                    {
                        Utilities.wrErr("<" + this.GetType() + "> AmmunitionVariety doesn't match");
                    }
                }
                else
                {
                    Utilities.wrErr("<" + this.GetType() + "> AmmunitionContainer" + CGO_Name + " is full");
                }
            }
            else
            {
                Utilities.wrErr("<" + this.GetType() + "> ammunition " + ammo.CGO_Name +
                                " is empty or negative for some reason");
            }
        }
        else
        {
            Utilities.wrErr("<" + this.GetType() + "> Wrong weaponType");
        }
    }

// Gear.Use() interface for other objects to access a poece of gear's functionality
    public override void Use(Ammunition ammunition)
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        ReloadAmmunitionContainer(ammunition);
    }
}
