// Parent class for weapons /// TODO: add variables to relevantAR distances oIika hpsr ptp /
using System;
using System.Collections.Generic;

[Serializable]
public class Weapon : Gear 
{
    WEAPON_CATAGORY _weaponCatagory = WEAPON_CATAGORY.Undefined;
    WEAPON_TYPE _weaponType = WEAPON_TYPE.Undefined;
    Damage _weaponDamage = new Damage();
    Damage _modifiedDamage = new Damage();
    bool _readied = false;
    int _maxRange = 0;
    int _currentModifications = 0;
    int _maxModifications = 0;
    Skill.SKILL_SPECIALIZATION _specialization = Skill.SKILL_SPECIALIZATION.Undefined;

    public enum WEAPON_CATAGORY
    {
        Ranged,
        Melee,
        Undefined
    }

    public enum WEAPON_TYPE
    {
        Blade,
        Club,
        Taser,
        HoldoutPistol,
        LightPistol,
        HeavyPistol,
        MachinePistol,
        SMG,
        LMG,
        MMG,
        HMG,
        Shotgun,
        SniperRifle,
        AssaultRifle,
        Launcher,
        SpecialWeapon,
        Exotic,
        Undefined
    }

    public enum WEAPON_RANGE
    {
        Close,

        ///0-3
        Near,

        ///4-50
        Medium,

        ///51-250
        Far,

        ///251-500
        Extreme ///501+
    }

    public Dictionary<WEAPON_RANGE, int> attackRating = new Dictionary<WEAPON_RANGE, int>();
    public Dictionary<WEAPON_RANGE, int> modifiedattackRating = new Dictionary<WEAPON_RANGE, int>();
    public List<Gear> accessories = new List<Gear>();
    public List<Gear> modifications = new List<Gear>();

    public WEAPON_CATAGORY weaponCatagory
    {
        get { return _weaponCatagory; }
        set
        {
            try
            {
                _weaponCatagory = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public WEAPON_TYPE weaponType
    {
        get { return _weaponType; }
        set
        {
            try
            {
                _weaponType = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public Damage weaponDamage
    {
        get { return _weaponDamage; }
        set
        {
            try
            {
                _weaponDamage = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public Damage modifiedDamage
    {
        get { return _modifiedDamage; }
        set
        {
            try
            {
                _modifiedDamage = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public bool readied
    {
        get { return _readied; }
        set
        {
            try
            {
                _readied = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int maxRange
    {
        get { return maxRange; }
        set
        {
            try
            {
                _maxRange = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int currentModifications
    {
        get { return _currentModifications; }
        set
        {
            try
            {
                _currentModifications = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int maxModifications
    {
        get { return _maxModifications; }
        set
        {
            try
            {
                _maxModifications = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public Skill.SKILL_SPECIALIZATION specialization
    {
        get { return _specialization; }
        set
        {
            try
            {
                _specialization = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int specializationBonus
    {
        get
        {
            Utilities.wrForce("requiredSkillName:" + requiredSkillName.ToString());
            Utilities.wrForce("specialization:" + specialization.ToString());
            if (Utilities.isNull(entity))
            {
                Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
                return 0;
            }

            if (Utilities.isNull(entity.activeSkillController))
            {
                Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity.activeSkillController is null!");
                return 0;
            }

            foreach (Skill s in entity.activeSkillController.controlledStats)
            {
                if (s.skillName == requiredSkillName)
                {
                    if (s.specialization == specialization)
                    {
                        return 2;
                    }

                    if (s.expertise == specialization)
                    {
                        return 3;
                    }
                }
            }

            return 0;
        }
    }

    public int relevantAR(Entity def)
    {
        /*
        //       Close, ///0-3
        //     Near, ///4-50
        //   Medium, ///51-250
        // Far, ///251-500
        //Extreme //501 +
       */


        Utilities.wrForce("Enter distance to defender");
        int tempDistance = int.Parse(Console.ReadLine());

// raycast distance to _defender in Unity instead of tempDistance
        int cAR = 0;
        if (tempDistance <= 3)
        {
            cAR = modifiedattackRating[WEAPON_RANGE.Close];
        }

        if (tempDistance >= 4 && tempDistance <= 50)
        {
            cAR = modifiedattackRating[WEAPON_RANGE.Near];
        }

        if (tempDistance >= 51 && tempDistance <= 250)
        {
            cAR = modifiedattackRating[WEAPON_RANGE.Medium];
        }

        if (tempDistance >= 251 && tempDistance <= 500)
        {
            cAR = modifiedattackRating[WEAPON_RANGE.Far];
        }

        if (tempDistance > 500)
        {
            cAR = modifiedattackRating[WEAPON_RANGE.Extreme];
        }

        return cAR;
    }

    public void CGO_Initialize(string namu, WEAPON_CATAGORY wC, WEAPON_TYPE wT, int[] aR)
    {
        base.CGO_Initialize(namu);
        gearCatagory = GEAR_CATAGORY.Weapon;
        weaponCatagory = wC;
        weaponType = wT;
        SetAttackRating(aR);
        SetRequiredSkill();
        SetSpecialization();
        SetMaxModifications();
    }

    public void SetMaxModifications() // Depends on type
    {
        if (weaponType == WEAPON_TYPE.Blade || weaponType == WEAPON_TYPE.Club || weaponType == WEAPON_TYPE.Taser)
        {
            maxModifications = 2;
        }

        if (weaponType == WEAPON_TYPE.LightPistol || weaponType == WEAPON_TYPE.HeavyPistol ||
            weaponType == WEAPON_TYPE.MachinePistol)
        {
            maxModifications = 3;
        }

        if (weaponType == WEAPON_TYPE.SMG || weaponType == WEAPON_TYPE.LMG || weaponType == WEAPON_TYPE.MMG ||
            weaponType == WEAPON_TYPE.HMG)
        {
            maxModifications = 4;
        }

        if (weaponType == WEAPON_TYPE.Shotgun || weaponType == WEAPON_TYPE.SniperRifle)
        {
            maxModifications = 5;
        }

        if (weaponType == WEAPON_TYPE.AssaultRifle)
        {
            maxModifications = 6;
        }
    }

    public void SetSpecialization()
    {
        if (weaponType == WEAPON_TYPE.Blade)
        {
            specialization = Skill.SKILL_SPECIALIZATION.Blades;
        }

        if (weaponType == WEAPON_TYPE.Club)
        {
            specialization = Skill.SKILL_SPECIALIZATION.Clubs;
        }

        if (
            weaponType == WEAPON_TYPE.Taser || weaponType == WEAPON_TYPE.HoldoutPistol ||
            weaponType == WEAPON_TYPE.LightPistol || weaponType == WEAPON_TYPE.HeavyPistol
        )
        {
            specialization = Skill.SKILL_SPECIALIZATION.Pistols;
        }

        if (
            weaponType == WEAPON_TYPE.MachinePistol || weaponType == WEAPON_TYPE.SMG ||
            weaponType == WEAPON_TYPE.AssaultRifle || weaponType == WEAPON_TYPE.LMG ||
            weaponType == WEAPON_TYPE.MMG ||
            weaponType == WEAPON_TYPE.HMG
        )
        {
            specialization = Skill.SKILL_SPECIALIZATION.Automatics;
        }

        if (weaponType == WEAPON_TYPE.Shotgun)
        {
            specialization = Skill.SKILL_SPECIALIZATION.Longarms;
        }

        if (weaponType == WEAPON_TYPE.SniperRifle)
        {
            specialization = Skill.SKILL_SPECIALIZATION.Rifles;
        }

        if (weaponType == WEAPON_TYPE.Exotic)
        {
            // TODO: specialization = Skill.SKILL_SPECIALIZATION.;
        }
    }

    public void SetRequiredSkill()
    {
        if (weaponType == WEAPON_TYPE.Blade || weaponType == WEAPON_TYPE.Club)
        {
            requiredSkillName = Skill.SKILL_NAME.CloseCombat;
        }

        if (
            weaponType == WEAPON_TYPE.Taser || weaponType == WEAPON_TYPE.HoldoutPistol ||
            weaponType == WEAPON_TYPE.LightPistol || weaponType == WEAPON_TYPE.HeavyPistol ||
            weaponType == WEAPON_TYPE.MachinePistol || weaponType == WEAPON_TYPE.SMG ||
            weaponType == WEAPON_TYPE.AssaultRifle || weaponType == WEAPON_TYPE.LMG ||
            weaponType == WEAPON_TYPE.MMG || weaponType == WEAPON_TYPE.HMG ||
            weaponType == WEAPON_TYPE.Shotgun || weaponType == WEAPON_TYPE.SniperRifle
        )
        {
            requiredSkillName = Skill.SKILL_NAME.Firearms;
        }

        if (weaponType == WEAPON_TYPE.Exotic)
        {
            requiredSkillName = Skill.SKILL_NAME.ExoticWeapons;
        }
    }

    public void AddAccessories(Gear accessory)
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        accessories.Add(accessory);
    }

    public void AddModification(Gear modification)
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        if (currentModifications <= maxModifications)
        {
            modifications.Add(modification);
            ++currentModifications;
        }
    }

    public void SetAttackRating(int[] aR)
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        if (aR.Length == 5)
        {
            attackRating.Add(WEAPON_RANGE.Close, aR[0]);
            attackRating.Add(WEAPON_RANGE.Near, aR[1]);
            attackRating.Add(WEAPON_RANGE.Medium, aR[2]);
            attackRating.Add(WEAPON_RANGE.Far, aR[3]);
            attackRating.Add(WEAPON_RANGE.Extreme, aR[4]);
            modifiedattackRating.Add(WEAPON_RANGE.Close, aR[0]);
            modifiedattackRating.Add(WEAPON_RANGE.Near, aR[1]);
            modifiedattackRating.Add(WEAPON_RANGE.Medium, aR[2]);
            modifiedattackRating.Add(WEAPON_RANGE.Far, aR[3]);
            modifiedattackRating.Add(WEAPON_RANGE.Extreme, aR[4]);
        }
        else
        {
            Utilities.wrErr("<" + this.GetType() + "> SetattackRatings Needs 5 numbers");
        }
    }

    public void ModifyAttackRating(int _modifier_AR) // changes modifiedattackRating without altering the weapon's base stats
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        modifiedattackRating = new Dictionary<WEAPON_RANGE, int>();
        modifiedattackRating.Add(WEAPON_RANGE.Close, attackRating[WEAPON_RANGE.Close]);
        modifiedattackRating.Add(WEAPON_RANGE.Near, attackRating[WEAPON_RANGE.Near]);
        modifiedattackRating.Add(WEAPON_RANGE.Medium, attackRating[WEAPON_RANGE.Medium]);
        modifiedattackRating.Add(WEAPON_RANGE.Far, attackRating[WEAPON_RANGE.Far]);
        modifiedattackRating.Add(WEAPON_RANGE.Extreme, attackRating[WEAPON_RANGE.Extreme]);
        List<WEAPON_RANGE> ranges = new List<WEAPON_RANGE>();
        foreach (WEAPON_RANGE key in modifiedattackRating.Keys)
        {
            if (modifiedattackRating[key] > 0)
            {
                ranges.Add(key);
            }
        }

        foreach (WEAPON_RANGE key in ranges)
        {
            modifiedattackRating[key] += _modifier_AR;
        }
    }

    public void ModifyDamage(int mDV, Damage.DAMAGE_TYPE mDT,
        Damage.ELEMENTAL_DAMAGE mED) // changes modifiedDamage without altering the weapon's base stats
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        string modName = "modifiedDamage:" + this.CGO_Name;
        modifiedDamage = new Damage();
        modifiedDamage.damageModifier += mDV;
        modifiedDamage.damageType = mDT;
        modifiedDamage.elementalDamage = mED;
    }
}