using System;

[Serializable]
public class Cyberleg : Cyberlimb
{
    public void CGO_Initialize(Augmentation.WARE_GRADE wG)
    {
        augmentationName = Augmentation.AUGMENTATION_NAME.Cyberleg;
        base.CGO_Initialize(augmentationName, 1000, 1, Gear.LEGALITY.L, wG, 1.0f);
    }
}