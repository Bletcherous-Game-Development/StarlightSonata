using System;[Serializable] public class TakeAim:Action{
    public override void InitiateAction(){
        if(Utilities.isNull(entity)){
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!"); return;}
        Utilities.wr("***<==8_TakeAim_8==>***");
        if(TimeAndTypeCheck()){}}}