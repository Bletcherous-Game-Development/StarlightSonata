using System;
using System.Linq.Expressions;
using UnityEngine;

[Serializable]
public class Character : Entity
{
    METATYPE _metatype = METATYPE.Undefined;
    int _unarmedMeleeDamageModifier = 0;
    Damage.DAMAGE_TYPE _unarmedMeleeDamageType = Damage.DAMAGE_TYPE.Stun;
    Damage.ELEMENTAL_DAMAGE _unarmedMeleeElementalDamage = Damage.ELEMENTAL_DAMAGE.Undefined;
    int _age = 0;

    SEX _sex = SEX.Undefined;
    float _height = 0.0f;
    float _weight = 0.0f;
    int _heat = 0;
    int _reputation = 0;
    public bool _init = false;
    public int resources = 0; // temp until dealt with through credstick or something

    public enum METATYPE
    {
        Baseline, // Human
        GridGhost, //AI
        HighGrav, // Dwarf
        LowGrav, // Elf
        Bespoke, // Ork
        VatGrown, // Troll
        Xeno, // ???

        Undefined
// more types to come?
    }

    public enum SEX
    {
        Male,
        Female,
        Undefined
    }

    public METATYPE metatype
    {
        get { return _metatype; }
        set
        {
            try
            {
                _metatype = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public Damage unarmedMeleeDamage
    {
        get
        {
            if (Utilities.isNull(attributeController))
            {
                Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".attributecontroller is null!");
                return new Damage();
            }

            dam = new Damage();
            foreach (Attribute a in attributeController.controlledStats)
            {
                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Strength)
                {
                    dam.CGO_Initialize((int)((float)a.modifiedRank() * 0.5f + 0.5f + unarmedMeleeDamageModifier),
                        unarmedMeleeDamageType);
                }
            }

            return dam;
        }
    }

    public int unarmedMeleeDamageModifier
    {
        get { return _unarmedMeleeDamageModifier; }
        set
        {
            try
            {
                _unarmedMeleeDamageModifier = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public Damage.DAMAGE_TYPE unarmedMeleeDamageType
    {
        get { return _unarmedMeleeDamageType; }
        set
        {
            try
            {
                _unarmedMeleeDamageType = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public float height
    {
        get { return _height; }
        set
        {
            try
            {
                _height = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public float weight
    {
        get { return _weight; }
        set
        {
            try
            {
                _weight = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int age
    {
        get { return _age; }
        set
        {
            try
            {
                _age = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public SEX sex
    {
        get { return _sex; }
        set
        {
            try
            {
                _sex = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int heat
    {
        get { return _heat; }
        set
        {
            try
            {
                _heat = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int reputation
    {
        get { return _reputation; }
        set
        {
            try
            {
                _reputation = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int carry
    {
        get
        {
            supportVar = 0;
            foreach (Attribute a in attributeController.controlledStats)
            {
                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Body)
                {
                    supportVar += a.modifiedRank();
                }

                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Willpower)
                {
                    supportVar += a.modifiedRank();
                }
            }

            return supportVar;
        }
    }

    public int composure
    {
        get
        {
            supportVar = 0;
            foreach (Attribute a in attributeController.controlledStats)
            {
                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Willpower)
                {
                    supportVar += a.modifiedRank();
                }

                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Charisma)
                {
                    supportVar += a.modifiedRank();
                }
            }

            return supportVar;
        }
    }

    public int judgeIntentions
    {
        get
        {
            supportVar = 0;
            foreach (Attribute a in attributeController.controlledStats)
            {
                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Willpower)
                {
                    supportVar += a.modifiedRank();
                }

                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Intuition)
                {
                    supportVar += a.modifiedRank();
                }
            }

            return supportVar;
        }
    }

    public int lift
    {
        get
        {
            supportVar = 0;
            foreach (Attribute a in attributeController.controlledStats)
            {
                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Strength)
                {
                    supportVar = (a.modifiedRank() * a.modifiedRank() * 10);
                }
            }

            return supportVar;
        }
    }

    public int liftOverHead
    {
        get
        {
            supportVar = 0;
            foreach (Attribute a in attributeController.controlledStats)
            {
                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Strength)
                {
                    supportVar = (a.modifiedRank() * a.modifiedRank() * 5);
                }
            }

            return supportVar;
        }
    }

    public int memory
    {
        get
        {
            supportVar = 0;
            foreach (Attribute a in attributeController.controlledStats)
            {
                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Logic)
                {
                    supportVar += a.modifiedRank();
                }

                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Intuition)
                {
                    supportVar += a.modifiedRank();
                }
            }

            return supportVar;
        }
    }

   
    
    public void CGO_Initialize(string namu, METATYPE mT)
    {
        base.CGO_Initialize(namu);
        metatype = mT;
        if (_init)
        {
            return;
        }

        SetControllableStats();
        SetMetavariants();
        AddMetavariantQualities();
        _init = true;
    }

    void SetMetavariants() // by metatype
    {
        if (Utilities.isNull(attributeController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".attributecontroller is null!");
            return;
        }

        if (Utilities.isNull(conditionMonitorController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".conditionMonitorController is null!");
            return;
        }

        if (Utilities.isNull(activeSkillController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".activeSkillController is null!");
            return;
        }

        foreach (Attribute a in attributeController.controlledStats)
        {
            a.SetRankLimit(6);
            a.SetBaseRank(1);
            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Edge)
            {
                if (metatype == METATYPE.Baseline)
                {
                    a.SetRankLimit(7);
                }
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Essence)
            {
                a.SetBaseRank(6);
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Armor)
            {
                a.SetBaseRank(0);
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Body)
            {
                if (metatype == METATYPE.HighGrav)
                {
                    a.SetRankLimit(7);
                }

                if (metatype == METATYPE.VatGrown)
                {
                    a.SetRankLimit(9);
                }
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Agility)
            {
                if (metatype == METATYPE.LowGrav)
                {
                    a.SetRankLimit(7);
                }

                if (metatype == METATYPE.VatGrown)
                {
                    a.SetRankLimit(5);
                }
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Reaction)
            {
                if (metatype == METATYPE.HighGrav)
                {
                    a.SetRankLimit(5);
                }
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Strength)
            {
                if (metatype == METATYPE.HighGrav)
                {
                    a.SetRankLimit(8);
                }

                if (metatype == METATYPE.VatGrown)
                {
                    a.SetRankLimit(9);
                }
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Willpower)
            {
                if (metatype == METATYPE.HighGrav)
                {
                    a.SetRankLimit(7);
                }
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Logic)
            {
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Intuition)
            {
                if (metatype == METATYPE.LowGrav)
                {
                    a.SetRankLimit(8);
                }
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Charisma)
            {
                if (metatype == METATYPE.VatGrown)
                {
                    a.SetRankLimit(5);
                }
            }
        }

        foreach (Skill s in activeSkillController.controlledStats)
        {
            s.SetRankLimit(9);
        }

        if (metatype == METATYPE.Bespoke)
        {
            attributeController.LimitBespokeAttributes();
        }
    }

    void AddMetavariantQualities() // additional setup by metatype
    {
        if (Utilities.isNull(qualityController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".qualityController is null!");
            return;
        }

        switch (metatype) //all the metatypes
        {
            case METATYPE.GridGhost:
            {
//TODO: ???
                break;
            }
            case METATYPE.Baseline:
            {
                qualityController.AddQuality(Quality.QUALITY_NAME.Bioadaptability, true);
                break;
            }
            case METATYPE.HighGrav:
            {
                qualityController.AddQuality(Quality.QUALITY_NAME.ThermographicVision, true);
                qualityController.AddQuality(Quality.QUALITY_NAME.ToxinResistance, true);
                qualityController.AddQuality(Quality.QUALITY_NAME.MacroGravityAdaption, true);
                break;
            }
            case METATYPE.LowGrav:
            {
                qualityController.AddQuality(Quality.QUALITY_NAME.LowLightVision, true);
                qualityController.AddQuality(Quality.QUALITY_NAME.MicroGravityAdaption, true);

                qualityController.AddQuality(Quality.QUALITY_NAME.RadiationResistance, true);
                qualityController.AddQuality(Quality.QUALITY_NAME.Fragile, 3, true);
                break;
            }
            case METATYPE.Bespoke:
            {
                qualityController.AddQuality(Quality.QUALITY_NAME.BuiltTough, 1, true);
                qualityController.AddQuality(Quality.QUALITY_NAME.LowLightVision, true);
                qualityController.AddQuality(Quality.QUALITY_NAME.QuickHealer, true);
                break;
            }
            case METATYPE.VatGrown:
            {
                qualityController.AddQuality(Quality.QUALITY_NAME.BuiltTough, 2, true);
                qualityController.AddQuality(Quality.QUALITY_NAME.DermalDeposits, true);
                qualityController.AddQuality(Quality.QUALITY_NAME.ThermographicVision, true);
                qualityController.AddQuality(Quality.QUALITY_NAME.Toughness, true);
                break;
            }
        }
    }

    public override void SetControllableStats()
    {
        SetAttributes();
        SetConditionMonitors();
        SetSkills();
    }

    public override void SetAttributes()
    {
        if (metatype != METATYPE.GridGhost) // meatbags
        {
            Attribute body = new Attribute();
            Attribute agility = new Attribute();
            Attribute reaction = new Attribute();
            Attribute strength = new Attribute();
            attributeController.Control(body);
            attributeController.Control(agility);
            attributeController.Control(reaction);
            attributeController.Control(strength);
            body.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Body);
            agility.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Agility);
            reaction.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Reaction);
            strength.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Strength);
        }

// all characters
        Attribute willpower = new Attribute();
        Attribute logic = new Attribute();
        Attribute intuition = new Attribute();
        Attribute charisma = new Attribute();
        Attribute edge = new Attribute();
        attributeController.Control(willpower);
        attributeController.Control(logic);
        attributeController.Control(intuition);
        attributeController.Control(charisma);
        attributeController.Control(edge);
        willpower.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Willpower);
        logic.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Logic);
        intuition.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Intuition);
        charisma.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Charisma);
        edge.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Edge);
        if (metatype == METATYPE.GridGhost) //Als
        {
            Attribute deviceRating = new Attribute();
            Attribute attack = new Attribute();
            Attribute sleaze = new Attribute();
            Attribute dataProcessing = new Attribute();
            Attribute firewall = new Attribute();
            Attribute depth = new Attribute();
            attributeController.Control(deviceRating);
            attributeController.Control(attack);
            attributeController.Control(sleaze);

            attributeController.Control(dataProcessing);
            attributeController.Control(firewall);
            attributeController.Control(depth);
            deviceRating.CGO_Initialize(Attribute.ATTRIBUTE_NAME.DeviceRating);
            attack.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Attack);
            sleaze.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Sleaze);
            dataProcessing.CGO_Initialize(Attribute.ATTRIBUTE_NAME.DataProcessing);
            firewall.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Firewall);
            depth.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Depth);
        }

        if (metatype != METATYPE.GridGhost)
        {
            Attribute essence = new Attribute();
            Attribute armor = new Attribute();
            attributeController.Control(essence);
            attributeController.Control(armor);
            essence.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Essence);
            armor.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Armor);
        }
    }

    public override void SetConditionMonitors()
    {
        if (Utilities.isNull(conditionMonitorController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".conditionMonitorcontroller is null!");
            return;
        }

        if (Utilities.isNull(attributeController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".attributecontroller is null!");
            return;
        }

        if (metatype != METATYPE.GridGhost)
        {
            ConditionMonitor stun = new ConditionMonitor();
            ConditionMonitor physical = new ConditionMonitor();
            conditionMonitorController.Control(stun);
            conditionMonitorController.Control(physical);
            foreach (Attribute a in attributeController.controlledStats)
            {
                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Willpower)
                {
                    stun.CGO_Initialize(Damage.DAMAGE_TYPE.Stun, a);
                }

                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Body)
                {
                    physical.CGO_Initialize(Damage.DAMAGE_TYPE.Physical, a);
                }
            }
        }

        if (metatype == METATYPE.GridGhost)
        {
            ConditionMonitor grid = new ConditionMonitor();
            conditionMonitorController.Control(grid);
            foreach (Attribute a in attributeController.controlledStats)
            {
                if (a.attributeName == Attribute.ATTRIBUTE_NAME.DeviceRating)
                {
                    grid.CGO_Initialize(Damage.DAMAGE_TYPE.Grid, a);
                }
            }
        }
    }

    public override void SetSkills()
    {
        if (Utilities.isNull(activeSkillController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".activeSkillController is null!");
            return;
        }

        Skill athletics = new Skill();
        Skill biotech = new Skill();
        Skill closeCombat = new Skill();
        Skill con = new Skill();
        Skill cracking = new Skill();
        Skill electronics = new Skill();
        Skill engineering = new Skill();
        Skill exoticWeapons = new Skill();
        Skill firearms = new Skill();
        Skill influence = new Skill();
        Skill outdoors = new Skill();
        Skill perception = new Skill();
        Skill piloting = new Skill();
        Skill stealth = new Skill();
        if (metatype != METATYPE.GridGhost)
        {
            activeSkillController.Control(athletics);
            activeSkillController.Control(biotech);
            activeSkillController.Control(closeCombat);
        }

        activeSkillController.Control(con);
        activeSkillController.Control(cracking);
        activeSkillController.Control(electronics);
        activeSkillController.Control(engineering);
        if (metatype != METATYPE.GridGhost)
        {
            activeSkillController.Control(exoticWeapons);
            activeSkillController.Control(firearms);
        }

        activeSkillController.Control(influence);
        if (metatype != METATYPE.GridGhost)
        {
            activeSkillController.Control(outdoors);
            activeSkillController.Control(perception);
            activeSkillController.Control(piloting);
            activeSkillController.Control(stealth);
        }

        foreach (Attribute a in attributeController.controlledStats)
        {
            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Body)
            {
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Agility)
            {
                engineering.secondaryAttribute = a;
                athletics.CGO_Initialize(Skill.SKILL_NAME.Athletics, a, true);
                closeCombat.CGO_Initialize(Skill.SKILL_NAME.CloseCombat, a, true);
                exoticWeapons.CGO_Initialize(Skill.SKILL_NAME.ExoticWeapons, a, false);
                firearms.CGO_Initialize(Skill.SKILL_NAME.Firearms, a, true);
                stealth.CGO_Initialize(Skill.SKILL_NAME.Stealth, a, true);
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Reaction)
            {
                piloting.CGO_Initialize(Skill.SKILL_NAME.Piloting, a, true);
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Strength)
            {
                athletics.secondaryAttribute = a;
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Willpower)
            {
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Logic)
            {
                influence.secondaryAttribute = a;
                perception.secondaryAttribute = a;
                biotech.CGO_Initialize(Skill.SKILL_NAME.Biotech, a, false);
                cracking.CGO_Initialize(Skill.SKILL_NAME.Cracking, a, false);
                electronics.CGO_Initialize(Skill.SKILL_NAME.Electronics, a, true);
                engineering.CGO_Initialize(Skill.SKILL_NAME.Engineering, a, true);
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Intuition)
            {
                electronics.secondaryAttribute = a;
                outdoors.CGO_Initialize(Skill.SKILL_NAME.Outdoors, a, true);
                perception.CGO_Initialize(Skill.SKILL_NAME.Perception, a, true);
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Charisma)
            {
                con.CGO_Initialize(Skill.SKILL_NAME.Con, a, true);
                influence.CGO_Initialize(Skill.SKILL_NAME.Influence, a, true);
            }
        }

        athletics.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Archery);
        athletics.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Climbing);
        athletics.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Flying);
        athletics.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Gymnastics);
        athletics.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Sprinting);
        athletics.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Swimming);
        athletics.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Throwing);
        biotech.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Biotechnology);
        biotech.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Cybertechnology);
        biotech.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.FirstAide);
        biotech.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Medicine);
        closeCombat.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Blades);
        closeCombat.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Clubs);
        closeCombat.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.UnarmedCombat);
        con.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Acting);
        con.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Disguise);
        con.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Impersonation);
        con.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Performance);
        cracking.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.CyberCombat);

        cracking.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.ElectronicWarfare);
        cracking.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Hacking);
        electronics.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Computer);
        electronics.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Hardware);
        electronics.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Software);
        engineering.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.AeronauticsMechanic);
        engineering.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Armorer);
        engineering.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.AutomotiveMechanic);
        engineering.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Demolitions);
        engineering.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Gunnery);
        engineering.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.IndustrialMechanic);
        engineering.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Lockpicking);
        engineering.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.NauticalMechanic);
        exoticWeapons.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.CombatChainsaw);
        exoticWeapons.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.GrappleGun);
        exoticWeapons.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.GrenadeLauncher);
        exoticWeapons.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.MonofilamentWhip);
        exoticWeapons.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.TubeLauncher);
        firearms.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Automatics);
        firearms.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Longarms);
        firearms.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Pistols);
        firearms.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Rifles);
        firearms.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Shotguns);
        influence.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Etiquette);
        influence.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Instruction);
        influence.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Intimidation);
        influence.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Leadership);
        influence.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Negotiation);
        outdoors.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Navigation);
        outdoors.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Survival);
        outdoors.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.TrackingArctic);
        outdoors.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.TrackingDesert);
        outdoors.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.TrackingJungle);
        outdoors.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.TrackingUrban);
        outdoors.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.TrackingWoods);
        perception.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Aural);
        perception.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Tactile);
        perception.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Visual);
        perception.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.ByEnvironmentArctic);
        perception.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.ByEnvironmentDesert);
        perception.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.ByEnvironmentJungle);
        perception.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.ByEnvironmentUrban);
        perception.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.ByEnvironmentWoods);
        piloting.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.GroundCraft);
        piloting.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Aircraft);
        piloting.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Watercraft);
        stealth.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Disguise);
        stealth.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Camouflage);
        stealth.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Palming);
        stealth.AddToSkillSpecializations(Skill.SKILL_SPECIALIZATION.Sneaking);
    }
}