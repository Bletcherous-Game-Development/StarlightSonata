using System;

[Serializable]
public class Attack : Action
{
    Entity _defender;
    Weapon _weapon;
    DiceRollVariables _attackerDRV;
    DiceRollVariables _defenderDRV;
    int _attackerSkill = 0;
    int _attackerAttribute = 0;
    int _attackerEdge = 0;
    int _defenderReaction = 0;
    int _defenderIntuition = 0;
    int _defenderEdge = 0;
    Damage _netDamage;

    public override void InitiateAction(Entity def, Weapon weap)
    {
        _defender = def;
        _weapon = weap;
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        if (Utilities.isNull(entity.activeSkillController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity.activeSkillController is null!");
            return;
        }

        if (Utilities.isNull(_defender.attributeController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ",_defender.attributecontroller is null!");
            return;
        }

        Utilities.wr("***<==8_Attack_8==>***");
        if (_weapon.readied)
        {
            if (_weapon.relevantAR(_defender) > 0)
            {
                if (TimeAndTypeCheck())
                {
// 1 grab dice.
                    foreach (Skill s in entity.activeSkillController.controlledStats)
                    {
                        if (s.skillName == _weapon.requiredSkillName)
                        {
                            if (s.rank > 0)
                            {
                                _attackerSkill = s.modifiedRank();
                            }
                            else
                            {
                                if (s.untrained)
                                {
                                    _attackerSkill = 0;
                                }
                                else
                                {
                                    _attackerSkill += 1;
                                    _attackerAttribute = s.linkedAttribute.modifiedRank();
                                }
                            }

                            foreach (Attribute a in entity.attributeController.controlledStats)
                            {
                                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Edge)
                                {
                                    _attackerEdge = a.rank;
                                }
                            }

                            foreach (Attribute a in _defender.attributeController.controlledStats)
                            {
                                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Reaction)
                                {
                                    _defenderReaction = a.modifiedRank();
                                }

                                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Intuition)
                                {
                                    _defenderIntuition = a.modifiedRank();
                                }

                                if (a.attributeName == Attribute.ATTRIBUTE_NAME.Edge)
                                {
                                    _defenderEdge = a.rank;
                                }
                            }

                            _attackerDRV = new DiceRollVariables(_attackerSkill +
                                _weapon.specializationBonus + _attackerAttribute - entity.woundModifier);
                            _attackerDRV.edgeRank = _attackerEdge;
                            _defenderDRV =
                                new DiceRollVariables(_defenderReaction + _defenderReaction - _defender.woundModifier);
                            _defenderDRV.edgeRank = _defenderEdge;
// 2 distribute edge.
                            Utilities.wrForce("_weapon.relevantAR:" + _weapon.relevantAR(_defender) +
                                              ", _defender.defenseRating: " +
                                              _defender.defenseRating);
                            if (_weapon.relevantAR(_defender) - _defender.defenseRating >= 4)
                            {
                                ++entity.availableEdge;
                                Utilities.wrForce(entity.CGO_Name + " gains a point of Edge.");
                            }
                            else if (_defender.defenseRating - _weapon.relevantAR(_defender) >= 4)
                            {
                                ++_defender.availableEdge;
                                Utilities.wrForce(_defender.CGO_Name + " gains a point of Edge.");
                            } // TODO: environmental, visability advantages

// 3 roll dice and spend edge.
                            ///prompt _attackerDRV for Edge Boost use before and after roll
// TODO: entity.UseAvailableEdge(ref_attackerDRV);
// prompt _defenderDRV for Edge Boost or defensive action use before and
// TODO: _defender.UseAvailableEdge(ref _defenderDRV);
                            Utilities.wrForce(entity.CGO_Name + ": " + _attackerDRV.dicePool + " vs " + _defender.CGO_Name +
                                              ":" +
                                              _defenderDRV.dicePool);
                            CoreMechanics coreMech = new CoreMechanics();
                            int result = coreMech.OpposedTest(ref _attackerDRV, ref _defenderDRV);
                            if (result > 0)
                            {
                                Utilities.wrForce("Hit," + result + " net hits");
                                Utilities.wrForce("modified Damage Value:" +
                                                  _weapon.modifiedDamage.modifiedDamageValue);
                                _netDamage = new Damage();
//TODO: " _weapon . modified Damage, name,_weapon .modifiedDamage.modifiedDamageValue,_weapon. modified Damage.dama geType);
                                _netDamage.damageModifier += result;
                                _defenderDRV = new DiceRollVariables();
// prompt _defenderDRV for Edge Boost
// TODO: _defender.UseAvailableEdge(ref _defenderDRV);
// 4 soak some damage.
// 5 bring the pain.
                                _defender.ResistDamage(_netDamage, ref _defenderDRV);
                            }

                            else
                            {
                                Utilities.wrForce("<" + this.GetType() + "> Missed");
                            }
                        }
                    }

                    Utilities.wrForce("<" + this.GetType() + "> Out of Weapon's Range");
                }
            }
            else
            {
                Utilities.wrForce("<" + this.GetType() + "> Weapon not readied");
            }
        }
    }
}