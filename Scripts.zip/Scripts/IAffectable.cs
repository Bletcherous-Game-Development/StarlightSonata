//controllers and their affected statClasses
public interface IAffectable  
{
    void Accept(IAffector visitor);
}