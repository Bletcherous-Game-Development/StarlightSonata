// For standalone contacts when you just need their base stats. If they are going to be present in a scene, create an NPC.
using System;
using System.Collections.Generic;

[Serializable]
public class Contact : ControllableStat
{
    int _connection = 1;
    int _loyalty = 1;
    int _maxRating = 12;
    public List<Attribute> attributes = new List<Attribute>();
    public List<Skill> knowledgeskills = new List<Skill>();

    public int connection
    {
        get { return _connection; }
        set
        {
            try
            {
                if (value <= _maxRating)
                {
                    _connection = value;
                }
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int loyalty
    {

        get { return _loyalty; }
        set
        {
            try
            {
                if (value <= _maxRating)
                {
                    _loyalty = value;
                }
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

//LegworkResults 1-10, simple connection + connection
    public int legworkResults()
    {
        CoreMechanics coreMech = new CoreMechanics();
        DiceRollVariables drv = new DiceRollVariables();
        drv.dicePool = connection + connection;
        return coreMech.SimpleTest(ref drv);
    }

    ///your l+C+loyalty: free results
    public int freeResults()
    {
        CoreMechanics coreMech = new CoreMechanics();
        DiceRollVariables drv = new DiceRollVariables();
        foreach (Attribute a in entity.attributeController.controlledStats)
        {
            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Intuition)
            {
                drv.dicePool += a.modifiedRank();
            }

            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Charisma)
            {
                drv.dicePool += a.modifiedRank();
            }
        }

        drv.dicePool += loyalty;
        return coreMech.SimpleTest(ref drv);
    }
}