using System;

[Serializable]
public class Aptitude : Quality
{
    Skill.SKILL_NAME _skillName = Skill.SKILL_NAME.Undefined;

    public Skill.SKILL_NAME skillName
    {
        get { return _skillName; }
        set
        {
            try
            {
                _skillName = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public void CGO_Initialize(Quality.QUALITY_NAME qN, Skill.SKILL_NAME sN)
    {
        skillName = sN;
        SetKarmaCost(12);
        base.CGO_Initialize(qN);

        SetName((qualityName.ToString() + "(" + skillName.ToString() + ")"));
        SetQualityType(QUALITY_TYPE.Positive);
    }

    public override void GameEffect()
    {
        if (Utilities.isNull(entity))
        {
            return;
        }

        if (Utilities.isNull(entity.activeSkillController))
        {
            return;
        }

        foreach (Skill s in entity.activeSkillController.controlledStats)
        {
            if (s.skillName == skillName)
            {
                s.AddAptitudeOrException();
                break;
            }
        }
    }

    public override void ReverseEffect()
    {
        base.ReverseEffect();
    }
}