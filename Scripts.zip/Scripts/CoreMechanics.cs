using System;

[Serializable]
public class CoreMechanics
{
    //Random randomNumbers = new Random();
    
    // main method for returning total # of D6 hits.
    // Modifies the DRV's variables to store results of the rolls
    
    public int DiceMechanic(ref DiceRollVariables drv)
    {
        var explodedSixes = false;
        var frequency1 = 0;
        var frequency2 = 0;
        var frequency5 = 0;
        var frequency6 = 0;
        var totalHits = 0;
        var glitchThreshold = 0;
        var tempFrequency1 = 0;

        Utilities.wrForce("Dice Pool:" + drv.dicePool);

        // handles the Edge Boost
        if (drv.sixesExplode)
        {
            Utilities.wrForce("Sixes Explode!");
            // add edge if using "6's Explode"
            drv.dicePool += drv.edgeRank;

            Utilities.wrForce("Dice Pool now:" + drv.dicePool);
        }

        // set glitch threshold to half of dice pool
        glitchThreshold = (int)((float)drv.dicePool*0.5f);

        // loop through rolling all the dice
        for (var roll = 1; roll <= drv.dicePool; ++roll)
        {
            // d6
            var face = UnityEngine.Random.Range(1, 7);

            // count 1,2,5,6. An Edge Boost, enemyCounting2s, needs 2s tallied for glitches
            switch (face)
            {
                case 1:
                    ++frequency1;
                    break;

                case 2:
                    ++frequency2;
                    break;

                case 5:
                    ++frequency5;
                    break;

                case 6:
                    ++frequency6;
                    break;
            }


            // if finished with dice pool, but 6's explode hasn't been counted yet, use
            // edge only once. Add 6's Explode, dont count 1's for glitches.
            if (roll == drv.dicePool && drv.sixesExplode && !explodedSixes)
            {
                // add the 6's already rolled
                drv.dicePool += frequency6;

                // dont count these 1's for glitches
                tempFrequency1 = frequency1;

                // set flag for the single use check
                explodedSixes = true;
            }

            // tally hits
            totalHits = frequency5 + frequency6;

            // use original 1's tally, not the extra rolls
            if (drv.sixesExplode)
            {
                frequency1 = tempFrequency1;
            }

            // Edge Boost used
            if (drv.enemyCounting2s)
            {
                frequency1 += frequency2;
            }

            // glitches
            if (frequency1 >= glitchThreshold)
            {
                // critical glitch
                if (totalHits == 0)
                {
                    drv.CriticalGlitch = true;
                }

                // regular glitch
                if (totalHits > 0)
                {
                    drv.glitch = true;
                }
            }

            Utilities.wrForce("1's:" + frequency1);
            Utilities.wrForce("2's:" + frequency2);
            Utilities.wrForce("5's:" + frequency5);
            Utilities.wrForce("6's: " + frequency6);
        }

        return totalHits;
    }

    // returns net hits over drv's threshold for simplicity, its 0 by default
    public int SimpleTest(ref DiceRollVariables drv)
    {
        var hits = DiceMechanic(ref drv);
        // set the flag
        if(hits >= drv.threshold)
        {
            drv.success = true;
        }
        else
        {
            drv.success = false;
        }
        return (hits - drv.threshold);
    }

    // straight up opposed, positive in 1's favor, negative in 2's
    public int OpposedTest(ref DiceRollVariables drv1, ref DiceRollVariables drv2)
    {
        return (DiceMechanic(ref drv1) - DiceMechanic(ref drv2));
    }

    // rerolls the dice pool with 1 less each time,records the results
    public void ExtendedTest(ref DiceRollVariables drv)
    {
        var hits = 0;
        var intervals = 0;
        // stop if threshold met or out of dice or exit is true
        while(hits < drv.threshold || drv.dicePool > 0 || drv.exit)
        {
            // tally hits
            hits += DiceMechanic(ref drv);
            // increase intervals
            ++intervals;
            // use one less dice each iteration
            drv.dicePool -= 1;
        }
        // after rolls finished if threshold, set the flags
        if(hits >= drv.threshold)
        {
            drv.success = true;
        }
        else
        {
            drv.success = false;
        }
        drv.elapsedIntervals = intervals;
    }
}