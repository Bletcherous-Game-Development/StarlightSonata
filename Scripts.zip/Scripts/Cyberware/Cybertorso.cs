using System;

[Serializable]
public class Cybertorso : Cyberlimb
{
    public void CGO_Initialize(Augmentation.WARE_GRADE wG)
    {
        augmentationName = Augmentation.AUGMENTATION_NAME.Cybertorso;
        base.CGO_Initialize(augmentationName, 1000, 1, Gear.LEGALITY.L, wG, 0.1f);
    }
}