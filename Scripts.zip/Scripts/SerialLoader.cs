// loads a CyberpunkGameObject from a location. All class instances on the ego MUST be [Serializable]
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public static class SerialLoader
{
    // returns the loaded ego
    public static CyberpunkGameObject SerialLoad(string _playerName)
    {
        if (!SaveData.isSaveDataFound)
        {
            Utilities.wrErr("<SerialLoader> isSaveDataFound = False. Returning empty ego.");
            return new CyberpunkGameObject();
        }

        BinaryFormatter reader = new BinaryFormatter();
        FileStream input;
        CyberpunkGameObject cgo;
        try
        {
            Utilities.wr("***<==8_SerialLoading:" + _playerName + "_8==>***");
            string f = (SaveData.FilePath + _playerName);
            if (!File.Exists(f))
            {
                Utilities.wrErr("<SerialLoader> Error, File Not Found at" + SaveData.FilePath);
//Utilities.wrErr("<" + this.GetType() + "> Try a new file location, remember to use 'WW not 'W'");
                SaveData.FilePath = Console.ReadLine();
                // recursion call
                f = (SaveData.FilePath + _playerName);
                SerialLoader.SerialLoad(f);
            }

            // open the file
            input = new FileStream(f, FileMode.Open, FileAccess.Read);
            // set the local ego
            cgo = (CyberpunkGameObject)reader.Deserialize(input);
            input.Close();
            if (Utilities.isntNull(cgo))
            {
                Utilities.wr("***<==8_SerialLoaded:" + cgo.CGO_Name + "_8==>***");
                return cgo;
            }
        }
        catch
        {
            Utilities.wrErr("<SerialLoader> Error with SerialLoad(" + _playerName +
                            "). The class may be too divergent from its last SerialSave.");
            Utilities.wrErr(_playerName + " is way off baseline!");
//SaveData. FilePath = Console.ReadLine();
            // recursion call
//string f = (SaveData.FilePath + _playerName);
//SerialLoader.SerialLoad(f);
            Console.ReadLine();
        }

        // if all else fails, but this shouldnt get called because of the recursion calls above
        return new CyberpunkGameObject();
    }
}