using System;

[Serializable]
public class AugmentationController : StatController
{
    bool _init = false;

//public ConditionMonitor stun = new ConditionMonitor();
    public override void CGO_InitializeControllableStats()
    {
        if (_init)
        {
            return;
        }

//Controljstun);
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        if (Utilities.isNull(entity.attributeController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity.attributeController is null!");
            return;
        }

//stun.CGO」nitialize(Damage,DAMAGE_TYPE.Stun, entity.attributecontroller.willpower);
    }

    public void AddAugmentation(Augmentation.AUGMENTATION_NAME aN, Augmentation.WARE_GRADE wG)
    {
    }

    public void AddAugmentation(Augmentation.AUGMENTATION_NAME aN, Augmentation.WARE_GRADE wG, int rtng)
    {
    }
}