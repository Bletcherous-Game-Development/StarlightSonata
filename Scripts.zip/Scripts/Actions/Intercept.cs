using System;

[Serializable]
public class Intercept : Action
{
    public override void InitiateAction()
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        Utilities.wr("***<==8_Intercept_8==>***");
        if (TimeAndTypeCheck())
        {
        }
    }
}