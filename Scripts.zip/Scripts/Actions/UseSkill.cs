using System;

[Serializable]
public class UseSkill : Action
{
    public override void InitiateAction(Skill skill, int threshold, ref DiceRollVariables drv)
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        Utilities.wr("***<==8_UseSkill_8==>***");
        if (TimeAndTypeCheck())
        {
            drv.dicePool = skill.modifiedRank() + skill.linkedAttribute.modifiedRank() -
                           entity.woundModifier;
            if (skill.modifiedRank() == 0)
            {
                drv.dicePool -= 2;
            }

            drv.threshold = threshold;
            CoreMechanics coreMech = new CoreMechanics();
            int result = coreMech.SimpleTest(ref drv);
            if (result >= threshold)
            {
                drv.success = true;
            }
        }
    }
}