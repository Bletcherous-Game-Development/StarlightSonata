using System;

[Serializable]
public class Bioadaptability : Quality // needs accurate karmaCost
{
    public override void GameEffect()
    {
        if (Utilities.isNull(entity))
        {
            return;
        }

        SetQualityType(QUALITY_TYPE.Positive);
        SetKarmaCost(5);
    }

    public override void ReverseEffect()
    {
        base.ReverseEffect();
    }
}