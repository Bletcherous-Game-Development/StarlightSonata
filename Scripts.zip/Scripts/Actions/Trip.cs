using System;[Serializable] public class Trip:Action{
    public override void InitiateAction(){
        if(Utilities.isNull(entity)){
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!"); return;}
        Utilities.wr("***<==8_Trip_8==>***");
        if(TimeAndTypeCheck()){}}}