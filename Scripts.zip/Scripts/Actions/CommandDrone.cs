using System;[Serializable] public class CommandDrone: Action{
    public override void InitiateAction(){
        if(Utilities.isNull(entity)){
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!"); return;}
        Utilities. wr("***<==8_CommandDrone_8==>***");
        if(TimeAndTypeCheck()){}}}