using System;

[Serializable]
public class BuiltTough : Quality
{
    int _rating = 0;

    public int rating
    {
        get { return _rating; }
        set
        {
            try
            {
                _rating = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public void CGO_lnitialize(Quality.QUALITY_NAME qN, int r)
    {
        base.CGO_Initialize(qN);
        SetName((qualityName.ToString() + "(" + rating + ")"));
        SetQualityType(QUALITY_TYPE.Positive);
        SetKarmaCost((rating * 4));
    }

    public override void GameEffect()
    {
        if (Utilities.isNull(entity))
        {
            return;
        }

        if (Utilities.isNull(entity.conditionMonitorController))
        {
            return;
        }

        foreach (ConditionMonitor c in entity.conditionMonitorController.controlledStats)
        {
            if (c.damageType == Damage.DAMAGE_TYPE.Physical)
            {
                c.IncreaseAdditionalBoxes(rating);
            }
        }
    }

    public override void ReverseEffect()
    {
        foreach (ConditionMonitor c in entity.conditionMonitorController.controlledStats)
        {
            if (c.damageType == Damage.DAMAGE_TYPE.Physical)
            {
                c.additionalBoxes -= rating;
            }
        }
    }
}