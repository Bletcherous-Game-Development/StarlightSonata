using System;
using System.Collections.Generic;

[Serializable]
public abstract class StatController : CyberpunkGameObject, IAffectable
{
    int numOfSyncs = 0;
    STAT_CONTROLLER_TYPE _statControllerType = STAT_CONTROLLER_TYPE.Undefined;
    public Entity entity;
    public List<ControllableStat> controlledStats = new List<ControllableStat>();

    public enum STAT_CONTROLLER_TYPE
    {
        AttributeController,
        ConditionMonitorController,
        ActiveSkillController,
        KnowledgeSkillController,
        QualityController,

        AugmentationController,
        StatusController,
        ActionController,
        GearSlotController,
        ContactController,
        Undefined
    }

    public STAT_CONTROLLER_TYPE statControllerType
    {
        get { return _statControllerType; }
        set
        {
            try
            {
                _statControllerType = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public void CGO_Initialize(STAT_CONTROLLER_TYPE sCT)
    {
        SetStatControllerType(sCT);
        SetName(statControllerType.ToString());
        base.CGO_Initialize();
        CGO_InitializeControllableStats();
        Sync();
    }

    public void SetEntity(Entity e)
    {
        entity = e;
    }

    public virtual void AddToControlledStats(ControllableStat cStat)
    {
        if (controlledStats.Contains(cStat))
        {
            Utilities.wr("<" + this.GetType().Name + "> " + CGO_Name + " already controls " + cStat.CGO_Name + "!");
            return;
        }

        controlledStats.Add(cStat);
    }

    public virtual void RemoveFromControlledStats(ControllableStat cStat)
    {
        if (!controlledStats.Contains(cStat))
        {
            Utilities.wr("<" + this.GetType().Name + " > " + CGO_Name + " doesnt control" + cStat.CGO_Name + "I");
            return;
        }

        controlledStats.Remove(cStat);
    }

    public virtual void Control(ControllableStat cStat)
    {
        if (controlledStats.Contains(cStat))
        {
            Utilities.wr("<" + this.GetType().Name + "> this " + CGO_Name + " already controls " + cStat.CGO_Name + "I");
            return;
        }

        if (Utilities.isntNull(cStat.statController))
        {
            if (cStat.statController != this)
            {
                Utilities.wr("<" + this.GetType().Name + "> " + cStat.statController.CGO_Name + " already controls" +
                             cStat.CGO_Name + "I");
                return;
            }
        }

        cStat.SetStatController(this);
        cStat.SetGM(GM);
        AddToControlledStats(cStat);
    }

    public virtual void UnControl(ControllableStat cStat)
    {
        if (!controlledStats.Contains(cStat))
        {
            Utilities.wr("<" + this.GetType().Name + "> this" + CGO_Name + " doesnt control" + cStat.CGO_Name +
                         "I");
            return;
        }

        cStat.SetControlled(false);
        controlledStats.Remove(cStat);
    }

    public virtual void Sync()
    {
        ++numOfSyncs;
//Utilities.wrForce("[statController:" + name + "]" + " Sync#" + numOfSyncs + ", controlled Stats. Cou nt: "+ controlledStats.Count);
        foreach (ControllableStat cStat in controlledStats)
        {
            cStat.Sync(this);

//Utilities.wrForce(name +	+ cStat.name + " Sync#" + numOfSyncs);
        }
    }

    public void SetStatControllerType(STAT_CONTROLLER_TYPE sCT)
    {
        statControllerType = sCT;
    }

    public abstract void CGO_InitializeControllableStats();

    public void Accept(IAffector visitor)
    {
        visitor.Visit(this);
    }
}