using System;

[Serializable]
public class Datajack : Cyberware
{
    public DataConnector jack = new DataConnector();
    public DataConnector slot = new DataConnector();

    public void CGO_Initialize(Augmentation.WARE_GRADE wG)
    {
        augmentationName = Augmentation.AUGMENTATION_NAME.Datajack;
        base.CGO_Initialize(augmentationName, 1000, 1, Gear.LEGALITY.L, wG, 0.1f);
        jack.CGO_Initialize(DataConnector.INTERFACE_TYPE.Jack);
        slot.CGO_Initialize(DataConnector.INTERFACE_TYPE.Slot);
    }
}
