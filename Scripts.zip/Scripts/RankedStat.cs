//base class for Attribute & Skill
using System;

[Serializable]
public class RankedStat : ControllableStat
{
    bool _aptitudeOrException = false;
    int _rank = 0;
    int _rankLimit = 0;

    public bool aptitudeOrException
    {
        get { return _aptitudeOrException; }
        set
        {
            try
            {
                _aptitudeOrException = value;

            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + "	Property set errror!!!");
            }
        }
    }

    public int rank
    {
        get { return _rank; }
        set
        {
            try
            {
                _rank = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + "	Property set errror!!!");
            }
        }
    }

    public int rankLimit
    {
        get { return _rankLimit; }
        set
        {
            try
            {
                _rankLimit = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + "	Property set errror!!!");
            }
        }
    }

    public int improvementKarmaCost
    {
        get { return ((rank + 1) * 5); }
    }

    public int modifiedRank()
    {

        int modType = 0;
        foreach (Modifier m in modifiers)
        {
            modType += (int)m.modifier;
        }

        return (int)(rank + modType);
    }

    public float modifiedRank(float f)
    {
        float modType = 0.0f;
        foreach (Modifier m in modifiers)
        {
            modType += m.modifier;
        }

        return ((float)rank + modType);
    }

    public virtual void AddAptitudeOrException()
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        if (Utilities.isNull(statController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".statController is null!");
            return;
        }

        RankedStat r = new RankedStat();
        int aptExc = 0;
        foreach (ControllableStat cStat in statController.controlledStats)
        {
            r = (RankedStat)cStat;
            if (r.aptitudeOrException)
            {
                if (r != this)
                {
                    ++aptExc;
                    return;
                }
            }
        }

        if (aptExc > 1)
        {
            Utilities.wrForce("TOO many AptitudesOrExceptions!!!");
            return;
        }

        aptitudeOrException = true;
        rankLimit += 1;
    }

    public void IncreaseBaseRank()
    {
        if (Utilities.isNull(entity))
        {
            return;
        }

        if (entity.karma < improvementKarmaCost)
        {
            return;
        }

        if ((rank + 1) <= rankLimit)
        {
            entity.DecreaseKarma(improvementKarmaCost);
            ++rank;
        }
    }

    public void IncreaseBaseRank(int amt)
    {
        if ((rank + amt) <= rankLimit)
        {
            rank += amt;
        }
    }

    public void SetRankLimit(int rL)
    {
        rankLimit = rL;
    }

    public void DecreaseRankLimit(int rL)
    {
        rankLimit -= rL;
    }

    public void RemoveAllModifiers()
    {
        modifiers.Clear();
    }

    public void SetBaseRank(int bR)
    {
        rank = bR;
    }
}