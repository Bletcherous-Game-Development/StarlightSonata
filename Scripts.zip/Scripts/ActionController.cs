using System;
using System.Collections.Generic;

[Serializable]
public class ActionController : StatController
{
    bool _init = false;
    int _currentMinorActions = 1;
    int _currentMajorActions = 1;
    bool _unaware = false;
    bool _surprised = false;
    bool _conscious = true;

    ///support variable
    int _tma = 0;

    public int currentMinorActions
    {
        get { return _currentMinorActions; }
        set
        {
            try
            {
                if (value >= 0)
                {
                    _currentMinorActions = value;
                }
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int currentMajorActions
    {
        get { return _currentMajorActions; }
        set
        {
            try
            {
                if (value <= 1)
                {
                    _currentMajorActions = value;
                }
                else
                {
                    Utilities.wrErr("<" + this.GetType() + "> Heres the problem:" + value);
                }
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int totalMinorActions
    {
        get
        {
            try
            {
                _tma = 1 + entity.initiativeDice;
                if (_tma > 0)
                {
                    if (_tma > 5)
                    {
                        _tma = 5;
                    }

                    return _tma;
                }

                return 0;
            }
            catch
            {
                Utilities.wrErr("<" + this.GetType() + "> TMA 	Try again...");
            }

            return 0;
        }
    }

    public bool unaware
    {
        get { return _unaware; }
        set
        {
            try
            {
                _unaware = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public bool surprised
    {
        get { return _surprised; }
        set
        {
            try
            {
                _surprised = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public bool conscious
    {
        get { return _conscious; }
        set
        {
            try
            {
                _conscious = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public List<Action> actions = new List<Action>();

// I Major
    public Action attack = new Attack();
    public Action pickUpPutDownObject = new PickUpPutDownObject();
    public Action observeInDetail = new ObserveInDetail();
    public Action readyWeapon = new ReadyWeapon();
    public Action reloadWeapon = new ReloadWeapon();
    public Action riggerJumpIn = new RiggerJumpIn();
    public Action sprint = new Sprint();
    public Action useSimpleDevice = new UseSimpleDevice();

    public Action useSkill = new UseSkill();

// A Major
    public Action assist = new Assist();

    public Action fullDefense = new FullDefense();

// I Minor
    public Action callAShot = new CallAShot();
    public Action commandDrone = new CommandDrone();
    public Action dropProne = new DropProne();
    public Action move = new Move();
    public Action multipleAttacks = new MultipleAttacks();
    public Action quickDraw = new QuickDraw();
    public Action reloadSmartgun = new ReloadSmartgun();
    public Action standUp = new StandUp();
    public Action takeAim = new TakeAim();
    public Action takeCover = new TakeCover();

    public Action trip = new Trip();

// A Minor
    public Action avoidIncoming = new Avoidlncoming();
    public Action block = new Block();
    public Action changeDeviceMode = new ChangeDeviceMode();
    public Action dodge = new Dodge();
    public Action dropObject = new DropObject();

    public Action hitTheDirt = new HitTheDirt();
    public Action intercept = new Intercept();

    public override void CGO_InitializeControllableStats()
    {
        if (_init)
        {
            return;
        }

        _init = true;
// Major initiative
        Control(attack);
        Control(pickUpPutDownObject);
        Control(observeInDetail);
        Control(readyWeapon);
        Control(reloadWeapon);
        Control(riggerJumpIn);
        Control(sprint);
        Control(useSimpleDevice);
        Control(useSkill);
// Major Anytime
        Control(assist);
        Control(fullDefense);
// Minor initiative
        Control(callAShot);
        Control(commandDrone);
        Control(dropProne);
        Control(move);
        Control(multipleAttacks);
        Control(quickDraw);
        Control(reloadSmartgun);
        Control(standUp);
        Control(takeAim);
        Control(takeCover);
        Control(trip);
// Minor Anytime
        Control(avoidIncoming);
        Control(block);
        Control(changeDeviceMode);
        Control(dodge);
        Control(dropObject);
        Control(hitTheDirt);
        Control(intercept);
// Major initiative
        attack.CGO_Initialize(Action.ACTION_NAME.Attack, Action.ACTION_TIME.initiative, Action.ACTION_TYPE.Major);
        pickUpPutDownObject.CGO_Initialize(Action.ACTION_NAME.PickUpPutDownObject, Action.ACTION_TIME.initiative,
            Action.ACTION_TYPE.Major);
        observeInDetail.CGO_Initialize(Action.ACTION_NAME.ObservelnDetail, Action.ACTION_TIME.initiative,
            Action.ACTION_TYPE.Major);
        readyWeapon.CGO_Initialize(Action.ACTION_NAME.ReadyWeapon, Action.ACTION_TIME.initiative,
            Action.ACTION_TYPE.Major);
        reloadWeapon.CGO_Initialize(Action.ACTION_NAME.ReloadWeapon, Action.ACTION_TIME.initiative,
            Action.ACTION_TYPE.Major);
        riggerJumpIn.CGO_Initialize(Action.ACTION_NAME.RiggerJumpIn, Action.ACTION_TIME.initiative,
            Action.ACTION_TYPE.Major);
        sprint.CGO_Initialize(Action.ACTION_NAME.Sprint, Action.ACTION_TIME.initiative, Action.ACTION_TYPE.Major);

        useSimpleDevice.CGO_Initialize(Action.ACTION_NAME.UseSimpleDevice, Action.ACTION_TIME.initiative,
            Action.ACTION_TYPE.Major);
        useSkill.CGO_Initialize(Action.ACTION_NAME.UseSkill, Action.ACTION_TIME.initiative, Action.ACTION_TYPE.Major);
// Major Anytime
        assist.CGO_Initialize(Action.ACTION_NAME.Assist, Action.ACTION_TIME.Anytime, Action.ACTION_TYPE.Major);
        fullDefense.CGO_Initialize(Action.ACTION_NAME.FullDefense, Action.ACTION_TIME.Anytime,
            Action.ACTION_TYPE.Major);
// Minor initiative
        callAShot.CGO_Initialize(Action.ACTION_NAME.CallAShot, Action.ACTION_TIME.initiative, Action.ACTION_TYPE.Minor);
        commandDrone.CGO_Initialize(Action.ACTION_NAME.CommandDrone, Action.ACTION_TIME.initiative,
            Action.ACTION_TYPE.Minor);
        dropProne.CGO_Initialize(Action.ACTION_NAME.DropProne, Action.ACTION_TIME.initiative, Action.ACTION_TYPE.Minor);
        move.CGO_Initialize(Action.ACTION_NAME.Move, Action.ACTION_TIME.initiative,
            Action.ACTION_TYPE.Minor);
        multipleAttacks.CGO_Initialize(Action.ACTION_NAME.MultipleAttacks, Action.ACTION_TIME.initiative,
            Action.ACTION_TYPE.Minor);
        quickDraw.CGO_Initialize(Action.ACTION_NAME.QuickDraw, Action.ACTION_TIME.initiative, Action.ACTION_TYPE.Minor);
        reloadSmartgun.CGO_Initialize(Action.ACTION_NAME.ReloadSmartgun, Action.ACTION_TIME.initiative,
            Action.ACTION_TYPE.Minor);
        standUp.CGO_Initialize(Action.ACTION_NAME.StandUp, Action.ACTION_TIME.initiative, Action.ACTION_TYPE.Minor);
        takeAim.CGO_Initialize(Action.ACTION_NAME.TakeAim, Action.ACTION_TIME.initiative, Action.ACTION_TYPE.Minor);
        takeCover.CGO_Initialize(Action.ACTION_NAME.TakeCover, Action.ACTION_TIME.initiative, Action.ACTION_TYPE.Minor);
        trip.CGO_Initialize(Action.ACTION_NAME.Trip, Action.ACTION_TIME.initiative, Action.ACTION_TYPE.Minor);
// Minor Anytime
        avoidIncoming.CGO_Initialize(Action.ACTION_NAME.AvoidIncoming, Action.ACTION_TIME.Anytime,
            Action.ACTION_TYPE.Minor);
        block.CGO_Initialize(Action.ACTION_NAME.Block, Action.ACTION_TIME.Anytime, Action.ACTION_TYPE.Minor);
        changeDeviceMode.CGO_Initialize(Action.ACTION_NAME.ChangeDeviceMode, Action.ACTION_TIME.Anytime,
            Action.ACTION_TYPE.Minor);
        dodge.CGO_Initialize(Action.ACTION_NAME.Dodge, Action.ACTION_TIME.Anytime, Action.ACTION_TYPE.Minor);

        dropObject.CGO_Initialize(Action.ACTION_NAME.DropObject, Action.ACTION_TIME.Anytime, Action.ACTION_TYPE.Minor);
        hitTheDirt.CGO_Initialize(Action.ACTION_NAME.HitTheDirt, Action.ACTION_TIME.Anytime, Action.ACTION_TYPE.Minor);
        intercept.CGO_Initialize(Action.ACTION_NAME.Intercept, Action.ACTION_TIME.Anytime, Action.ACTION_TYPE.Minor);
    }

    public void ResetCurrentActions()
    {
        currentMinorActions = totalMinorActions;
        currentMajorActions = 1;
    }

    public void ReduceCurrentActions(Action.ACTION_TYPE actionType)
    {
        switch (actionType)
        {
            case Action.ACTION_TYPE.Minor:
            {
                if (currentMinorActions >= 1)
                {
                    --currentMinorActions;
                }
                else if (currentMajorActions >= 1)
                {
                    --currentMajorActions;
                }

                break;
            }
            case Action.ACTION_TYPE.Major:
            {
                if (currentMajorActions >= 1)
                {
                    --currentMajorActions;
                }
                else if (currentMinorActions >= 4)
                {
                    currentMinorActions -= 4;
                }

                break;
            }
        }
    }

    public void SetSurprised(bool sup)
    {
        surprised = sup;
    }

    public void SetUnaware(bool un)
    {
        unaware = un;
    }

    public void SetConscious(bool con)
    {
        conscious = con;
    }
}