using System;

[Serializable]
public class NPC : Entity
{
//This will be where Conversations, Dispositions,
//Other Al Interactive chunks of code are added later.
    public override void SetControllableStats()
    {
    }
}