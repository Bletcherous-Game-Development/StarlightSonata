// the buffs, debuffs, etc. ie slappatches, toxins, medkits, one-shot nano tech, etc. even qualities/gear/stati
public interface IAffector 
{
    // needs a visit for every class that could be affected by the above list
    void Visit(IAffectable iA);
}