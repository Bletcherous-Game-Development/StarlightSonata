using System;

[Serializable]
public class Status : ControllableStat, IAffector // what does a status affect?
{
    private string _sValue = "";
    bool _bValue = false;
    float _fValue = 0.0f;
    int _iValue = 0;
    int _rating = 1;
    int _durration = 1;

    /// in rounds
    int _remainingDurration = 0;

// TODO: handle variables
    public enum STATUS_TYPE
    {
        Blinded, //1-3
        Burning, //#
        Chilled,
        Confused, //#
        Corrosive, //#
        Cover, //1-4
        Deafened, //1-3
        Frightened,
        Hazed,
        Hobbled,
        Immobilized,
        Invisible, //#
        Invisible_Improved, //#
        Nauseated,
        Panicked,
        Petrified,
        Poisoned, //#
        Prone,
        Silent, //#
        Silent_Improved, //#
        Stilted,
        Wet,
        Zapped

    }
/* public string name{
    get{
        return _name;}
    set{
        try{
            _name = value;}
        catch{
            Utilities.wrErr(GetType() + " Property set errror!!!");}}}*/

    public string sValue
    {
        get { return _sValue; }
        set
        {
            try
            {
                _sValue = value;
            }
            catch
            {
                Utilities.wrErr(GetType() + " Property set errror!!!");
            }
        }
    }

    public bool bValue
    {
        get { return _bValue; }
        set
        {
            try
            {
                _bValue = value;
            }
            catch
            {
                Utilities.wrErr(GetType() + " Property set errror!!!");
            }
        }
    }

    public float falue
    {
        get { return _fValue; }
        set
        {

            try
            {
                _fValue = value;
            }
            catch
            {
                Utilities.wrErr(GetType() + " Property set errror!!!");
            }
        }
    }

    public int iValue
    {
        get { return _iValue; }
        set
        {
            try
            {
                _iValue = value;
            }
            catch
            {
                Utilities.wrErr(GetType() + " Property set errror!!!");
            }
        }
    }

// needs a visit for every cclass that is directly affected by various stati, or inherited children do
    public void Visit(IAffectable iA)
    {
        Skill s = (Skill)iA;
        s.rank = iValue;
    }

    public int rating
    {
        get { return _rating; }
        set
        {
            try
            {
                _rating = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int durration
    {
        get { return _durration; }
        set
        {
            try
            {
                _durration = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int remainingDurration
    {
        get { return _remainingDurration; }
        set
        {
            try
            {
                _remainingDurration = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public virtual void Apply()
    {
// TODO:
    }

    public virtual void Remove()
    {
// TODO:
    }
}