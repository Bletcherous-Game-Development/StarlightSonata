// All Ranged_Weapons are Weapons, but not all Weapons are Ranged_Weapons
using System;
using System.Collections.Generic;

[Serializable]
public class RangedWeapon : Weapon
{
    int _ammunitionCapacity = 0;
    AMMUNITION_CONTAINER_TYPE _ammunitionContainerType = AMMUNITION_CONTAINER_TYPE.Undefined;
    RANGED_WEAPON_DESIGNATION _designation = RANGED_WEAPON_DESIGNATION.Undefined;
    AmmunitionContainer _ammunitionContainer;

    public enum AMMUNITION_CONTAINER_TYPE
    {
        Belt,
        Clip,
        Cylinder,
        Magazine,
        Missile,
        Muzzleloader,
        Undefined
    }

    public enum WEAPON_MODE
    {

        SS,
        SA,
        BF,
        FA,
        Undefined
    }

// so the right clips and rounds work in the right weapons
    public enum RANGED_WEAPON_DESIGNATION
    {
        StreetlineSpecial,
        AresPredatorVI,
        AresAlpha,
        Undefined
    }

    public List<WEAPON_MODE> weaponModes = new List<WEAPON_MODE>();

    public int ammunitionCapacity
    {
        get { return _ammunitionCapacity; }
        set
        {
            try
            {
                _ammunitionCapacity = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public AMMUNITION_CONTAINER_TYPE ammunitionContainerType
    {
        get { return _ammunitionContainerType; }
        set
        {
            try
            {
                _ammunitionContainerType = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public RANGED_WEAPON_DESIGNATION designation
    {
        get { return _designation; }
        set { _designation = value; }
    }

    public AmmunitionContainer ammunitionContainer
    {
        get { return _ammunitionContainer; }
        set { _ammunitionContainer = value; }
    }

    public int currentAmmunitionCount
    {
        get
        {
            if (!Utilities.isntNull(ammunitionContainer))
            {
                return 0;
            }

            return ammunitionContainer.currentAmmunitionCount;
        }
        set
        {
            try
            {
                ammunitionContainer.currentAmmunitionCount = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public void AddWeaponMode(WEAPON_MODE mode)
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        weaponModes.Add(mode);
    }

    public void Fire(int ammunitionFired)
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        if (currentAmmunitionCount >= ammunitionFired)
        {
            currentAmmunitionCount -= ammunitionFired;
            Utilities.wrForce("ammunitionFired:" + ammunitionFired);
        }
        else
        {

            Utilities.wrErr("<" + this.GetType() + "> Not enough ammunition");
        }
    }

// also modifies the AR and Damage based on the ammo loaded
    public void ReloadRangedWeapon(AmmunitionContainer aCon)
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        Utilities.wr("***<==8_ReloadRangedWeapon_8==>***");
        if (aCon.designation == designation)
        {
            if (aCon.ammunitionContainerType == ammunitionContainerType)
            {
                if (Utilities.isntNull(ammunitionContainer))
                {
/*
there is already an ammunitionContainer, Eject the ammunitionContainer
Instance the ammunitionContainer and drop or whatever
ammunitionContainer oldAmmunitionContainer = ammunitionContainer;
*/
                }

                ///no ammunitionContainer, make a copy before transfering.
                ammunitionContainer = aCon;
                ammunitionContainer.SetName((ammunitionContainer.designation.ToString() + 
                                             ammunitionContainer.ammunitionContainerType.ToString()));
                if (Utilities.isntNull(ammunitionContainer.containedAmmunition))
                {
                    ModifyAttackRating(ammunitionContainer.containedAmmunition.modifier_AR);
                    ModifyDamage(ammunitionContainer.containedAmmunition.modifier_DV,
                        ammunitionContainer.containedAmmunition.modifiedDamageType,
                        ammunitionContainer.containedAmmunition.modifiedElementalDamage);
                }
            }
            else
            {
                Utilities.wrForce("ammunitionContainer" + ammunitionContainer.CGO_Name +
                                  " is the wrong ammunitionContainerType");
            }
        }
        else
        {
            Utilities.wrErr("<" + this.GetType() + "> Wrong designation");
        }
    }
}
