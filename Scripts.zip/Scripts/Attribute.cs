using System;
[Serializable]
public class Attribute : RankedStat // BARSWLICEEA+
{
    ATTRIBUTE_NAME _attributeName = ATTRIBUTE_NAME.Undefined;

    public enum ATTRIBUTE_NAME
    {
        Body,
        Agility,
        Reaction,
        Strength,
        Willpower,
        Logic,
        Intuition,
        Charisma,
        Edge,
        Essence,

        Armor,
        Attack,
        Sleaze,
        DataProcessing,
        Firewall,
        DeviceRating,
        Depth,
        Handling,
        Acceleration,
        SpeedInterval,
        TopSpeed,
        Pilot,
        Sensor,
        Seat,
        Undefined

    }

    public void CGO_Initialize(ATTRIBUTE_NAME aN)
    {
        SetAttributeName(aN);
        SetName(attributeName.ToString());
        base.CGO_Initialize();
    }

    public ATTRIBUTE_NAME attributeName
    {
        get { return _attributeName; }
        set
        {
            try
            {
                _attributeName = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public void SetAttributeName(ATTRIBUTE_NAME aN)
    {
        attributeName = aN;
    }
}