using System;

[Serializable]
public class ThermographicVision : Quality
{
    public override void GameEffect()
    {
        if (Utilities.isNull(entity))
        {
            return;
        }

        SetQualityType(QUALITY_TYPE.Positive);
        SetKarmaCost(8);
    }

    public override void ReverseEffect()
    {
        base.ReverseEffect();
    }
}