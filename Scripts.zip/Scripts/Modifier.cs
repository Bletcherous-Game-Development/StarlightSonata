using System;
[Serializable]
public class Modifier
{
    float _modifier = 0.0f;
    string _name = "";

    public float modifier
    {
        get { return _modifier; }
        set
        {
            try
            {
                _modifier = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public string name
    {
        get { return _name; }
        set
        {
            try
            {
                _name = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public Modifier(string namu, float mod)
    {
        name = namu;
        modifier = mod;
    }
}