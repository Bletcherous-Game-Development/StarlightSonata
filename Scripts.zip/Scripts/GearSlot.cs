// Separate class to hold the gear, it just worked better this way for referencing, etc.
using System;

[Serializable]
public class GearSlot : ControllableStat
{
    public Gear slottedGear;
    GEAR_SLOT_NAME _gearSlotName = GEAR_SLOT_NAME.Undefined;

    public GEAR_SLOT_NAME gearSlotName
    {
        get { return _gearSlotName; }
        set
        {
            try
            {
                _gearSlotName = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public enum GEAR_SLOT_NAME
    {
        LeftHip,
        RightHip,
        LeftAnkle,
        RightAnkle,
        LeftShoulder,
        RightShoulder,
        LeftUnderarm,
        RightUnderarm,
        LeftArmSlide,
        RightArmSlide,
        LeftCyberarm,
        RightCyberarm,
        LeftCyberleg,
        RightCyberleg,
        Cybertorso,
        LeftHand,
        RightHand,
        TacticalSling,
        LeftSlungOnBack,
        RightSlungOnBack,
        FrontWaistband,
        BackWaistband,
        Mount0,
        Mount1,
        Mount2,
        Mount3,
        Pack,
        Pocket0,
        Pocket1,
        Pocket2,
        Pocket3,
        Undefined
    }

    public void CGO_Initialize(GearSlot.GEAR_SLOT_NAME gS)
    {
        gearSlotName = gS;
        SetName(gearSlotName.ToString());
        base.CGO_Initialize();
    }
}