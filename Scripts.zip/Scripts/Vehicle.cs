// all vehicles are devices, but not all vehicles are drones, covers anything not considered a drone
using System;
using System.Collections.Generic;

[Serializable]
public class Vehicle : Entity
{
// TODO: if pilot.rank > 0, set a device with stats set to pilot
    private int _speed = 0;
    VEHICLE_CATAGORY _vehicleCatagory;
    VEHICLE_SIZE _vehicleSize;
    SECONDARY_PROPULSION _secondaryPropulsion;
    public Entity _entityPilot;
    public Skill _entityPilotSkill;
    public Device _vehicleDevice;
    public List<VehicleModification> vehicleModifications = new List<VehicleModification>();
    public List<VehicleAccessory> vehicleAccessories = new List<VehicleAccessory>();

    public enum VEHICLE_CATAGORY
    {
        Car,
        Truck,
        Van,
        Boat,
        Submarine,
        FixedWingAircraft,
        Rotorcraft,
        VTOL_VSTOL
    }

    public enum VEHICLE_SIZE
    {
        Miniscule,
        Tiny,
        Small,
        Average,
        Bulky,
        Large,
        Huge
    }

    public enum SECONDARY_PROPULSION
    {
        AmphibiousSurface,
        AmphibiousSubmersible,
        Hovercraft,
        Rotor,
        Tracked,
        Walker
    }

    public int speed
    {
        get { return _speed; }
        set
        {
            try
            {
                _speed = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public VEHICLE_CATAGORY vehicleCatagory
    {
        get { return _vehicleCatagory; }
        set
        {
            try
            {
                _vehicleCatagory = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public VEHICLE_SIZE vehicleSize
    {
        get { return _vehicleSize; }
        set
        {
            try
            {
                _vehicleSize = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public SECONDARY_PROPULSION secondaryPropulsion
    {
        get { return _secondaryPropulsion; }
        set
        {
            try
            {
                _secondaryPropulsion = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public override void CGO_Initialize()
    {
        base.CGO_Initialize();
//gearSlotController.Control(gearSlotController.MountO);
//gearSlotController.Control(gearSlotController.Mountl);} public override void SetControllableStats(){
        SetAttributes();
        SetConditionMonitors();
    }

    public override void SetAttributes()
    {
        Attribute handling = new Attribute();
        Attribute acceleration = new Attribute();

        Attribute speedInterval = new Attribute();
        Attribute topSpeed = new Attribute();
        Attribute body = new Attribute();
        Attribute armor = new Attribute();
        Attribute pilot = new Attribute();
        Attribute sensor = new Attribute();
        Attribute seat = new Attribute();
        attributeController.Control(handling);
        attributeController.Control(acceleration);
        attributeController.Control(speedInterval);
        attributeController.Control(topSpeed);
        attributeController.Control(body);
        attributeController.Control(armor);
        attributeController.Control(pilot);
        attributeController.Control(sensor);
        attributeController.Control(seat);
        handling.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Handling);
        acceleration.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Acceleration);
        speedInterval.CGO_Initialize(Attribute.ATTRIBUTE_NAME.SpeedInterval);
        topSpeed.CGO_Initialize(Attribute.ATTRIBUTE_NAME.TopSpeed);
        body.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Body);
        armor.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Armor);
        pilot.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Pilot);
        sensor.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Sensor);
        seat.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Seat);
    }

    public override void SetConditionMonitors()
    {
        if (Utilities.isNull(attributeController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".attributecontroller is null!");
            return;
        }

        if (Utilities.isNull(conditionMonitorController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".conditionMonitorController is null!");
            return;
        }

        ConditionMonitor physical = new ConditionMonitor();
        conditionMonitorController.Control(physical);
        foreach (Attribute a in attributeController.controlledStats)
        {
            if (a.attributeName == Attribute.ATTRIBUTE_NAME.Body)
            {
                physical.CGO_Initialize(Damage.DAMAGE_TYPE.Physical, a);
            }
        }
    }
}
