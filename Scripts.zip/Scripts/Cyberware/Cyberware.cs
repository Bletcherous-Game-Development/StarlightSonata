using System;

[Serializable]
public class Cyberware : Augmentation
{
    public void CGO_Initialize(AUGMENTATION_NAME aN, int co, int avail, LEGALITY leg, WARE_GRADE grade, float essCost)
    {
        base.CGO_Initialize(aN, co, avail, leg, grade, Augmentation.WARE_TYPE.Cyberware, essCost);
    }
}

