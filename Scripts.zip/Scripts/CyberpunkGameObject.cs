using System;
using UnityEngine;

[Serializable]
public class CyberpunkGameObject:MonoBehaviour // the parent class for all interactable things in game
{
    private string _cgoName = "";
    GameMaster _GM = null;
    bool _isGMd = false;
    bool _isActive = false;
    public string CGO_Name
    {
        get { return _cgoName; }
        set
        {
            try
            {
                _cgoName = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }

    public bool isGMd
    {
        get { return _isGMd; }
        set
        {
            try
            {
                isGMd = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }

    public GameMaster GM
    {
        get { return _GM; }
        set
        {
            try
            {
                _GM = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }

    public bool isActive
    {
        get { return _isActive; }
        set
        {
            try
            {
                _isActive = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }

    public void SetActive(bool iA)
    {
        isActive = iA;
    }

    public void SetName(string namu)
    {
        CGO_Name = namu;
    }

    public void SetGM(GameMaster gm)
    {
        GM = gm;
    }

    public void SetIsGMd(bool gm)
    {
        isGMd = true;
    }

    public virtual void CGO_Initialize(GameMaster gm)
    {
        SetGM(gm);
        CGO_Initialize();
    }

    public virtual void CGO_Initialize()
    {
        if (Utilities.isNull(GM))
        {
// SetGM(GameObject.Find<GameMaster>());
            Utilities.wr("<" + this.GetType().Name + "> " + CGO_Name + ".GM is null!");
            return;
        }
    }

    public virtual void CGO_Initialize(string namu)
    {
        SetName(namu);
        CGO_Initialize();
    }
}