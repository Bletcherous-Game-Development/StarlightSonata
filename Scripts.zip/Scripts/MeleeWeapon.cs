// All Melee_Weapons are Weapons, but not all Weapons are Melee_Weapons
using System;

[Serializable]
public class MeleeWeapon : Weapon
{
    public override void CGO_Initialize()
    {
        base.CGO_Initialize();
        weaponCatagory = WEAPON_CATAGORY.Melee;
    }
}