// Character Creation interface!
using System;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class CharacterEditor:MonoBehaviour
{
	int _metatypeAdjustmentPoints = 0;
	int _attributePoints = 0;
	int _skillPoints = 0;
	int _resources = 0;
	int _karma = 0;

	enum BACK_TO
	{
		LoadOrCreateCharacter,
		LoadCharacter,
		CreateCharacter,
		Undefined
	}

	public Character character;
	public GameMaster GM;
	public TextMeshProUGUI inputText;
	public string characterName = "";

	public void enter()
	{
		
	}
	void MenuNav(BACK_TO backTo, BACK_TO currentMenu, ref Character character, GameMaster gm, ref string msg)
	{
		Utilities.wrForce("type 'back' to go back");
		msg = Console.ReadLine();
		switch (msg)
		{
			case "back":
			{
				switch (backTo)
				{
					case BACK_TO.LoadOrCreateCharacter:
					{
						LoadOrCreateCharacter(ref character, gm);
						break;
					}
					case BACK_TO.LoadCharacter:
					{
						LoadCharacter(ref character, gm);
						break;
					}
					case BACK_TO.CreateCharacter:
					{
						CreateCharacter(ref character, gm);
						break;
					}
				}

				break;
			}
			case "":
			{
				switch (currentMenu)
				{
					case BACK_TO.LoadOrCreateCharacter:
					{
						LoadOrCreateCharacter(ref character, gm);
						break;
					}
					case BACK_TO.LoadCharacter:
					{
						LoadCharacter(ref character, gm);
						break;
					}
					case BACK_TO.CreateCharacter:
					{
						CreateCharacter(ref character, gm);
						break;
					}
				}

				break;
			}
		}
	}


	public void LoadOrCreateCharacter(ref Character character, GameMaster gm) // text interface to load or create a Character^
	{
		string msg = "";
		Utilities.wrForce("Welcome to CyberpunkGame.");
		Utilities.wrForce("Enter 1 to LoadCharacter...");
		Utilities.wrForce("Enter 2 to CreateCharacter.");
		MenuNav(BACK_TO.LoadOrCreateCharacter, BACK_TO.LoadOrCreateCharacter, ref character, gm, ref msg);
		switch (msg)
		{
			///LoadCharacter
			case "1":
			{
				LoadCharacter(ref character, gm);
				break;
			}
			///NewPlayer
			case "2":
			{
				CreateCharacter(ref character, gm);
				break;
			}
			default:
			{
				LoadOrCreateCharacter(ref character, gm);
				break;
			}
		}
	}

	void LoadCharacter(ref Character character, GameMaster gm)
// LoadOrCreateCharacter option 1. Ill returns a choice to load a Character from a list of saved players or delete.
	{
		string msg = "";
		try
		{

			string f = SaveData.FilePath;
			string[] files = Directory.GetFiles(SaveData.FilePath);
			string[] playerNames = new string[files.Length];
			for (int i = 0; i < files.Length; ++i)
			{
				string[] pieces = files[i].Split('\\');
				playerNames[i] = pieces[pieces.Length - 1];
				Utilities.wrForce(i + " " + pieces[pieces.Length - 1]);
			}

			Utilities.wrForce("***<==8_LoadPlayer_8==>***");
			Utilities.wrForce("Enter number of playerName to LoadCharacter.");
			Utilities.wrForce("...or Enter DeletePlayer to DeletePlayer.");
			MenuNav(BACK_TO.LoadOrCreateCharacter, BACK_TO.LoadCharacter, ref character, gm,
				ref msg);
			string n = playerNames[int.Parse(msg)];
			if (msg == "DeletePlayer")
			{
				Utilities.wrForce("Enter number of playerName to DeletePlayer.");
				msg = Console.ReadLine();
				f += playerNames[int.Parse(msg)];
				File.Delete(f);
				LoadCharacter(ref character, gm);
			}

			f = SaveData.FilePath + n;
			if (File.Exists(f))
			{
				Character p = (Character)SerialLoader.SerialLoad(n);
				p.SetGM(gm);
				character = p;
			}
			else
			{
				LoadOrCreateCharacter(ref character, gm);
			}
		}
		catch
		{
			Utilities.wrErr("LoadCharacter Error");
		}
	}


	public void CreateCharacter_Click()
	{
		characterName = inputText.text;
		CreateCharacter(ref character, GM);
	}
	
	public void CreateCharacter(ref Character character, GameMaster gm) //LoadOrCreateCharacter option 2.
	{
		try
		{
			character.SetGM(gm);
			Character.METATYPE _metatype = Character.METATYPE.Baseline;
			_metatypeAdjustmentPoints = 1;
			_attributePoints = 8;
			_skillPoints = 16;
			_resources = 50000;
			_karma = 50;
			SetPriorities(ref _metatype, ref _metatypeAdjustmentPoints, ref _attributePoints, ref _skillPoints, ref _resources);
			character.metatype = _metatype;
			character.CGO_Initialize(characterName);
			character.karma = _karma;
			character.resources = _resources;
			enterStats("Attribute", character, _attributePoints);
			enterMAStats(character, gm, _metatypeAdjustmentPoints);
			enterStats("Skill", character, _skillPoints);
			SpendKarma(ref character, true);
			EnterQualities(ref character, ref _karma);
			EnterOtherStats(ref character);
			//Utilities.wrForce("Welcome to cyberspace " + character.CGO_Name + ".");
		}
		catch
		{
			Utilities.wrErr("CreateCharacter Error");
		}
	}

// TODO: finished putting it all together and make a back button
	void SetPriorities(ref Character.METATYPE metatype, ref int metatypeAdjustmentRoints, ref int attributePoints,
		ref int skillPoints, ref int resourcePoints)
	{
/* Character.METATYPE metatype = Character.METATYPE.Baseline;
int metatypeAdjustmentPoints = 1;
int attributePoints = 8;
int skillPoints = 16;
int resourcePoints = 50000;*/
		PRIORITY meta = PRIORITY.A;
		PRIORITY attributes = PRIORITY.A;
		PRIORITY skills = PRIORITY.A;
		PRIORITY resources = PRIORITY.A;
		List<PRIORITY> remainingPriorities = new List<PRIORITY>();
		remainingPriorities.Add(PRIORITY.A);
		remainingPriorities.Add(PRIORITY.B);
		remainingPriorities.Add(PRIORITY.C);
		remainingPriorities.Add(PRIORITY.D);
/*
PRIORITY	metatype (Adjustment Points)	skills	resources

A	HighGrav, Bespoke, VatGrown (13)	14	32	450k
B	HighGrav, Lowgrav, Bespoke, VatGrown (11)	16	24	275k
C	HighGrav, Lowgrav, Bespoke, VatGrown (9)	12	20	150k
D	HighGrav, Lowgrav, Baseline Bespoke, VatGrown (4)	8	16	50k
*/
		string m1_msg = "Priority	Metatype (Adjustment Points)";
		string mA_msg = "A	HighGrav, Bespoke, VatGrown (13)";
		string mB_msg = "B	HighGrav, Lowgrav, Bespoke, VatGrown (11)";
		string mC_msg = "C	HighGrav, Lowgrav, Bespoke, VatGrown (9)";
		string mD_msg = "D	HighGrav, Lowgrav, Baseline Bespoke, VatGrown (4)";
		string m2_msg = "Choose a metatype PRIORITY...";
		string[] m = new string[] { mA_msg, mB_msg, mC_msg, mD_msg };
		string a1_msg = "Priority	attributes";
		string aA_msg = "A	24";
		string aB_msg = "B	16";
		string aC_msg = "C	12";
		string aD_msg = "D	8";
		string a2_msg = "Choose attributes PRIORITY...";
		string[] a = new string[] { aA_msg, aB_msg, aC_msg, aD_msg };
		string s1_msg = "Priority	skills";
		string sA_msg = "A	32";
		string sB_msg = "B	24";
		string sC_msg = "C	20";
		string sD_msg = "D	16";
		string s2_msg = "Choose Skills PRIORITY...";
		string[] s = new string[] { sA_msg, sB_msg, sC_msg, sD_msg };
		string r1_msg = "Priority Resources";
		string rA_msg = "A	450k";
		string rB_msg = "B	275k";
		string rC_msg = "C	150k";
		string rD_msg = "D	50k";
		string r2_msg = "Choose resources PRIORITY...";
		string[] r = new string[] { rA_msg, rB_msg, rC_msg, rD_msg };
		List<string[]> priorityMSGs = new List<string[]>();
		priorityMSGs.Add(m);
		priorityMSGs.Add(a);
		priorityMSGs.Add(s);
		priorityMSGs.Add(r);
		priorityDialogue(m1_msg, m2_msg, ref m, ref meta, ref remainingPriorities, ref priorityMSGs);
		metatype = metatypeChoice(meta);
		priorityDialogue(a1_msg, a2_msg, ref a, ref attributes, ref remainingPriorities, ref priorityMSGs);
		priorityDialogue(s1_msg, s2_msg, ref s, ref skills, ref remainingPriorities, ref priorityMSGs);
		priorityDialogue(r1_msg, r2_msg, ref r, ref resources, ref remainingPriorities, ref priorityMSGs);
		switch (meta)
		{
			case PRIORITY.A:
			{
				_metatypeAdjustmentPoints = 13;
				break;
			}
			case PRIORITY.B:
			{
				_metatypeAdjustmentPoints = 11;
				break;
			}
			case PRIORITY.C:
			{
				_metatypeAdjustmentPoints = 9;
				break;
			}
			case PRIORITY.D:
			{
				_metatypeAdjustmentPoints = 4;
				break;
			}
		}

		switch (attributes)
		{
			case PRIORITY.A:
			{
				attributePoints = 24;
				break;
			}
			case PRIORITY.B:
			{
				attributePoints = 16;
				break;
			}
			case PRIORITY.C:
			{
				attributePoints = 12;
				break;
			}
			case PRIORITY.D:
			{
				attributePoints = 8;
				break;
			}
		}

		switch (skills)
		{
			case PRIORITY.A:
			{
				skillPoints = 32;
				break;
			}
			case PRIORITY.B:
			{
				skillPoints = 24;
				break;
			}
			case PRIORITY.C:
			{
				skillPoints = 20;
				break;
			}
			case PRIORITY.D:
			{
				skillPoints = 16;
				break;
			}
		}

		switch (resources)
		{
			case PRIORITY.A:
			{
				resourcePoints = 450000;
				break;
			}
			case PRIORITY.B:
			{
				resourcePoints = 275000;
				break;
			}
			case PRIORITY.C:
			{
				resourcePoints = 150000;
				break;
			}
			case PRIORITY.D:
			{
				resourcePoints = 50000;
				break;
			}
		}

		Utilities.wrForce("Metatype Priority " + meta.ToString() + "" + meta.ToString() + " (" +
		                  _metatypeAdjustmentPoints.ToString() + ")");
		Utilities.wrForce("Attribute Priority " + attributes.ToString() + "" + attributePoints.ToString());
		Utilities.wrForce("skills Priority " + skills.ToString() + "" + skillPoints.ToString());
		Utilities.wrForce("Resources Priority" + resources.ToString() + ": Y" + resourcePoints.ToString());
	}

	enum PRIORITY
	{
// enum for CreateCharacter
		A,
		B,
		C,
		D,
		E, // not used (mundane)
		Undefined
	}

	PRIORITY priorityChoice(ref List<PRIORITY> _remainingPriorities, ref List<string[]> _priorityMSGs)
	{
// helper function for CreateCharacter. saves choice and removes it from the other catagories{
		string choice = Console.ReadLine();
		switch (choice)
		{
			case "a":
			{
				if (_remainingPriorities.Contains(PRIORITY.A))
				{
					_remainingPriorities.Remove(PRIORITY.A);
					foreach (string[] s in _priorityMSGs)
					{
						s[0] = "";
					}

					return PRIORITY.A;
				}
				else
				{
					Utilities.wrForce("Choose again from these Priorities:");
					foreach (PRIORITY p in _remainingPriorities)
					{
						Utilities.wrForce(p.ToString());
					}

					priorityChoice(ref _remainingPriorities, ref _priorityMSGs);
				}

				return priorityChoice(ref _remainingPriorities, ref _priorityMSGs);
			}
			case "b":
			{
				if (_remainingPriorities.Contains(PRIORITY.B))
				{
					_remainingPriorities.Remove(PRIORITY.B);
					foreach (string[] s in _priorityMSGs)
					{
						s[1] = "";
					}

					return PRIORITY.B;
				}
				else
				{
					Utilities.wrForce("Choose again from these Priorities:");
					foreach (PRIORITY p in _remainingPriorities)
					{
						Utilities.wrForce(p.ToString());
					}

					priorityChoice(ref _remainingPriorities, ref _priorityMSGs);
				}

				return priorityChoice(ref _remainingPriorities, ref _priorityMSGs);
			}
			case "c":
			{
				if (_remainingPriorities.Contains(PRIORITY.C))
				{
					_remainingPriorities.Remove(PRIORITY.C);
					foreach (string[] s in _priorityMSGs)
					{
						s[2] = "";
					}

					return PRIORITY.C;
				}
				else
				{
					Utilities.wrForce("Choose again from these Priorities:");
					foreach (PRIORITY p in _remainingPriorities)
					{
						Utilities.wrForce(p.ToString());
					}

					priorityChoice(ref _remainingPriorities, ref _priorityMSGs);
				}

				return priorityChoice(ref _remainingPriorities, ref _priorityMSGs);
			}
			case "d":
			{
				if (_remainingPriorities.Contains(PRIORITY.D))
				{
					_remainingPriorities.Remove(PRIORITY.D);


					foreach (string[] s in _priorityMSGs)
					{
						s[3] = "";
					}

					return PRIORITY.D;
				}
				else
				{
					Utilities.wrForce("Choose again from these Priorities:");
					foreach (PRIORITY p in _remainingPriorities)
					{
						Utilities.wrForce(p.ToString());
					}

					priorityChoice(ref _remainingPriorities, ref _priorityMSGs);
				}

				return priorityChoice(ref _remainingPriorities, ref _priorityMSGs);
			}
			default:
			{
				Utilities.wrForce("Choose again from these Priorities:");
				foreach (PRIORITY p in _remainingPriorities)
				{
					Utilities.wrForce(p.ToString());
				}

				return priorityChoice(ref _remainingPriorities, ref _priorityMSGs);
			}
		}
	}

	void priorityDialogue(string _msg1, string _msg2, ref string[] _msgs, ref PRIORITY _priority, ref
		List<PRIORITY> _remainingPriorities, ref List<string[]> _priorityMSGs) // helper function for CreateCharacter
	{
		Utilities.wrForce(_msg1);
		foreach (string msg in _msgs)
		{
			Utilities.wrForce(msg);
		}

		Utilities.wrForce(_msg2);
		_priority = priorityChoice(ref _remainingPriorities, ref _priorityMSGs);
		Utilities.wrForce();
	}

	void metatypeChoiceDialogue(Character.METATYPE[] availableMetatypes,
		ref Character.METATYPE _m) // helper function for CreateCharacter
	{
		Utilities.wrForce("Choose a Metatype...");
		for (int i = 0; i < availableMetatypes.Length; ++i)
		{
			Utilities.wrForce(i.ToString() + ":" + availableMetatypes[i].ToString());
		}

		int choice = int.Parse(Console.ReadLine());
		if (choice < 0 || choice > (availableMetatypes.Length - 1))
		{
			Utilities.wrForce("Choose from the available Metatypes");
			metatypeChoiceDialogue(availableMetatypes, ref _m);
		}

		switch (choice)
		{
			case 0:
			{
				_m = Character.METATYPE.HighGrav;
				break;
			}
			case 1:
			{
				_m = Character.METATYPE.Bespoke;
				break;
			}
			case 2:
			{
				_m = Character.METATYPE.VatGrown;
				break;
			}
			case 3:
			{
				_m = Character.METATYPE.LowGrav;
				break;
			}
			case 4:
			{
				_m = Character.METATYPE.Baseline;
				break;
			}
		}
	}

	Character.METATYPE metatypeChoice(PRIORITY _metatype) // helper function for CreateCharacter
	{
		Character.METATYPE metatype = Character.METATYPE.Baseline;
		Character.METATYPE[] availableMetatypes = new Character.METATYPE[3];
		availableMetatypes[0] = Character.METATYPE.HighGrav;
		availableMetatypes[1] = Character.METATYPE.Bespoke;
		availableMetatypes[2] = Character.METATYPE.VatGrown;
		switch (_metatype)
		{
			case PRIORITY.A:
			{
				metatypeChoiceDialogue(availableMetatypes, ref metatype);
				break;
			}
			case PRIORITY.B:
			{
				availableMetatypes = new Character.METATYPE[4];
				availableMetatypes[0] = Character.METATYPE.HighGrav;
				availableMetatypes[1] = Character.METATYPE.Bespoke;
				availableMetatypes[2] = Character.METATYPE.VatGrown;
				availableMetatypes[3] = Character.METATYPE.LowGrav;
				metatypeChoiceDialogue(availableMetatypes, ref metatype);
				break;
			}
			default:
			{
				if (_metatype == PRIORITY.C || _metatype == PRIORITY.D)
				{
					availableMetatypes = new Character.METATYPE[5];
					availableMetatypes[0] = Character.METATYPE.HighGrav;
					availableMetatypes[1] = Character.METATYPE.Bespoke;
					availableMetatypes[2] = Character.METATYPE.VatGrown;
					availableMetatypes[3] = Character.METATYPE.LowGrav;
					availableMetatypes[4] = Character.METATYPE.Baseline;
					metatypeChoiceDialogue(availableMetatypes, ref metatype);
				}

				break;
			}
		}

		return metatype;
	}

	void EnterOtherStats(ref Character character) // helper for CreateCharacter
	{
		try
		{
			Utilities.wrForce("Enter Character.height in centimeters");
			character.height = float.Parse(Console.ReadLine());
			Utilities.wrForce("Creating character.height:" + character.height);
			Utilities.wrForce("Enter Character.weight in kilograms");
			character.weight = float.Parse(Console.ReadLine());
			Utilities.wrForce("Creating character.weight:" + character.weight);
			Utilities.wrForce("Enter Character.age in years");
			character.age = int.Parse(Console.ReadLine());
			Utilities.wrForce("Creating character.age:" + character.age);
			Utilities.wrForce("Enter Character.sex");
			Utilities.wrForce("0 Male");
			Utilities.wrForce("1 Female");
			Utilities.wrForce("2 Undefined");
			string msg =
				msg = Console.ReadLine();
			switch (msg)
			{
				case "0":
				{
					character.sex = Character.SEX.Male;
					break;
				}
				case "1":
				{
					character.sex = Character.SEX.Female;
					break;
				}
				case "2":
				{
					character.sex = Character.SEX.Undefined;
					break;
				}
			}

			Utilities.wrForce("Creating character.sex:" + character.sex.ToString());
		}
		catch
		{
			Utilities.wrForce("<" + GetType() + "> Try again...");
			EnterOtherStats(ref character);
		}
	}

	void EnterQualities(ref Character character, ref int k) // helper for CreateCharacter
	{
		try
		{
			character.CGO_Initialize(character.CGO_Name);
			Utilities.wrForce("Select qualities");
			List<string> qualityList = new List<string>();
			qualityList.Add("Aptitude");
			qualityList.Add("BuiltTough");
			qualityList.Add("DermalDeposits");
			qualityList.Add("Exceptional");
			qualityList.Add("LowLightVision");
			qualityList.Add("ThermographicVision");
			qualityList.Add("ToxinResistance");
			if (character.metatype == Character.METATYPE.GridGhost)
			{
				qualityList.Remove("BuiltTough");
				qualityList.Remove("DermalDeposits");
				qualityList.Remove("LowLightVision");
				qualityList.Remove("ToxinResistance");
				qualityList.Remove("ThermographicVision");
			}

			if (character.metatype == Character.METATYPE.Baseline)
			{
			}

			if (character.metatype == Character.METATYPE.HighGrav)
			{
				qualityList.Remove("Toxin Resistance");
				qualityList.Remove("ThermographicVision");
			}

			if (character.metatype == Character.METATYPE.LowGrav)
			{
				qualityList.Remove("LowLightVision");
			}

			if (character.metatype == Character.METATYPE.Bespoke)
			{
				qualityList.Remove("LowLightVision");
			}

			if (character.metatype == Character.METATYPE.VatGrown)
			{
				qualityList.Remove("DermalDeposits");
				qualityList.Remove("ThermographicVision");
			}

			Utilities.wrForce(character.CGO_Name + " already has the following free metatype qualities from " +
			                  character.metatype.ToString());
			foreach (Quality q in character.qualityController.controlledStats)
			{
				Utilities.wrForce(q.CGO_Name);
			}

			foreach (string quality in qualityList)
			{
				Utilities.wrForce("Add " + quality + "? - y / n");
				if (Console.ReadLine() == "y")
				{
					switch (quality)
					{
						case "Aptitude":
						{
							AddAptitude(ref character);
							break;
						}
						case "BuiltTough":
						{
							AddBuiltTough(ref character);
							break;
						}
						case "DermalDeposits":
						{
							AddDermalDeposits(ref character);
							break;
						}
						case "Exceptional":
						{
							AddExceptional(ref character);
							break;
						}
						case "LowLightVision":
						{
							AddLowLightVision(ref character);
							break;
						}
						case "ThermographicVision":
						{
							AddThermographicVision(ref character);
							break;
						}
						case "ToxinResistance":
						{
							AddToxinResistance(ref character);
							break;
						}
					}
				}
			}
		}
		catch
		{
			Utilities.wrErr("EnterQualities");
		}
	}

	void AddAptitude(ref Character character) // helper function for EnterQualities
	{
		try
		{
			foreach (Skill skill in character.activeSkillController.controlledStats)
			{
				Utilities.wrForce("aptitude(" + skill.CGO_Name + ") y / n?");
				if (Console.ReadLine() == "y")
				{
					Utilities.wrForce("Adding aptitude(" + skill.CGO_Name + ").");
					character.qualityController.AddQuality(Quality.QUALITY_NAME.Aptitude, skill.skillName);
					break;
				}
			}
		}
		catch
		{
			Utilities.wrErr("AddAptitude");
		}
	}

	void AddBuiltTough(ref Character character) // helper function for EnterQualities
	{
		try
		{
			if (character.metatype != Character.METATYPE.GridGhost)
			{
				int minimum = 1;
				if (character.metatype != Character.METATYPE.Bespoke &&
				    character.metatype != Character.METATYPE.VatGrown)
				{
					Utilities.wrForce("Enter rating 1-4");
				}
				else if (character.metatype == Character.METATYPE.Bespoke)
				{
					minimum = 2;
					Utilities.wrForce("Enter rating 2-4");
				}
				else if (character.metatype == Character.METATYPE.VatGrown)
				{
					minimum = 3;
					Utilities.wrForce("Enter rating 3-4");
				}

				int i = int.Parse(Console.ReadLine());
				if (i <= 4 && i >= minimum)
				{
					Utilities.wrForce("Adding builtTough" + i + ").");
					character.qualityController.AddQuality(Quality.QUALITY_NAME.BuiltTough,
						i);
				}
				else
				{
					AddBuiltTough(ref character);
				}
			}
		}
		catch
		{
			Utilities.wrErr("AddBuiltTough");
		}
	}

	void AddDermalDeposits(ref Character character) // helper function for EnterQualities
	{
		try
		{
			if (character.metatype != Character.METATYPE.GridGhost && character.metatype != Character.METATYPE.VatGrown)
			{
				Utilities.wrForce("Adding dermalDeposits.");
				character.qualityController.AddQuality(Quality.QUALITY_NAME.DermalDeposits);
			}
		}
		catch
		{
			Utilities.wrErr("AddDermalDeposits");
		}
	}

	void AddExceptional(ref Character character) // helper function for EnterQualities
	{
		try
		{
			foreach (Attribute attribute in character.attributeController.controlledStats)
			{
				Utilities.wrForce("exceptional(" + attribute.CGO_Name + ") y / n?");
				if (Console.ReadLine() == "y")
				{
					Utilities.wrForce("Adding exceptional(" + attribute.CGO_Name + ").");
					character.qualityController.AddQuality(Quality.QUALITY_NAME.Exceptional,
						attribute.attributeName);
					break;
				}
			}
		}
		catch
		{
			Utilities.wrErr("AddExceptional");
		}
	}

	void AddLowLightVision(ref Character character) // helper function for EnterQualities
	{
		try
		{
			if (character.metatype != Character.METATYPE.GridGhost && character.metatype !=
			    Character.METATYPE.LowGrav && character.metatype != Character.METATYPE.Bespoke)
			{
				Utilities.wrForce("Adding lowLightVision.");
				character.qualityController.AddQuality(Quality.QUALITY_NAME.LowLightVision);
			}
		}
		catch
		{
			Utilities.wrErr("AddLowLightVision");
		}
	}

	void AddThermographicVision(ref Character character) // helper function for EnterQualities
	{
		try
		{
			if (character.metatype != Character.METATYPE.GridGhost && character.metatype !=
			    Character.METATYPE.HighGrav && character.metatype != Character.METATYPE.VatGrown)
			{
				Utilities.wrForce("Adding thermographicVision.");
				character.qualityController.AddQuality(Quality.QUALITY_NAME.ThermographicVision);
			}
		}
		catch
		{
			Utilities.wrErr("AddThermographicVision");
		}
	}

	void AddToxinResistance(ref Character character) // helper function for EnterQualities
	{
		try
		{
// cause Als cant have it and HighGravs already got it
			if (character.metatype != Character.METATYPE.GridGhost && character.metatype != Character.METATYPE.HighGrav)
			{
				Utilities.wrForce("Adding toxinResistance.");
				character.qualityController.AddQuality(Quality.QUALITY_NAME.ToxinResistance);
			}
		}
		catch
		{
			Utilities.wrErr("AddToxinResistance");
		}
	}

	void enterStats(string attORskill, Character character, int points)

// helper for CreateCharacter
// text interface for picking attributes
// type "Attribute" or "Skill" for the first param, leave metatypeAdjustmentPoints blank if "Skill"
	{
		try
		{
			string msg = "";

			Utilities.wrForce();
			int remainingPoints = points;
/*
 int remainingMAPoints = metatypeAdjustmentPoints;
if(metatypeAdjustmentPoints != 0){
Utilities.wrForce(remainingMAPoints.ToString() + " Metatype Adjustment Points");} 
*/
			if (attORskill == "Attribute")
			{
				if (character.metatype == Character.METATYPE.Bespoke)
				{
					Attribute.ATTRIBUTE_NAME[] allAttributes = new
						Attribute.ATTRIBUTE_NAME[character.attributeController.controlledStats.Count];
					Attribute.ATTRIBUTE_NAME[] bA = new Attribute.ATTRIBUTE_NAME[3];
					int i = 0;
//int j = 0;
					Utilities.wrForce("Select two high limits and one low");
					foreach (Attribute a in character.attributeController.controlledStats)
					{
						Utilities.wrForce(i + "" + a.CGO_Name);
						allAttributes[i] = a.attributeName;
						for (int j = 0; j < 3; ++j)
						{
							Utilities.wrForce("Enter the number of an attribute");
							int p = int.Parse(Console.ReadLine());
							bA[j] = allAttributes[p];
						}

						character.attributeController.SetBespokeAttributes(bA);
					}

					foreach (Attribute a in character.attributeController.controlledStats)
					{
						setStats(attORskill, a, ref remainingPoints);
						Utilities.wrForce(a.CGO_Name + "" + a.rank + " /" + a.rankLimit);
					}
				}

				if (attORskill == "Skill")
				{
					foreach (Skill s in character.activeSkillController.controlledStats)
					{
						setStats(attORskill, s, ref remainingPoints);
						string msg1 = s.CGO_Name + "" + s.rank + " /" + s.rankLimit;
						if (s.specialization != Skill.SKILL_SPECIALIZATION.Undefined)
						{
						}

						string msg2 = " (" + s.specialization.ToString() + " +2)";
/* if(s.expXtise != SknLSKILL_SPECIALIZATION.Undefined){
string msg2 = " (" + s.expertise.ToString() + " +3)"; msg1 += msg2;*/
						Utilities.wrForce(msg1);
					}
				}

// didnt use all the points
				Utilities.wrForce(remainingPoints.ToString() + " Available Points");
				if (remainingPoints > 0)
				{
					Utilities.wrForce("Use all the Points this time.");
					enterStats(attORskill, character, points);
				}

// prompt to redo the whole thing
				Utilities.wrForce("Redo " + attORskill + "s?");
				msg = Console.ReadLine();
				if (msg == "y")
				{
					if (attORskill == "Skill")
					{
						foreach (Skill v in character.activeSkillController.controlledStats)
						{
							v.specialization = Skill.SKILL_SPECIALIZATION.Undefined;
							v.expertise = Skill.SKILL_SPECIALIZATION.Undefined;
						}
					}

					enterStats(attORskill, character, points);
				}

				character.ResetAvailableEdge();
				Utilities.wrForce();
			}
		}
		catch
		{
			Utilities.wrForce("<" + GetType() + "> Try again...");
		}
	}

	void setStats(string attORskill, RankedStat cgs, ref int remainingPoints)
	{
// helper function for enterStats
// Attribute or Skill, points, "Attribute" or "Skill", option for attributes
// Call this in a foreach where needed in enterStats
//TODO: needs to be up/down button

		Utilities.wrForce(remainingPoints.ToString() + " Remaining Points");
		Utilities.wrForce("Enter" + cgs.CGO_Name + " rank." +
		                  "Must be <= " + cgs.rankLimit);
		int _i = int.Parse(Console.ReadLine());
		int _j = 0;
		int _k = 0;
		if (attORskill == "Attribute")
		{
			_j = (_i - 1);
			_k = 1;
		}

		if (attORskill == "Skill")
		{
			_j = _i;
			_k = 0;
		}

// set the rank to min if less, or set to input and - points
		if (_i <= cgs.rankLimit & _j <= remainingPoints)
		{
			if (_i < 1)
			{
// Attribute min = 1, Skill min = 0
				cgs.rank = _k;
			}

			if (_i > 0)
			{
				cgs.rank = _i;
// Attribute starts at 1, Skill starts at 0
				remainingPoints -= _j;
			}
		}
		else
		{
			Utilities.wrForce("Too high or not enough points...");
			setStats(attORskill, cgs, ref remainingPoints);
		}

		Utilities.wrForce(cgs.CGO_Name + " set to " + cgs.rank.ToString());
		Utilities.wrForce();
		if (attORskill == "Skill")
		{
			addSpecialization((Skill)cgs, ref remainingPoints);
			addExpertise((Skill)cgs);
		}
	}

	void enterMAStats(Character character, GameMaster gm, int points)
	{
// helper for CreateCharacter
// text interface for picking metatypeAdjustmentPoints
		try
		{
			Utilities.wrForce();
			string msg = "";
			int amt = 0;
			int remainingPoints = points;
			List<Attribute> metaAdjAttributes = new List<Attribute>();
			foreach (Attribute a in character.attributeController.controlledStats)
			{
				if (a.attributeName == Attribute.ATTRIBUTE_NAME.Edge)
				{
					metaAdjAttributes.Add(a);
					continue;
				}

				if (a.attributeName == Attribute.ATTRIBUTE_NAME.Depth)
				{
					metaAdjAttributes.Add(a);
					continue;
				}

				if (a.rank > 6)
				{
					metaAdjAttributes.Add(a);
				}
			}

			Utilities.wrForce(remainingPoints.ToString() + " Metatype Adjustment Points");
			foreach (Attribute a in metaAdjAttributes)
			{
				Utilities.wrForce(a.CGO_Name + "" + a.rank + " /" + a.rankLimit);
			}

			foreach (Attribute a in metaAdjAttributes)
			{
				Utilities.wrForce(remainingPoints.ToString() + " Metatype Adjustment Points");
				Utilities.wrForce(a.CGO_Name + "" + a.rank + " /" + a.rankLimit);
				Utilities.wrForce("Increase" + a.CGO_Name + "? y/n");
				msg = Console.ReadLine();
				if (msg == "y")
				{
					Utilities.wrForce("How much?");
				}

				msg = Console.ReadLine();
				amt = int.Parse(msg);
				if (amt > 0)
				{
					if (amt <= (a.rankLimit - a.rank))
					{
						a.IncreaseBaseRank(amt);
						remainingPoints -= amt;
					}
				}
			}

// didnt use all the points
			Utilities.wrForce(remainingPoints.ToString() + " Available Points");
			if (remainingPoints > 0)
			{

				Utilities.wrForce("Use all the Points this time.");
				enterMAStats(character, gm, remainingPoints);
			}

// prompt to redo the whole thing
			Utilities.wrForce("Redo metatype Adjustment Points? y/n");
			MenuNav(BACK_TO.CreateCharacter, BACK_TO.CreateCharacter, ref character, gm, ref msg);
			if (msg == "y")
			{
				enterMAStats(character, gm, points);
			}

			character.ResetAvailableEdge();
			Utilities.wrForce();
		}
		catch
		{
			Utilities.wrForce("<" + GetType() + "> Try again...");
		}
	}

	void addSpecialization(Skill skill, ref int remainingPoints)
// helper function for setStats
	{
		try
		{
			if (skill.rank > 0 && skill.specialization == Skill.SKILL_SPECIALIZATION.Undefined && remainingPoints > 0)
			{
				Utilities.wrForce("Add specialization to " + skill.CGO_Name + "? y / n");
				if (Console.ReadLine() == "y")
				{
					Utilities.wrForce("Choose From the following specializations:");
					int i = 0;
					Skill.SKILL_SPECIALIZATION[] specs = new
						Skill.SKILL_SPECIALIZATION[skill.specializations.Count];
					foreach (var s in skill.specializations)
					{
						if (s != skill.expertise)
						{
							Utilities.wrForce(i + "" + s.ToString());
							specs[i] = s;
							++i;
						}
					}

					skill.AddSpecialization(specs[int.Parse(Console.ReadLine())], true);
					--remainingPoints;
					Utilities.wrForce("Added " + skill.CGO_Name + "(" + skill.specialization.ToString() +
					                  ")•");
				}
			}
		}
		catch
		{
			Utilities.wrErr("<" + this.GetType() + "> specialization Error");
		}
	}

	void addExpertise(Skill skill)
	{
		// helper function for setStats
		try
		{
			if (skill.rank > 0 && skill.expertise == Skill.SKILL_SPECIALIZATION.Undefined &&
			    skill.specialization != Skill.SKILL_SPECIALIZATION.Undefined)
			{
				Utilities.wrForce("Add expertise to" + skill.CGO_Name + "? y / n");
				if (Console.ReadLine() == "y")
				{
					skill.AddExpertise(true);
					Utilities.wrForce("Added expertise " + skill.CGO_Name + "(" + skill.expertise.ToString() + ")");
				}
			}
		}
		catch
		{
			Utilities.wrErr("<" + this.GetType() + "> expertise Error");
		}
	}

	public void SpendKarma(ref Character character, bool isCharCreation = false)
	{
		string msg = "";
		Utilities.wrForce("spendable Karma:" + character.karma);
		Utilities.wrForce("Choose howto spend...");
		Utilities.wrForce("0 Increase Attributes");
		Utilities.wrForce("1 Increase Skills");
		Utilities.wrForce("2 Specialize/expertise Skills");
		Utilities.wrForce("3 Purchase Positive Qualities");
		Utilities.wrForce("4 Buy off Negative Qualities");
		if (isCharCreation)
		{
			Utilities.wrForce("5 Convert karma to resources");
		}

		msg = Console.ReadLine();
		switch (msg)
		{
			case "0":
			{
				IncreaseAttribute(ref character);
				break;
			}
			case "1":
			{
				IncreaseSkill(ref character);
				break;
			}
			case "2":
			{
				SpecializeExpertiseSkill(ref character);
				break;
			}
			case "3":
			{
				PurchasePositiveQualities(ref character);
				break;
			}
			case "4":
			{
				BuyOffNegativeQualities(ref character);
				break;
			}
			case "5":
			{
				if (isCharCreation)
				{
					ConvertKarmaToResources(ref character);
				}

				break;
			}
		}

		if (isCharCreation)
		{
			if (character.karma > 7)
			{
				Utilities.wrForce("spendable Karma:" + character.karma + ". Spend it till its <= 7!");
				SpendKarma(ref character, isCharCreation);
			}
			else
			{
				character.totalKarma = character.karma;
			}
		}
		else
		{
			Utilities.wrForce("Spend more Karma? y/n");
			msg = Console.ReadLine();
			if (msg == "y")
			{
				SpendKarma(ref character, isCharCreation);
			}
		}
	}

	void IncreaseAttribute(ref Character character)
	{
		string msg = "";
		int i = 0;
		foreach (Attribute a in character.attributeController.controlledStats)
		{
			if (character.karma >= a.improvementKarmaCost)
			{
				i = a.rank + 1;
				Utilities.wrForce("Ugrade " + a.CGO_Name + " to " + i + " for" + a.improvementKarmaCost +
				                  "?");
				msg = Console.ReadLine();
				if (msg == "y")
				{
					a.IncreaseBaseRank();
				}
			}
		}
	}

	void IncreaseSkill(ref Character character)
	{
		string msg = "";
		int i = 0;
		foreach (Skill a in character.activeSkillController.controlledStats)
		{
			Utilities.wrForce(a.CGO_Name + "" + a.rank + " (" + a.improvementKarmaCost + ")");
		}

		foreach (Skill a in character.activeSkillController.controlledStats)
		{
			if (character.karma >= a.improvementKarmaCost)
			{
				i = a.rank + 1;
				Utilities.wrForce("Ugrade " + a.CGO_Name + " to " + i + " for" + a.improvementKarmaCost +
				                  "?");
				msg = Console.ReadLine();
				if (msg == "y")
				{
					a.IncreaseBaseRank();
				}
			}
		}
	}

	void SpecializeExpertiseSkill(ref Character character)
	{
		string msg = "";
		int i = 0;
		foreach (Skill skill in character.activeSkillController.controlledStats)
		{
			if (skill.rank > 0)
			{
				msg = skill.CGO_Name;
				if (skill.specialization != Skill.SKILL_SPECIALIZATION.Undefined)
				{
					msg += ("(" + skill.specialization.ToString() + " +2)");
				}

				Utilities.wrForce(msg);
				if (skill.expertise != Skill.SKILL_SPECIALIZATION.Undefined)
				{
					msg = (skill.CGO_Name + "(" + skill.specialization.ToString() + " +3)");
					Utilities.wrForce(msg);
				}
			}
		}

		Utilities.wrForce("specialize or expertise? s/e");
		msg = Console.ReadLine();
		if (msg == "s")
		{
//spec
			foreach (Skill skill in character.activeSkillController.controlledStats)
			{
				if (character.karma >= 5 && skill.rank > 0 &&
				    skill.specialization == Skill.SKILL_SPECIALIZATION.Undefined)
				{
					Utilities.wrForce("specialize " + skill.CGO_Name + " for 5 karma?");
					foreach (var s in skill.specializations)
					{
						if (s != skill.expertise)
						{
							Utilities.wrForce("(" + s.ToString() + ")");
						}
					}

					msg = Console.ReadLine();
					if (msg == "y")
					{
						Utilities.wrForce("Choose from the following specializations:");
						Skill.SKILL_SPECIALIZATION[] specs = new
							Skill.SKILL_SPECIALIZATION[skill.specializations.Count];
						foreach (var s in skill.specializations)
						{
							if (s != skill.expertise)
							{
								Utilities.wrForce(i + "" + s.ToString());
								specs[i] = s;
								++i;
							}
						}

						skill.AddSpecialization(specs[int.Parse(Console.ReadLine())]);
						Utilities.wrForce("Added " + skill.CGO_Name + "(" +
						                  skill.specialization.ToString() + ").");
					}
				}
			}
		}

		if (msg == "e")
		{
// expertise
			foreach (Skill skill in character.activeSkillController.controlledStats)
			{
				if (skill.rank > 0 && skill.expertise == Skill.SKILL_SPECIALIZATION.Undefined &&
				    skill.specialization != Skill.SKILL_SPECIALIZATION.Undefined)
				{
					Utilities.wrForce("Add expertise to " + skill.CGO_Name + "(" + skill.specialization.ToString() +
					                  ")? y/n");
					if (Console.ReadLine() == "y")
					{
						skill.AddExpertise();
						Utilities.wrForce("Added expertise " + skill.CGO_Name + "(" + skill.expertise.ToString() + ")");
					}
				}
			}
		}
	}

	void PurchasePositiveQualities(ref Character character)
	{
		string msg = "";
		int i = 0;
		msg = Console.ReadLine();
		i = int.Parse(msg);

// list all the qualities character has, subtract them from the master qualities list, display the remainders,
// prompt to purchase them with name and karmaCost.
	}

	void BuyOffNegativeQualities(ref Character character)
	{
//string msg =
		int i = 0;
		foreach (Quality q in character.qualityController.controlledStats)
		{
			if (q.qualityType == Quality.QUALITY_TYPE.Negative)
			{
				i = (q.karmaCost * 2);
				Utilities.wrForce(q.CGO_Name + "" + i);
			}
		}
	}

	void ConvertKarmaToResources(ref Character character)
	{
		string msg = "";
		int i = 0;
		Utilities.wrForce(character.CGO_Name + " has" + character.karma + " karma.");
		Utilities.wrForce(character.CGO_Name + " has " + character.resources + " resources.");
		Utilities.wrForce("Conversion rate: 1 karma to 2,000 resources.");
		Utilities.wrForce("Convert how much karma?");
		msg = Console.ReadLine();
		i = int.Parse(msg);
		character.DecreaseKarma(i);
		character.resources += (2000 * i);
		Utilities.wrForce(character.CGO_Name + " now has " + character.karma + " karma.");
		Utilities.wrForce(character.CGO_Name + " now has " + character.resources + " resources.");
	}
}










