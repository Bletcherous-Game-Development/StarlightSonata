//Stores stats for ammunition for AR and Damage modification in RangedWeapon
using System;

[Serializable]
public class Ammunition : Gear
{
    Weapon.WEAPON_TYPE _weaponType = Weapon.WEAPON_TYPE.HoldoutPistol;
    AMMUNITION_VARIETY _ammunitionVariety = AMMUNITION_VARIETY.Regular;
    int _modifierAR = 0;
    int _modifierDV = 0;
    Damage.DAMAGE_TYPE _modifiedDamageType = Damage.DAMAGE_TYPE.Physical;
    Damage.ELEMENTAL_DAMAGE _modifiedElementalDamage = Damage.ELEMENTAL_DAMAGE.Undefined;
    bool _caseless = false;
    float _costMultiplier = 1.0f;

    public enum AMMUNITION_VARIETY
    {
        Regular,
        APDS,
        AssaultCannon, // 4(I) Y50
        DMSO, // 1 Y10
        Explosive,
        Flechette,
        Gel,
        InjectionDart, // 2 Y5+toxin
        Stick_n_Shock,
        Undefined
    }

    public Weapon.WEAPON_TYPE weaponType
    {
        get { return _weaponType; }
        set { _weaponType = value; }
    }

    public AMMUNITION_VARIETY AmmunitionVariety
    {
        get { return _ammunitionVariety; }
        set { _ammunitionVariety = value; }
    }

    public int modifier_AR
    {

        get { return _modifierAR; }
        set { _modifierAR = value; }
    }

    public int modifier_DV
    {
        get { return _modifierDV; }
        set { _modifierDV = value; }
    }

    public Damage.DAMAGE_TYPE modifiedDamageType
    {
        get { return _modifiedDamageType; }
        set { _modifiedDamageType = value; }
    }

    public Damage.ELEMENTAL_DAMAGE modifiedElementalDamage
    {
        get { return _modifiedElementalDamage; }
        set { _modifiedElementalDamage = value; }
    }

    public bool caseless
    {
        get { return _caseless; }
        set { _caseless = value; }
    }

    public float costMultiplier
    {
        get { return _costMultiplier; }
        set { _costMultiplier = value; }
    }

    public void CGO_Initialize(string namu, int co, int avail, LEGALITY leg, Weapon.WEAPON_TYPE weapType, AMMUNITION_VARIETY ammoVariety)
    {
        base.CGO_Initialize(namu);
        SetModifiers();
        consumable = true;
        stackable = true;
        quantity = 10;
        cost = co;
        availability = avail;
        legality = leg;
        weaponType = weapType;
        AmmunitionVariety = ammoVariety;
        stackable = true;
        SetModifiers();
    }

// cost, availability, legality, AR, Damage
    public void SetModifiers()
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        if (weaponType == Weapon.WEAPON_TYPE.HoldoutPistol || 
            weaponType == Weapon.WEAPON_TYPE.LightPistol || weaponType == Weapon.WEAPON_TYPE.MachinePistol)
        {
            cost = 5;
            availability = 1;
            legality = Gear.LEGALITY.Undefined;
        }

        if (weaponType == Weapon.WEAPON_TYPE.HeavyPistol || weaponType ==
            Weapon.WEAPON_TYPE.SMG)
        {
            cost = 10;
            availability = 1;
            legality = Gear.LEGALITY.Undefined;
        }

        if (weaponType == Weapon.WEAPON_TYPE.AssaultRifle || 
            weaponType == Weapon.WEAPON_TYPE.SniperRifle || weaponType == Weapon.WEAPON_TYPE.Shotgun)
        {
            cost = 20;
            availability = 2;
            legality = Gear.LEGALITY.L;
        }

        if (weaponType == Weapon.WEAPON_TYPE.Taser)
        {
            cost = 10;
            availability = 1;
            legality = Gear.LEGALITY.Undefined;
        }

        if (weaponType == Weapon.WEAPON_TYPE.LMG || weaponType == Weapon.WEAPON_TYPE.MMG ||
            weaponType == Weapon.WEAPON_TYPE.HMG)
        {
            cost = 15;
            availability = 2;
            legality = Gear.LEGALITY.L;
        }

        switch (AmmunitionVariety)
        {
            case AMMUNITION_VARIETY.Regular:
            {
                modifier_AR = 0;
                modifier_DV = 0;
                costMultiplier = 1f;
                break;
            }
            case AMMUNITION_VARIETY.APDS:
            {
                modifier_AR = 2;
                modifier_DV = -1;
                costMultiplier = 3f;
                break;
            }
            case AMMUNITION_VARIETY.AssaultCannon:
            {
                cost = 50;
                availability = 4;
                legality = Gear.LEGALITY.I;
                break;
            }
            case AMMUNITION_VARIETY.DMSO:
            {
                cost = 10;
                availability = 1;
                legality = Gear.LEGALITY.Undefined;
                break;
            }
            case AMMUNITION_VARIETY.Explosive:
            {
                modifier_AR = 0;
                modifier_DV = 1;
                costMultiplier = 2f;
                break;
            }
            case AMMUNITION_VARIETY.Flechette:
            {
                modifier_AR = 1;
                modifier_DV = -1;
                costMultiplier = 1.5f;
                break;
            }
            case AMMUNITION_VARIETY.Gel:
            {
                modifier_AR = 0;
                modifier_DV = 0;
                costMultiplier = 1.5f;
                modifiedDamageType = Damage.DAMAGE_TYPE.Stun;
                break;
            }
            case AMMUNITION_VARIETY.InjectionDart:
            {
                cost = 5; //+toxin
                availability = 2;
                legality = Gear.LEGALITY.Undefined;
                break;
            }
            case AMMUNITION_VARIETY.Stick_n_Shock:
            {
                modifier_AR = 1;
                modifier_DV = -1;
                costMultiplier = 2f;
                modifiedDamageType = Damage.DAMAGE_TYPE.Stun;
                modifiedElementalDamage = Damage.ELEMENTAL_DAMAGE.Electricity;
                break;
            }
        }

        cost = (int)((float)cost * costMultiplier);
    }
}