using System;

[Serializable]
public class DataConnector : CyberpunkGameObject
{
    INTERFACE_TYPE _interfaceType = INTERFACE_TYPE.Undefined;

    public enum INTERFACE_TYPE
    {
        Jack,
        Slot,
        Undefined
    }

    public INTERFACE_TYPE interfaceType
    {
        get { return _interfaceType; }
        set
        {
            try
            {
                _interfaceType = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public Device connectedDevice;

    public void CGO_Initialize(INTERFACE_TYPE iT)
    {
        interfaceType = iT;
        SetName(interfaceType.ToString());
        base.CGO_Initialize();
    }
}