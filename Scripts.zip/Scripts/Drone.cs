// all drones are vehicles, but not all vehicles are drones
using System;

[Serializable]
public class Drone : Vehicle
{
    DRONE_CATAGORY _droneCatagory;
    DRONE_SIZE _droneSize;

    public enum DRONE_CATAGORY
    {
        Wheeled,
        Anthro,
        Rotor,
        Winged,
    }

    public enum DRONE_SIZE
    {
        Micro,
        Mini,
        Small,
        Medium,
        Large,
    }

    public DRONE_CATAGORY droneCatagory
    {
        get { return _droneCatagory; }
        set
        {
            try
            {
                _droneCatagory = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public DRONE_SIZE droneSize
    {
        get { return _droneSize; }
        set
        {
            try
            {
                _droneSize = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }
}