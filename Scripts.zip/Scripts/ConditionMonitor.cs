// tracks damage boxes, instance a new one for physical, stun, or grid
using System;

[Serializable]
public class ConditionMonitor : ControllableStat
{
    Attribute _linkedAttribute = new Attribute();
    Damage.DAMAGE_TYPE _damageType = Damage.DAMAGE_TYPE.Physical;
    int _filledBoxes = 0;
    int _filledOverflow = 0;
    int _additionalBoxes = 0;
    int _additionalOverflow = 0;

    int _woundModifierThreshold = 3;

// helper variables
    int _extraWoundModifier = 0;
    int _cod = 0;
    int _dam = 0;
    ConditionMonitorController conditionMonitorController;

    public Attribute linkedAttribute // from the 
    {
        get { return _linkedAttribute; }
        set
        {
            try
            {
                _linkedAttribute = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public Damage.DAMAGE_TYPE damageType // Stun, Physical, Grid
    {
        get { return _damageType; }
        set
        {
            try
            {
                _damageType = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int filledBoxes // damage taken
    {
        get { return _filledBoxes; }
        set
        {
            try
            {
                _filledBoxes = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int filledOverflow // physical overflow taken
    {
        get { return _filledOverflow; }
        set
        {
            try
            {
                _filledOverflow = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int additionalBoxes // from 'ware or qualities,etc
    {
        get { return _additionalBoxes; }
        set
        {
            try
            {
                _additionalBoxes = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int additionalOverflow // from 'ware or qualities,etc
    {
        get { return _additionalOverflow; }
        set
        {
            try
            {
                _additionalOverflow = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int woundModifierThreshold
    {
        get { return _woundModifierThreshold; }
        set
        {
            try
            {
                _woundModifierThreshold = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public bool conditionMonitorFull // all boxes filled possible overflow or unconsciousness or bricked
    {
        get
        {
            if (filledBoxes >= totalBoxes)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public int maxOverflow // Death's threshold
    {
        get { return ((linkedAttribute.rank * 2) + additionalOverflow); }
    }

    public int totalBoxes // most damage able to sustain
    {
        get
        {
            if (Utilities.isntNull(linkedAttribute))
            {
                return ((int)((float)linkedAttribute.rank * 0.5f + 8.0f + additionalBoxes));
            }

            return 0;
        }
    }

    public int unfilledBoxes // capacity for more damage
    {
        get { return (totalBoxes - filledBoxes); }
    }

    public int woundModifier
    {
        get
        {
            _extraWoundModifier = 0;
            if (conditionMonitorFull)
            {
// if row is filled...
                if ((totalBoxes % woundModifierThreshold) > 0)
                {


// ...dont forget the extra -1 from the next row
                    _extraWoundModifier = 1;
                }
            }

// every 2, 3, or 4 boxes filled is a -1
            return ((filledBoxes / woundModifierThreshold) + _extraWoundModifier);
        }
    }

    public void CGO_Initialize(Damage.DAMAGE_TYPE dt, Attribute IA)
    {
        ResetWoundModifierThreshold();
        SetDamageType(dt);
        SetLinkedAttribute(IA);
        base.CGO_Initialize(CGO_Name);
        conditionMonitorController = (ConditionMonitorController)statController;
    }

    public void IncreaseWoundModifierThreshold(int wmt = 4)
    {
        woundModifierThreshold = wmt;
    }

    public void IncreaseAdditionalBoxes(int amount)
    {
        additionalBoxes += amount;
        Utilities.wrForce(CGO_Name + " ConditionMonitor now has " + totalBoxes);
    }

    public void IncreaseTotalOverflow(int increase)
    {
        additionalOverflow += increase;
    }

    public void TakeBoxesOfDamage(int damage) // the basic method to increase damage
    {
        Utilities.wrForce("<CM " + CGO_Name + "> Taking " + damage + " boxes of damage.");
// add the damage
        filledBoxes += damage;
// if too much... overflow, carryover excess Damage
        if (unfilledBoxes > totalBoxes)
        {
// only stun or physical
            if (damageType != Damage.DAMAGE_TYPE.Grid)
            {
// send up the extra
                Carryover((filledBoxes - totalBoxes));
            }

// cap to max
            filledBoxes = totalBoxes;
        }
    }

    public void RemoveBoxesOfDamage(int damage) // for healing damage
    {
/* identity.isDestroyed){
return;} */
        Utilities.wrForce("Healing " + CGO_Name + " CM for" + damage + "!");
// remove the damage
        if (damageType == Damage.DAMAGE_TYPE.Physical)
        {
            if (filledOverflow > 0)
            {
                _dam = damage;
                filledOverflow -= damage;
                Utilities.wrForce("Healing overflow for" + damage + "!");
                if (filledOverflow < 0)
                {
                    _dam += filledOverflow;
                    filledOverflow = 0;
                    Utilities.wrForce("Healing " + CGO_Name + " for the " + _dam + " leftover");
                }
            }

            filledBoxes -= _dam;
        }
        else
        {
            filledBoxes -= damage;
        }

// if healed too much...
        if (filledBoxes < 0)
        {
//... reset to min
            filledBoxes = 0;
        }

        if (filledBoxes == 0)
        {
            Utilities.wrForce(CGO_Name + " CM fully healed!");
        }
    }

    void SetDamageType(Damage.DAMAGE_TYPE dt)
    {
        damageType = dt;
        switch (damageType)
        {
            case Damage.DAMAGE_TYPE.Physical:
            {
                SetName("Physical");
                break;
            }
            case Damage.DAMAGE_TYPE.Stun:
            {
                SetName("Stun5");
                break;
            }
            case Damage.DAMAGE_TYPE.Grid:
            {
                SetName("Grid");
                break;
            }
        }
    }

    void SetLinkedAttribute(Attribute IA)
    {
        linkedAttribute = IA;
    }

    void ResetWoundModifierThreshold()
    {
        woundModifierThreshold = 3;
    }

    void Carryover(int cO)
    {
// exceeded the CM
        if (cO > 0)
        {
            Utilities.wrForce("Damage Exceeded the " + CGO_Name + " CM");
// pass it to the physical Boxes
            if (damageType == Damage.DAMAGE_TYPE.Stun)
            {
// calc the caryover
                _cod = (int)(cO * 0.5f);
                Utilities.wrForce("Converting " + cO + " Stun to " + _cod + " Physical");
                foreach (ConditionMonitor c in conditionMonitorController.controlledStats)
                {
                    if (c.damageType == Damage.DAMAGE_TYPE.Physical)
                    {
                        c.TakeBoxesOfDamage(_cod);
                    }
                }
            }

// pass it to the overflow
            if (damageType == Damage.DAMAGE_TYPE.Physical)
            {
                TakeOverflowDamage(cO);
            }

// clean up
            _cod = 0;
        }
    }

    void TakeOverflowDamage(int damage) // pass the overflow where appropriate
    {
        Utilities.wrForce(CGO_Name + " CM is overflowing by " + damage + ".");
        filledOverflow += damage;
        Utilities.wrForce("filledOverflow is at" + filledOverflow + +maxOverflow);
        if ((filledOverflow >= maxOverflow))
        {
            filledOverflow = maxOverflow;
// TODO: You Dead, Chummer!
//entity.actionController.SetConscious(false);// handle internally for entity //entity. SetDestroyed(true);
//Utilities.wrForce(entity.name + ", you dead, chummer!");
        }
    }

    void CheckForExtraWoundModifier() // sometimes there is one more -1
    {
    }
}