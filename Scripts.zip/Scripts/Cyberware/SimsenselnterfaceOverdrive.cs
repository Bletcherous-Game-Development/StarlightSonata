using System;

[Serializable]
public class SimsenselnterfaceOverdrive : Cyberware // 1-4
{
    public void CGO_Initialize(Augmentation.WARE_GRADE wG, int rtng)
    {
        augmentationName = Augmentation.AUGMENTATION_NAME.SimsenselnterfaceOverdrive;
        base.CGO_Initialize(augmentationName, (rating * 15000), 1, Gear.LEGALITY.L, wG, (rating * 0.2f));
    }
}