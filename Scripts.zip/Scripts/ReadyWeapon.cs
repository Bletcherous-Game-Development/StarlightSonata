using System;

[Serializable]
public class ReadyWeapon : Action
{
    GearSlotController gsc;

    public override void InitiateAction(Weapon weap)
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        Utilities.wr("***<==8_ReadyWeapon_8==>***");
        if (weap.gearCatagory == Gear.GEAR_CATAGORY.Weapon)
        {
            if (TimeAndTypeCheck())
            {
                gsc = entity.gearSlotController;
                weap.SetEntity(entity);
                weap.SetRequiredSkill();
                weap.readied = true;
                Utilities.wrForce(entity.CGO_Name + " readied " + weap.CGO_Name);
            }
        }
    }
}