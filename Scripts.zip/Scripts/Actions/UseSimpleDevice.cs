using System;

[Serializable]
public class UseSimpleDevice : Action
{

    public override void InitiateAction(Gear gear0, Gear gear1)
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        Utilities.wr("***<==8_UseSimpleDevice_8==>***");
// TODO: AmmunitionContainer.ReloadAmmunitionContainer(Ammunition ammo)
        if (gear0.gearCatagory == Gear.GEAR_CATAGORY.Accessory && gear1.gearCatagory == Gear.GEAR_CATAGORY.Ammunition)
        {
            if (TimeAndTypeCheck())
            {
                gear0.Use((Ammunition)gear1);
            }
        }
    }
}