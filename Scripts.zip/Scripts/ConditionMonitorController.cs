using System;
using System.Collections.Generic;

[Serializable]
public class ConditionMonitorController : StatController
{
    public override void CGO_InitializeControllableStats()
    {
    }
}