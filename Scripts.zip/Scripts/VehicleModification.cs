using System;

[Serializable]
public class VehicleModification : Gear
{
    int _modSlots = 0;
    MODIFICATION_TYPE _modType = MODIFICATION_TYPE.Chassis;

    public enum MODIFICATION_TYPE
    {
        Chassis,
        Powerplant,
        Electronics
    }

    public int modSlots
    {
        get { return _modSlots; }
        set
        {
            try
            {
                _modSlots = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public MODIFICATION_TYPE modType
    {
        get { return _modType; }
        set
        {
            try
            {
                _modType = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }
}