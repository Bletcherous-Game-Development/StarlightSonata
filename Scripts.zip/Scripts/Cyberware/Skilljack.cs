using System;

[Serializable]
public class Skilljack : Cyberware
{
    public DataConnector slot = new DataConnector();
    public void CGO_Initialize(Augmentation.WARE_GRADE wG, int rtng) // 1-6
    {
        augmentationName = Augmentation.AUGMENTATION_NAME.Skilljack;
        base.CGO_Initialize(augmentationName, 1000, 1, Gear.LEGALITY.L, wG, 0.1f);
        slot.CGO_Initialize(DataConnector.INTERFACE_TYPE.Slot);
    }
}