using System;[Serializable] public class Dodge:Action{
    public override void InitiateAction(){
        if(Utilities.isNull(entity)){
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!"); return;}
        Utilities.wr("***<==8_Dodge_8==>***");
        if(TimeAndTypeCheck()){}}}