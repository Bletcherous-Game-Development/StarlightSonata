using System;

[Serializable]
public class MultipleAttacks : Action
{
    public override void InitiateAction()
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        Utilities.wr("***<==8_MultipleAttacks_8==>***");
        if (TimeAndTypeCheck())
        {
        }
    }
}