using System;

[Serializable]
public class ToxinResistance : Quality
{
    public override void GameEffect()
    {
        if (Utilities.isNull(entity))
        {
            return;
        }

        SetQualityType(QUALITY_TYPE.Positive);
        SetKarmaCost(12);
    }

    public override void ReverseEffect()
    {
        base.ReverseEffect();
    }
}