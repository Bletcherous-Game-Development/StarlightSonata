using System;

[Serializable]
public class RadiationResistance : Quality // needs accurate karmaCost
{
    public override void GameEffect()
    {
        if (Utilities.isNull(entity))
        {
            return;
        }

        SetQualityType(QUALITY_TYPE.Positive);
        SetKarmaCost(12);
    }

    public override void ReverseEffect()
    {
        base.ReverseEffect();
    }
}