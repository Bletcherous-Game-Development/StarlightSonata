﻿using System;

[Serializable]
public class StatusController: StatController
{
    bool _init = false;

//public ConditionMonitor stun = new ConditionMonitor();
    public override void CGO_InitializeControllableStats()
    {
        if (_init)
        {
            return;
        }

        _init = true;

        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        if (Utilities.isNull(entity.attributeController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity.attributeController is null!");
            return;
        }

        //stun.CGO_Initialize(Damage.DAMAGE_TYPE.Stun, entity.attributeController.willpower);
    }
}