using System;

[Serializable]
public class Block : Action
{
    public override void InitiateAction()
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        Utilities.wr("***<==8_Block_8==>***");
        if (TimeAndTypeCheck())
        {
            Utilities.wrForce("");
        }
    }
}