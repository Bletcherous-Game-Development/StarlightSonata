// Holds all the stats of the various damage types

using System;

[Serializable]
public class Damage
{
    private int _damageValue = 0;
    
    private DAMAGE_TYPE _damageType = DAMAGE_TYPE.Undefined;
    
    private ELEMENTAL_DAMAGE _elementalDamage = ELEMENTAL_DAMAGE.Undefined;
    
    private bool _unresisted = false;
    
    private int _damageModifier = 0;
    
    public enum DAMAGE_TYPE
    {
        Physical,
        Stun,
        Grid,
        Undefined
    }
    public enum ELEMENTAL_DAMAGE
    {
        Electricity,
        Chemical,
        Cold,
        Fire,
        Undefined
        
    }
    
    public bool unresisted
    {
        get
        {
            return _unresisted;
        }
        set
        {
            try
            {
                _unresisted = value;
            } 
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }
    public int damageValue
    {
        get
        {
            return _damageValue;
        }
        set
        {
            try
            {
                _damageValue = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }
    public int damageModifier
    {
        get
        {
            return _damageModifier;
        }
        set
        {
            try
            {
                _damageModifier = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }
    public int modifiedDamageValue
    {
        get
        {
            return damageValue + damageModifier;
        }
        
    }
    public DAMAGE_TYPE damageType
    {
        get
        {
            return _damageType;
        }
        set
        {
            try
            {
                _damageType = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }
    
    public ELEMENTAL_DAMAGE elementalDamage
    {
        get
        {
            return _elementalDamage;
        }
        set
        {
            try
            {
                _elementalDamage = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }
    
    public void CGO_Initialize(int dV, DAMAGE_TYPE dT, ELEMENTAL_DAMAGE eD = ELEMENTAL_DAMAGE.Undefined, bool uR = false)
    {
        damageValue = dV;
        damageType = dT;
        elementalDamage = eD;
        unresisted = uR;
    }
}
