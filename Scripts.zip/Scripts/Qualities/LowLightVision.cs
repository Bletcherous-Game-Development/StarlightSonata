using System;

[Serializable]
public class LowLightVision : Quality
{
    public override void GameEffect()
    {
        if (Utilities.isNull(entity))
        {
            return;
        }

        SetQualityType(QUALITY_TYPE.Positive);
        SetKarmaCost(6);
    }

    public override void ReverseEffect()
    {
        base.ReverseEffect();
    }
}