// The things an entity can do. only physical actions. Now is not the time for the grid; that time comes later!
using System;

[Serializable]
public abstract class Action : ControllableStat
{
    ACTION_NAME _actionName = ACTION_NAME.ObservelnDetail;
    ACTION_TIME _actionTime = ACTION_TIME.initiative;
    ACTION_TYPE _actionType = ACTION_TYPE.Major;

    public enum ACTION_NAME
    {
        ///Minor
        AvoidIncoming,
        Block,
        CallAShot,
        ChangeDeviceMode,
        CommandDrone,
        Dodge,
        DropObject,
        DropProne,
        HitTheDirt,
        Intercept,
        Move,
        MultipleAttacks,
        QuickDraw,
        ReloadSmartgun,
        StandUp,
        TakeAim,
        TakeCover,
        Trip,

        ///Major
        Assist,
        Attack,
        FullDefense,
        PickUpPutDownObject,
        ObservelnDetail,
        ReadyWeapon,
        ReloadWeapon,
        RiggerJumpIn,
        Sprint,
        UseSimpleDevice,
        UseSkill
    }

    public enum ACTION_TIME
    {
        initiative,
        Anytime
    }

    public enum ACTION_TYPE
    {
        Minor,
        Major
    }

    public Entity Target;
    public ActionController actionController;

    public ACTION_NAME actionName
    {
        get { return _actionName; }
        set
        {
            try
            {
                _actionName = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public ACTION_TIME actionTime
    {
        get { return _actionTime; }
        set
        {
            try
            {
                _actionTime = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public ACTION_TYPE actionType
    {
        get { return _actionType; }
        set
        {

            try
            {
                _actionType = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    // makes sure the right actions are done in the proper game state
    public bool TimeAndTypeCheck()
    {
        if (Utilities.isNull(GM))
        {
            Utilities.wr("<" + this.GetType().Name + "> " + CGO_Name + ".GM is null!");
            return false;
        }

        if (Utilities.isNull(actionController))
        {
            Utilities.wr("<" + this.GetType().Name + "> " + CGO_Name + ".actioncontroller is null!");
            return false;
        }

        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return false;
        }

        if (entity.isDestroyed == true)
        {
            Utilities.wrErr("<" + this.GetType() + "> isDestroyed!!!");
        }

        if (actionController.conscious == false)
        {
            Utilities.wrErr("<" + this.GetType() + "> Unconscious!!!");
            return false;
        }

        if (entity.GM.gameTime == GameMaster.GAME_TIME.Exploration)
        {
            return true;
        }

        bool typeCheck = false;
        switch (actionType)
        {
            case ACTION_TYPE.Minor:
            {
                if (actionController.currentMinorActions >= 1 || actionController.currentMajorActions >= 1)
                {
                    typeCheck = true;
                }

                break;
            }
            case ACTION_TYPE.Major:
            {
                if (actionController.currentMajorActions >= 1 || actionController.currentMinorActions >= 4)
                {
                    typeCheck = true;
                }

                break;
            }
        }

        if (typeCheck)
        {
            if (actionTime == ACTION_TIME.Anytime)
            {
                actionController.ReduceCurrentActions(actionType);
                return true;
            }

            if (actionTime == ACTION_TIME.initiative && entity == entity.GM.entityWhoseTurnItIs)
            {
                actionController.ReduceCurrentActions(actionType);
                return true;
            }
        }

        Utilities.wrErr("<" + this.GetType() + "> Wrong Time or Type");
        return false;
    }

    public virtual void CGO_Initialize(ACTION_NAME aName, ACTION_TIME aTime, ACTION_TYPE aType)
    {
        actionName = aName;
        SetName(actionName.ToString());
        actionTime = aTime;
        actionType = aType;
        base.CGO_Initialize();
    }

    // for the inheritance interface, the comments are referencing their child class es
    public virtual void InitiateAction()
    {
    }

    public virtual void InitiateAction(GearSlot slot, Gear gear)
    {
    }

    //PickUpPutDownObject
    public virtual void InitiateAction(GearSlot slot)
    {
    }

    //PickUpPutDownObject
    public virtual void InitiateAction(GearSlot slotO, GearSlot slotl)
    {
    }

    //PickUpPutDownObject
    public virtual void InitiateAction(Weapon weap)
    {
    }

    //ReadyWeapon
    public virtual void InitiateAction(Entity def, Weapon weap)
    {
    }

    //Attack
    public virtual void InitiateAction(RangedWeapon mgdWeap, AmmunitionContainer ammoCont)
    {
    }

    //ReloadWeapon
    public virtual void InitiateAction(Gear gearO, Gear gearl)
    {
    }

    //UseSimpleDevice:Gear.Use(AmmunitionContainer.ReloadAmmunitionContainer);

    public virtual void InitiateAction(Skill skill, int thrshld, ref DiceRollVariables drv)
    {

    } ///UseSkill
}