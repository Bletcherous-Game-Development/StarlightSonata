using System;

[Serializable]
public class Cyberlimb : Cyberware
{
    CYBERLIMB_STYLE _cyberlimbStyle = CYBERLIMB_STYLE.Undefined;


    public enum CYBERLIMB_STYLE
    {
        Obvious,
        Synthetic,
        Undefined
    }

    public CYBERLIMB_STYLE cyberlimbStyle
    {
        get { return _cyberlimbStyle; }
        set
        {
            try
            {
                _cyberlimbStyle = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public void CGO_Initialize(CYBERLIMB_STYLE cS, Augmentation.WARE_GRADE wG, AUGMENTATION_NAME aN, int co, int avail, LEGALITY leg, WARE_GRADE grade, float essCost)
    {
        cyberlimbStyle = cS;
        base.CGO_Initialize(aN, 1000, 1, Gear.LEGALITY.L, wG, 1.0f);
    }
}