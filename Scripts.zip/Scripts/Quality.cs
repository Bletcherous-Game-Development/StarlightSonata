using System;

[Serializable]
public class
    Quality : ControllableStat // The best idea at the time was to make each one inherit this because they are all so different.{
{
    int _karmaCost = 0;

    QUALITY_TYPE _qualityType = QUALITY_TYPE.Undefined;

    QUALITY_NAME _qualityName = QUALITY_NAME.Undefined;

//string _additionallnfo =
    private string _descriptiveText = "";
    private string _gameEffectText = "";

/* public int parseAdditionallnfo(){
try{
return int.Parse(additionallnfo);}
catch{
Utilities.wrErr("Quality.parseAdditionallnfo Error");}
return 0;} */
    public enum QUALITY_TYPE
    {
        Positive,
        Negative,
        Drivingstyle,
        MartialArt,
        Undefined
    }

    public enum QUALITY_NAME
    {
        Aptitude,
        Bioadaptability,
        BuiltTough,
        DermalDeposits,
        Exceptional,
        Fragile,
        Impairment,
        LowLightVision,
        MacroGravityAdaption,
        MicroGravityAdaption,
        QuickHealer,
        RadiationResistance,
        ThermographicVision,
        Toughness,
        ToxinResistance,
        Weakness,
        Undefined
    }

/* public string additionallnfo{
get{
return _additionallnfo;}
set{
try{
_additionallnfo = value;}
catch{
Utilities.wrErr(this.GetType().Name + " Property set errror!!!");}}} */
    public QUALITY_TYPE qualityType
    {
        get { return _qualityType; }
        set
        {
            try
            {
                _qualityType = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public QUALITY_NAME qualityName
    {
        get { return _qualityName; }
        set
        {
            try
            {
                _qualityName = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int karmaCost
    {
        get { return _karmaCost; }
        set
        {
            try
            {
                _karmaCost = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public string descriptiveText
    {
        get { return _descriptiveText; }
        set
        {
            try
            {
                _descriptiveText = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public string gameEffectText
    {
        get { return _gameEffectText; }
        set
        {
            try
            {
                _gameEffectText = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public void CGO_Initialize(QUALITY_NAME qN)
    {
        SetQualityName(qN);
        SetName(qualityName.ToString());
//SetAdditionallnfo(al);
        base.CGO_Initialize();
        GameEffect();
    }

    public void SetQualityType(QUALITY_TYPE qT)
    {
        qualityType = qT;
    }

    public void SetQualityName(QUALITY_NAME qN)
    {
        qualityName = qN;
    }

/* public void SetAdditionallnfo(string al){
additionallnfo = al; }
*/
    public void SetKarmaCost(int kC)
    {
        karmaCost = kC;
    }

    public void SetDescriptiveText(string dT)
    {
        descriptiveText = dT;
    }

    public void SetGameEffectText(string gET)
    {
        gameEffectText = gET;
    }

    public virtual void GameEffect()
    {
    }

    public virtual void ReverseEffect()
    {
        entity.qualityController.UnControl(this);
    }
}