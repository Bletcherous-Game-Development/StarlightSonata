using System;

[Serializable]
public class QuickHealer : Quality // needs accurate karmaCost
{
    public override void GameEffect()
    {
        if (Utilities.isNull(entity))
        {
            return;
        }

        SetQualityType(QUALITY_TYPE.Positive);
        SetKarmaCost(5);
    }

    public override void ReverseEffect()
    {
        base.ReverseEffect();
    }
}