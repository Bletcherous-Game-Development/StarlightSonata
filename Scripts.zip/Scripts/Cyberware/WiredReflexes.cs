using System;

[Serializable]
public class WiredReflexes : Cyberware
{
    public void CGO_Initialize(Augmentation.WARE_GRADE wG, int rtng)
    {
        augmentationName = Augmentation.AUGMENTATION_NAME.WiredReflexes;
        base.CGO_Initialize(augmentationName, 1000, 1, Gear.LEGALITY.L, wG, rating);
    }

    public override void GameEffect()
    {
        base.GameEffect();
        entity.initiativeDice += rating;
    }
}