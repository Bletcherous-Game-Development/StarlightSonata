using System;

[Serializable]
public class ContactController : StatController
{
    bool _init = false;

//public ConditionMonitor stun = new ConditionMonitor();
    public override void CGO_InitializeControllableStats()
    {
        if (_init)
        {
            return;
        }

        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        if (Utilities.isNull(entity.attributeController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity.attributecontroller is null!");
            return;
        }
//stun.CGO」nitialize(Damage.DAMAGE_TYPE.Stun, entity.attributecontroller.willpower);
    }
}