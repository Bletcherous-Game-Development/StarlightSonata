//Covers most electronic devices with grid attributes.
using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;

[Serializable]
public class Device : Entity
{
    bool _runningSilent = false;
    bool _poweredOn = false;
    bool _wirelessEnabled = false;
    int _totalProgramSlots = 0;
    Device _devicePwNr = null;
    DEVICE_TYPE _deviceType = DEVICE_TYPE.PwNee;
    int _cost = 0;
    int _availability = 0;
    Gear.LEGALITY _legality = Gear.LEGALITY.Undefined;

    public Entity entityOwner;
    public DataConnector slot = new DataConnector();
    public List<Cyberprogram> slottedCyberprograms = new List<Cyberprogram>();
    public List<Cyberprogram.CYBERPROGRAM_TYPE> compatableCyberprograms = new List<Cyberprogram.CYBERPROGRAM_TYPE>();
    public List<Device> personalNetwork = new List<Device>();

    public enum DEVICE_TYPE
    {
        PwNCapable,
        PwNee
    }

    public int maxPersonalNetwork
    {
        get
        {
            if (Utilities.isntNull(attributeController))
            {
                Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".attributecontroller is null!");
                return 0;
            }

            if (deviceType == DEVICE_TYPE.PwNCapable)
            {
                foreach (Attribute a in attributeController.controlledStats)
                {
                    if (a.attributeName == Attribute.ATTRIBUTE_NAME.DeviceRating)
                    {
                        return (a.rank * 3);
                    }
                }

                return 0;
            }
            else
            {
                return 0;
            }
        }
    }

    public int currentPersonalNetwork
    {
        get { return personalNetwork.Count; }
    }

    public bool runningSilent
    {
        get { return _runningSilent; }
        set
        {
            try
            {
                _runningSilent = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public bool poweredOn
    {
        get { return _poweredOn; }
        set
        {
            try
            {
                _poweredOn = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public bool wirelessEnabled
    {
        get { return _wirelessEnabled; }
        set
        {
            try
            {
                _wirelessEnabled = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int totalProgramSlots
    {
        get
        {
            if (Utilities.isntNull(attributeController))
            {
                Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".attributecontroller is null!");
                return 0;
            }


            if (deviceType == DEVICE_TYPE.PwNee)
            {
                foreach (Attribute a in attributeController.controlledStats)
                {
                    if (a.attributeName == Attribute.ATTRIBUTE_NAME.DeviceRating)
                    {
                        return (int)(a.rank * 0.5f);
                    }
                }

                return 0;
            }

            return _totalProgramSlots;
        }
        set
        {
            try
            {
                if (deviceType == DEVICE_TYPE.PwNCapable)
                {
                    _totalProgramSlots = value;
                }
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int filledProgramSlots
    {
        get { return slottedCyberprograms.Count; }
    }

    public bool canHavePersonalNetwork
    {
        get
        {
            if (deviceType == DEVICE_TYPE.PwNCapable)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public bool isPwNd
    {
        get
        {
            if (Utilities.isntNull(devicePwNr))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }

    public Device devicePwNr
    {
        get { return _devicePwNr; }
        set
        {
            try
            {
                _devicePwNr = value;
            }
            catch
            {

                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public DEVICE_TYPE deviceType
    {
        get { return _deviceType; }
        set
        {
            try
            {
                _deviceType = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int cost
    {
        get
        {
            return
                _cost;
        }
        set
        {
            try
            {
                _cost = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public int availability
    {
        get { return _availability; }
        set
        {
            try
            {
                _availability = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public Gear.LEGALITY legality
    {
        get { return _legality; }
        set
        {
            try
            {
                _legality = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }

    public override void CGO_Initialize()
    {
        base.CGO_Initialize();
        SetControllableStats();
        slot.CGO_Initialize(DataConnector.INTERFACE_TYPE.Slot);
    }

/************** The Call when damaged***************/
    public override void ResistDamage(Damage damage, ref DiceRollVariables drv) /// the appropriate CondMon
    {
        if (!Utilities.isntNull(
                conditionMonitorController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".conditionMonitorcontroller is null!!");
            return;
        }

        foreach (ConditionMonitor c in conditionMonitorController.controlledStats)
        {
            if (damage.elementalDamage == Damage.ELEMENTAL_DAMAGE.Electricity)
            {
                if (c.damageType == Damage.DAMAGE_TYPE.Physical)
                {
                    Damage elec = damage;
                    elec.damageType = Damage.DAMAGE_TYPE.Physical;
                    ResistDamage(c, elec, ref drv);
                    return;
                }

                return;
            }

            if (c.damageType == damage.damageType)
            {
                ResistDamage(c, damage, ref drv);
            }
        }
    }

    public void SyncDevice(Device d)
    {
        devicePwNr = d;
        GM = devicePwNr.GM;
    }

    public void PwNDevice(Device d)
    {
        if (deviceType != DEVICE_TYPE.PwNCapable)
        {
            Utilities.wrErr("<" + this.GetType() + "> " + CGO_Name + " can't PwN, its not a PwNr!");
            return;
        }

        if (personalNetwork.Contains(d))
        {
            Utilities.wrErr("<" + this.GetType() + "> " + d.CGO_Name + " is already PwNd by this" + CGO_Name);
            return;
        }

        if (d.personalNetwork.Count != 0)
        {
            Utilities.wrErr("<" + this.GetType() + "> " + d.CGO_Name + " cant be PwNd, it has a PN");
            return;
        }

        if (Utilities.isntNull(d.devicePwNr))
        {
            Utilities.wrErr("<" + this.GetType() + "> " + d.CGO_Name + " can't be PwNd, it already has an devicePwNr");
            return;
        }

        if (currentPersonalNetwork >= maxPersonalNetwork)
        {
            Utilities.wrErr("<" + this.GetType() + "> " + d.CGO_Name + " can't be PwNd, this" + CGO_Name + "'s PN is full!");
            return;
        }

// Beat its Firewall or prompt its entity to Allow
        personalNetwork.Add(d);
    }

//SyncPersonalNetwork();}
    public void DisPwNDevice(Device d)
    {
        personalNetwork.Remove(d);
        d.devicePwNr = null;
    }

    public void SyncPersonalNetwork()
    {
        foreach (Device d in personalNetwork)
        {
            d.SyncDevice(this);
        }
    }

    public void SlotCyberprogram(Cyberprogram cp)
    {
        if (!compatableCyberprograms.Contains(cp.cyberprogramType))
        {
            Utilities.wrErr("<" + this.GetType() + "> " + CGO_Name + " can't slot" + cp.CGO_Name +
                            ", its not a compatable Cyberprogram type");
            return;
        }

        if (filledProgramSlots < totalProgramSlots)
        {
            slottedCyberprograms.Add(cp);
        }

        Utilities.wrErr("<" + this.GetType() + "> " + CGO_Name + " can't slot" + cp.CGO_Name +
                        ", its slottedCyberprograms is maxd");
        return;
    }


    public override void SetControllableStats()
    {
        SetAttributes();
        SetConditionMonitors();
    }

    public override void SetAttributes()
    {
        Attribute deviceRating = new Attribute();
        Attribute attack = new Attribute();
        Attribute sleaze = new Attribute();
        Attribute dataProcessing = new Attribute();
        Attribute firewall = new Attribute();
        attributeController.Control(deviceRating);
        attributeController.Control(attack);
        attributeController.Control(sleaze);
        attributeController.Control(dataProcessing);
        attributeController.Control(firewall);
        deviceRating.CGO_Initialize(Attribute.ATTRIBUTE_NAME.DeviceRating);
        attack.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Attack);
        sleaze.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Sleaze);
        dataProcessing.CGO_Initialize(Attribute.ATTRIBUTE_NAME.DataProcessing);
        firewall.CGO_Initialize(Attribute.ATTRIBUTE_NAME.Firewall);
    }

    public override void SetConditionMonitors()
    {
        if (Utilities.isNull(conditionMonitorController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".conditionMonitorController is null!");
            return;
        }

        if (Utilities.isNull(attributeController))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".attributecontroller is null!");
            return;
        }

        ConditionMonitor grid = new ConditionMonitor();
        conditionMonitorController.Control(grid);
        foreach (Attribute a in attributeController.controlledStats)
        {
            if (a.attributeName == Attribute.ATTRIBUTE_NAME.DeviceRating)
            {
                grid.CGO_Initialize(Damage.DAMAGE_TYPE.Grid, a);
            }
        }
    }
}