using System;

[Serializable]
public class ControlRig : Cyberware
{
    public DataConnector slot = new DataConnector();
   
    public void CGO_Initialize(Augmentation.WARE_GRADE wG, int rtng) // 1-3
    {
        augmentationName = Augmentation.AUGMENTATION_NAME.ControlRig;
        base.CGO_Initialize(augmentationName, (rating * 30000), 1, Gear.LEGALITY.L, wG, rating); 
        slot.CGO_Initialize(DataConnector.INTERFACE_TYPE.Slot);
    }
}