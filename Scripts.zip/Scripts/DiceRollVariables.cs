using System;

[Serializable]
public class DiceRollVariables
{
    // Sets the Dice Pool. Stores info from dice rolls for anything that needs to know what was rolled
    public enum EXTENDED_TEST_INTERVAL
    {
        CombatTurn_1,
        Minute_1,
        Minute_10,
        Minute_30,
        Hour_1,
        Day_1,
        Week_1,
        Month_1,
        Undefined
    }

    bool _criticalGlitch = false;

    // Edge Boost
    bool _enemyCounting2s = false;

    bool _exit = false;

    bool _glitch = false;

    // Edge Boost
    bool _sixesExplode = false;

    bool _success = false;

    int _dicePool = 0;

    // the Entity's Edge
    int _edgeRank = 0;

    int _elapsedIntervals = 0;

    int _threshold = 0;

    EXTENDED_TEST_INTERVAL _extendedTestInterval = EXTENDED_TEST_INTERVAL.Undefined;

    public bool CriticalGlitch
    {
        get
        {
            return _criticalGlitch;
        }
        
        set
        {
            try
            {
                _criticalGlitch = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }

    public bool enemyCounting2s
    {
        get
        {
            return _enemyCounting2s;
        }
        set
        {
            try
            {
                _enemyCounting2s = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    } 

    public bool exit
    {
        get
        {
            return _exit;
        }

        set
        {
            try
            {
                _exit = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }

    public bool glitch
    {
        get
        {
            return _glitch;
        }
        set
        {
            try
            {
                _glitch = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }

    public bool sixesExplode
    {
        get
        {
            return _sixesExplode;
        }

        set
        {
            try
            {
                _sixesExplode = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }

    public bool success
    {
        get
        {
            return _success;
        }

        set
        {
            try
            {
                _success = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }

    public int dicePool
    {
        get
        {
            return _dicePool;
        }

        set
        {
            try
            {
                _dicePool = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }

    public int edgeRank
    {
        get
        {
            return _edgeRank;
        }

        set
        {
            try
            {
                _edgeRank = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    } 

    public int elapsedIntervals
    {
        get
        {
            return _elapsedIntervals;
        }

        set
        {
            try
            {
                _elapsedIntervals = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }

    public int threshold
    {
        get
        {
            return threshold;
        }
        set
        {
            try
            {
                _threshold = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }

    public EXTENDED_TEST_INTERVAL extendedTestlnterval
    {
        get
        {
            return _extendedTestInterval;
        }
        set
        {
            try
            {
                _extendedTestInterval = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set error!!!");
            }
        }
    }

    // declare with a dice Pool or not
    public DiceRollVariables (int dP)
    {
        dicePool = dP;
    }

    public DiceRollVariables()
    {

    }
}
