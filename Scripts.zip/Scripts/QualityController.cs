using System;
using System.Collections.Generic;

[Serializable]
public class QualityController : StatController
{
    bool _init = false;

    public override void CGO_InitializeControllableStats()
    {

        if (_init)
        {
            return;
        }

        _init = true;
    }

    public void AddQuality(Quality.QUALITY_NAME qN, bool isCharCreation = false) // The ones without variants or parameters
    {
        foreach (Quality q in controlledStats)
        {
            if (q.qualityName == qN)
            {
                return;
            }
        }

        switch (qN)
        {
            case Quality.QUALITY_NAME.Bioadaptability:
            {
                Bioadaptability bioadaptability = new Bioadaptability();
                Control(bioadaptability);
                bioadaptability.CGO_Initialize(qN);
                DecreaseKarma(bioadaptability, isCharCreation);
                break;
            }
            case Quality.QUALITY_NAME.DermalDeposits:
            {
                DermalDeposits dermalDeposits = new DermalDeposits();
                Control(dermalDeposits);
                dermalDeposits.CGO_Initialize(qN);
                DecreaseKarma(dermalDeposits, isCharCreation);
                break;
            }
            case Quality.QUALITY_NAME.LowLightVision:
            {
                LowLightVision lowLightVision = new LowLightVision();
                Control(lowLightVision);
                lowLightVision.CGO_Initialize(qN);
                DecreaseKarma(lowLightVision, isCharCreation);
                break;
            }
            case Quality.QUALITY_NAME.MacroGravityAdaption:
            {
                MacroGravityAdaption macroGravityAdaption = new MacroGravityAdaption();
                Control(macroGravityAdaption);
                macroGravityAdaption.CGO_Initialize(qN);

                DecreaseKarma(macroGravityAdaption, isCharCreation);
                break;
            }
            case Quality.QUALITY_NAME.MicroGravityAdaption:
            {
                MicroGravityAdaption microGravityAdaption = new MicroGravityAdaption();
                Control(microGravityAdaption);
                microGravityAdaption.CGO_Initialize(qN);
                DecreaseKarma(microGravityAdaption, isCharCreation);
                break;
            }
            case Quality.QUALITY_NAME.QuickHealer:
            {
                QuickHealer quickHealer = new QuickHealer();
                Control(quickHealer);
                quickHealer.CGO_Initialize(qN);
                DecreaseKarma(quickHealer, isCharCreation);
                break;
            }
            case Quality.QUALITY_NAME.RadiationResistance:
            {
                RadiationResistance radiationResistance = new RadiationResistance();
                Control(radiationResistance);
                radiationResistance.CGO_Initialize(qN);
                DecreaseKarma(radiationResistance, isCharCreation);
                break;
            }
            case Quality.QUALITY_NAME.ThermographicVision:
            {
                ThermographicVision thermographicVision = new ThermographicVision();
                Control(thermographicVision);
                thermographicVision.CGO_Initialize(qN);
                DecreaseKarma(thermographicVision, isCharCreation);
                break;
            }
            case Quality.QUALITY_NAME.ToxinResistance:
            {
                ToxinResistance toxinResistance = new ToxinResistance();
                Control(toxinResistance);
                toxinResistance.CGO_Initialize(qN);
                DecreaseKarma(toxinResistance, isCharCreation);
                break;
            }
        }
    }

    public void AddQuality(Quality.QUALITY_NAME qN, Skill.SKILL_NAME sN, bool isCharCreation = false) 
        // Aptitude
    {
        foreach (Quality q in controlledStats)
        {
            if (q.qualityName == qN)
            {
                return;
            }
        }

        if (qN == Quality.QUALITY_NAME.Aptitude)
        {
            Aptitude aptitude = new Aptitude();
            Control(aptitude);
            aptitude.CGO_Initialize(qN, sN);
            DecreaseKarma(aptitude, isCharCreation);
        }
    }

    public void AddQuality(Quality.QUALITY_NAME qN, int r, bool isCharCreation = false) // BuiltTough, Fragile
    {
        foreach (Quality q in controlledStats)
        {
            if (q.qualityName == Quality.QUALITY_NAME.BuiltTough)
            {
                BuiltTough b = (BuiltTough)q;
                if (b.rating >= r)
                {
                    return;
                }
            }
        }

        if (qN == Quality.QUALITY_NAME.BuiltTough)
        {
            BuiltTough builtTough = new BuiltTough();
            Control(builtTough);
            builtTough.CGO_lnitialize(qN, r);
            DecreaseKarma(builtTough, isCharCreation);
        }

        if (qN == Quality.QUALITY_NAME.Fragile)
        {
            Fragile fragile = new Fragile();
            Control(fragile);
            fragile.CGO_Initialize(qN, r);
            DecreaseKarma(fragile, isCharCreation);
        }
    }

    public void AddQuality(Quality.QUALITY_NAME qN, Attribute.ATTRIBUTE_NAME aN,
        bool isCharCreation = false) // Exceptional
    {
        foreach (Quality q in controlledStats)
        {

            if (q.qualityName == Quality.QUALITY_NAME.Exceptional)
            {
                return;
            }
        }

        if (qN == Quality.QUALITY_NAME.Exceptional)
        {
            Exceptional exceptional = new Exceptional();
            Control(exceptional);
            exceptional.CGO_Initialize(qN, aN);
            DecreaseKarma(exceptional, isCharCreation);
        }
    }

    public void AddQuality(Quality.QUALITY_NAME qN, Damage.DAMAGE_TYPE dT,
        bool isCharCreation = false) // Toughness, Weakness
    {
        foreach (Quality q in controlledStats)
        {
            if (q.qualityName == Quality.QUALITY_NAME.Toughness)
            {
                Toughness t = (Toughness)q;
                if (t.damageType == dT)
                {
                    return;
                }
            }

            if (q.qualityName == Quality.QUALITY_NAME.Weakness)
            {
                Weakness w = (Weakness)q;
                if (w.damageType == dT)
                {
                    return;
                }
            }
        }

        if (qN == Quality.QUALITY_NAME.Toughness)
        {
            Toughness toughness = new Toughness();
            Control(toughness);
            toughness.CGO_Initialize(qN, dT);
            DecreaseKarma(toughness, isCharCreation);
        }

        if (qN == Quality.QUALITY_NAME.Weakness)
        {
            Weakness weakness = new Weakness();
            Control(weakness);
            weakness.CGO_Initialize(qN, dT);
            DecreaseKarma(weakness, isCharCreation);
        }
    }

    public void AddQuality(Quality.QUALITY_NAME qN, Attribute.ATTRIBUTE_NAME aN, int rtng,
        bool isCharCreation = false) // Impairment!
    {
        foreach (Quality q in controlledStats)
        {
            if (q.qualityName == Quality.QUALITY_NAME.Impairment)
            {
                Impairment i = (Impairment)q;
                if (i.attributeName == aN)
                {
                    return;
                }
            }
        }

        if (qN == Quality.QUALITY_NAME.Impairment)
        {
            Impairment impairment = new Impairment();
            Control(impairment);
            impairment.CGO_Initialize(qN, aN, rtng);
            DecreaseKarma(impairment, isCharCreation);
        }
    }

    void DecreaseKarma(Quality q, bool isCharCreation)
    {
        if (!isCharCreation)
        {
            if (entity.karma < q.karmaCost)
            {
                UnControl(q);
                Utilities.wrForce("<" + this.GetType().Name + ".AddQuality:" + CGO_Name +
                                  ".entity doesnt have enough karma for" +
                                  q.CGO_Name + "!");
                return;
            }

            if (q.qualityType == Quality.QUALITY_TYPE.Positive)
            {
                entity.DecreaseKarma(q.karmaCost);
            }
        }

        if (isCharCreation)
        {
            if (q.qualityType == Quality.QUALITY_TYPE.Negative)
            {
                entity.karma += q.karmaCost;
            }
        }
    }
}