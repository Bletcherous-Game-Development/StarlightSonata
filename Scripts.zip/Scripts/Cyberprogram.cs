//slottable into devices to augment
using System;

[Serializable]
public class Cyberprogram : Gear
{
    public enum CYBERPROGRAM_TYPE
    {
        Basic,
        Hacking,
        E_soft,
        Autosoft,
        Skillsoft,
        Knowsoft,
        Mapsoft,
        Shopsoft,
    }

    public CYBERPROGRAM_TYPE _cyberprogramType = CYBERPROGRAM_TYPE.Basic;

    public CYBERPROGRAM_TYPE cyberprogramType
    {
        get { return _cyberprogramType; }
        set
        {
            try
            {
                _cyberprogramType = value;
            }
            catch
            {
                Utilities.wrErr(this.GetType().Name + " Property set errror!!!");
            }
        }
    }
}