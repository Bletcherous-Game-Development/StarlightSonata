using System;

[Serializable]
public class GearSlotController : StatController
{
    bool _init = false;
    public GearSlot leftHip = new GearSlot();
    public GearSlot rightHip = new GearSlot();
    public GearSlot leftAnkle = new GearSlot();
    public GearSlot rightAnkle = new GearSlot();
    public GearSlot leftShoulder = new GearSlot();
    public GearSlot rightShoulder = new GearSlot();
    public GearSlot leftUnderarm = new GearSlot();
    public GearSlot rightUnderarm = new GearSlot();
    public GearSlot leftArmSlide = new GearSlot();
    public GearSlot rightArmSlide = new GearSlot();
    public GearSlot leftCyberarm = new GearSlot();
    public GearSlot rightCyberarm = new GearSlot();
    public GearSlot leftCyberleg = new GearSlot();
    public GearSlot rightCyberleg = new GearSlot();
    public GearSlot cyberTorso = new GearSlot();
    public GearSlot leftHand = new GearSlot();
    public GearSlot rightHand = new GearSlot();
    public GearSlot tacticalSling = new GearSlot();
    public GearSlot leftSlungOnBack = new GearSlot();
    public GearSlot rightSlungOnBack = new GearSlot();
    public GearSlot frontWaistband = new GearSlot();
    public GearSlot backWaistband = new GearSlot();
    public GearSlot mountO = new GearSlot();
    public GearSlot mount1 = new GearSlot();
    public GearSlot mount2 = new GearSlot();
    public GearSlot mount3 = new GearSlot();
    public GearSlot pack = new GearSlot();
    public GearSlot pocketO = new GearSlot();
    public GearSlot pocket1 = new GearSlot();
    public GearSlot pocket2 = new GearSlot();
    public GearSlot pocket3 = new GearSlot();

    public override void CGO_InitializeControllableStats()
    {
        if (_init)
        {
            return;
        }

        Control(leftHip);
        Control(rightHip);
        Control(leftAnkle);
        Control(rightAnkle);
        Control(leftShoulder);
        Control(rightShoulder);
        Control(leftUnderarm);
        Control(rightUnderarm);
        Control(leftArmSlide);
        Control(rightArmSlide);
        Control(leftCyberarm);
        Control(rightCyberarm);
        Control(leftCyberleg);
        Control(rightCyberleg);
        Control(cyberTorso);
        Control(leftHand);
        Control(rightHand);
        Control(tacticalSling);
        Control(leftSlungOnBack);
        Control(rightSlungOnBack);
        Control(frontWaistband);
        Control(backWaistband);
        Control(mountO);
        Control(mount1);
        Control(mount2);
        Control(mount3);
        Control(pack);
        Control(pocketO);
        Control(pocket1);
        Control(pocket2);
        Control(pocket3);
        leftHip.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.LeftHip);
        rightHip.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.RightHip);
        leftAnkle.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.LeftAnkle);
        rightAnkle.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.RightAnkle);
        leftShoulder.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.LeftShoulder);
        rightShoulder.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.RightShoulder);
        leftUnderarm.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.LeftUnderarm);
        rightUnderarm.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.RightUnderarm);
        leftArmSlide.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.LeftArmSlide);
        rightArmSlide.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.RightArmSlide);
        leftCyberarm.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.LeftCyberarm);
        rightCyberarm.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.RightCyberarm);
        leftCyberleg.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.LeftCyberleg);
        rightCyberleg.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.RightCyberleg);
        cyberTorso.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.Cybertorso);
        leftHand.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.LeftHand);
        rightHand.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.RightHand);
        tacticalSling.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.TacticalSling);
        leftSlungOnBack.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.LeftSlungOnBack);
        rightSlungOnBack.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.RightSlungOnBack);
        frontWaistband.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.FrontWaistband);
        backWaistband.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.BackWaistband);

        mountO.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.Mount0);
        mount1.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.Mount1);
        mount2.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.Mount2);
        mount3.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.Mount3);
        pack.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.Pack);
        pocketO.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.Pocket0);
        pocket1.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.Pocket1);
        pocket2.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.Pocket2);
        pocket3.CGO_Initialize(GearSlot.GEAR_SLOT_NAME.Pocket3);
    }

// the gear, where its going
    public void SlotGear(GearSlot slot, Gear gear)
    {
        slot.slottedGear = gear;
        Utilities.wrForce(entity.CGO_Name + " Slotted " + gear.CGO_Name + " in " + slot.CGO_Name);
    }

// basically drop it
    public void UnSlotGear(GearSlot slot)
    {
// cleanup for weapons
        if (slot.slottedGear.gearCatagory == Gear.GEAR_CATAGORY.Weapon)
        {
            Weapon _weapon = (Weapon)slot.slottedGear;
            _weapon.readied = false;
            Utilities.wrForce(entity.CGO_Name + " UnReadied " + _weapon.CGO_Name);
        }

        string slottedGearName = slot.slottedGear.CGO_Name;
        Utilities.wrForce(entity.CGO_Name + " UnSlotted " + slottedGearName + " from " + slot.CGO_Name);
// add code to instantiate the object and drop it
        slot.slottedGear = null;
    }
}