using System;

[Serializable]
public class ReloadWeapon : Action
{
    public override void InitiateAction(RangedWeapon rangedWeapon, AmmunitionContainer ammunitionContainer)
    {
        if (Utilities.isNull(entity))
        {
            Utilities.wrErr("<" + this.GetType().Name + "> " + CGO_Name + ".entity is null!");
            return;
        }

        Utilities.wr("***<==8_ReloadWeapon_8==>***");
        if (rangedWeapon.weaponCatagory == Weapon.WEAPON_CATAGORY.Ranged && ammunitionContainer.gearCatagory == Gear.GEAR_CATAGORY.Accessory);
        if (TimeAndTypeCheck())
        {
            Utilities.wrForce(rangedWeapon.CGO_Name + ":" + rangedWeapon.ammunitionContainerType.ToString() + "" +
                              rangedWeapon.currentAmmunitionCount + rangedWeapon.ammunitionCapacity);
            rangedWeapon.ReloadRangedWeapon(ammunitionContainer);
            Utilities.wrForce(rangedWeapon.CGO_Name + ";" +
                              rangedWeapon.ammunitionContainerType.ToString() + "" +
                              rangedWeapon.currentAmmunitionCount + +
                                  rangedWeapon.ammunitionCapacity);
        }
    }
}