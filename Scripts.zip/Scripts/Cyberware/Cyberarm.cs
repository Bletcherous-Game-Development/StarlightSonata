using System;

[Serializable]
public class Cyberarm : Cyberlimb
{
    public void CGO_Initialize(CYBERLIMB_STYLE cS, Augmentation.WARE_GRADE wG)
    {
        augmentationName = Augmentation.AUGMENTATION_NAME.Cyberarm;
        base.CGO_Initialize(cS, wG, augmentationName, 1000, 1, Gear.LEGALITY.L, wG, 1.0f);
    }
}